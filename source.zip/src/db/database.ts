import type { SQLiteDatabase } from 'expo-sqlite';
import type {
  CompanyBatch,
  CompanyImportBatch,
  CompanyMergedRow,
  CompanyPhoto,
  CompanyRawRow,
  CompanyRawRowDraft,
  DateSummary,
  LedgerEntry,
  LedgerEntryDraft,
  ReconciliationItem,
  ReconciliationSnapshot,
} from '../types';
import { addressSimilarity, isSafeAutoAddressMatch, normalizeAddress, numberTokensCompatible } from '../utils/address';

export async function migrateDbIfNeeded(db: SQLiteDatabase) {
  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS own_entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      record_date TEXT NOT NULL,
      bill_date TEXT NOT NULL,
      trip_no INTEGER NOT NULL CHECK(trip_no >= 1),
      address TEXT NOT NULL,
      freight_cents INTEGER NOT NULL DEFAULT 0,
      upstairs_cents INTEGER NOT NULL DEFAULT 0,
      upstairs_note TEXT,
      photo_uri TEXT,
      note TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_own_entries_record_date ON own_entries(record_date);
    CREATE INDEX IF NOT EXISTS idx_own_entries_bill_date ON own_entries(bill_date);
    CREATE TABLE IF NOT EXISTS own_entry_photos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      entry_id INTEGER NOT NULL,
      uri TEXT NOT NULL,
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      UNIQUE(entry_id, uri),
      FOREIGN KEY(entry_id) REFERENCES own_entries(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_own_entry_photos_entry ON own_entry_photos(entry_id);

    CREATE TABLE IF NOT EXISTS company_batches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      period TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'reviewing',
      created_at TEXT NOT NULL,
      confirmed_at TEXT,
      merged_at TEXT
    );

    CREATE TABLE IF NOT EXISTS company_photos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      batch_id INTEGER NOT NULL,
      uri TEXT NOT NULL,
      page_no INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY(batch_id) REFERENCES company_batches(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_company_photos_batch ON company_photos(batch_id);

    CREATE TABLE IF NOT EXISTS company_import_batches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      company_batch_id INTEGER NOT NULL,
      batch_no INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'reviewing',
      source_type TEXT NOT NULL DEFAULT 'paste',
      source_text TEXT,
      created_at TEXT NOT NULL,
      confirmed_at TEXT,
      UNIQUE(company_batch_id, batch_no),
      FOREIGN KEY(company_batch_id) REFERENCES company_batches(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_company_import_batches_account ON company_import_batches(company_batch_id);

    CREATE TABLE IF NOT EXISTS company_raw_rows (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      batch_id INTEGER NOT NULL,
      photo_id INTEGER,
      source_row_no INTEGER NOT NULL,
      bill_date TEXT NOT NULL,
      address TEXT NOT NULL,
      freight_cents INTEGER NOT NULL DEFAULT 0,
      upstairs_cents INTEGER NOT NULL DEFAULT 0,
      total_cents INTEGER NOT NULL DEFAULT 0,
      confidence REAL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY(batch_id) REFERENCES company_batches(id) ON DELETE CASCADE,
      FOREIGN KEY(photo_id) REFERENCES company_photos(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS idx_company_raw_batch ON company_raw_rows(batch_id);
    CREATE INDEX IF NOT EXISTS idx_company_raw_bill_date ON company_raw_rows(bill_date);

    CREATE TABLE IF NOT EXISTS company_merged_rows (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      batch_id INTEGER NOT NULL,
      bill_date TEXT NOT NULL,
      address TEXT NOT NULL,
      match_address TEXT NOT NULL,
      freight_cents INTEGER NOT NULL DEFAULT 0,
      upstairs_cents INTEGER NOT NULL DEFAULT 0,
      total_cents INTEGER NOT NULL DEFAULT 0,
      raw_row_ids_json TEXT NOT NULL,
      raw_row_count INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY(batch_id) REFERENCES company_batches(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_company_merged_batch ON company_merged_rows(batch_id);
    CREATE INDEX IF NOT EXISTS idx_company_merged_bill_date ON company_merged_rows(bill_date);

    CREATE TABLE IF NOT EXISTS reconciliation_matches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      batch_id INTEGER NOT NULL,
      own_entry_id INTEGER NOT NULL,
      company_merged_id INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(batch_id, own_entry_id),
      UNIQUE(batch_id, company_merged_id),
      FOREIGN KEY(batch_id) REFERENCES company_batches(id) ON DELETE CASCADE,
      FOREIGN KEY(own_entry_id) REFERENCES own_entries(id) ON DELETE CASCADE,
      FOREIGN KEY(company_merged_id) REFERENCES company_merged_rows(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS reconciliation_rejections (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      batch_id INTEGER NOT NULL,
      own_entry_id INTEGER NOT NULL,
      company_merged_id INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(batch_id, own_entry_id, company_merged_id),
      FOREIGN KEY(batch_id) REFERENCES company_batches(id) ON DELETE CASCADE,
      FOREIGN KEY(own_entry_id) REFERENCES own_entries(id) ON DELETE CASCADE,
      FOREIGN KEY(company_merged_id) REFERENCES company_merged_rows(id) ON DELETE CASCADE
    );
  `);

  // 增量迁移：只增加字段，绝不删除或重建用户已有账目。
  const columns = await db.getAllAsync<{ name: string }>('PRAGMA table_info(company_raw_rows)');
  const names = new Set(columns.map((column) => column.name));
  if (!names.has('import_batch_id')) await db.execAsync('ALTER TABLE company_raw_rows ADD COLUMN import_batch_id INTEGER');
  if (!names.has('original_sequence')) await db.execAsync("ALTER TABLE company_raw_rows ADD COLUMN original_sequence TEXT NOT NULL DEFAULT ''");
  if (!names.has('order_code')) await db.execAsync("ALTER TABLE company_raw_rows ADD COLUMN order_code TEXT NOT NULL DEFAULT ''");
  if (!names.has('recipient_name')) await db.execAsync("ALTER TABLE company_raw_rows ADD COLUMN recipient_name TEXT NOT NULL DEFAULT ''");

  // 旧版本的一份公司账只有一组明细：自动迁入“第1批”，保持原数据可继续使用。
  const legacyAccounts = await db.getAllAsync<{ id: number; status: string; created_at: string; confirmed_at: string | null }>(`
    SELECT b.id, b.status, b.created_at, b.confirmed_at FROM company_batches b
    WHERE EXISTS (SELECT 1 FROM company_raw_rows r WHERE r.batch_id = b.id AND r.import_batch_id IS NULL)
  `);
  for (const account of legacyAccounts) {
    let imported = await db.getFirstAsync<{ id: number }>(
      'SELECT id FROM company_import_batches WHERE company_batch_id = ? ORDER BY batch_no LIMIT 1', account.id,
    );
    if (!imported) {
      const result = await db.runAsync(
        `INSERT INTO company_import_batches(company_batch_id, batch_no, status, source_type, created_at, confirmed_at)
         VALUES (?, 1, ?, 'legacy', ?, ?)`,
        account.id, account.status === 'reviewing' ? 'reviewing' : 'confirmed', account.created_at, account.confirmed_at,
      );
      imported = { id: result.lastInsertRowId };
    }
    await db.runAsync('UPDATE company_raw_rows SET import_batch_id = ? WHERE batch_id = ? AND import_batch_id IS NULL', imported.id, account.id);
  }
  // 旧版单照片无损迁移到多照片表；原字段保留供旧备份兼容。
  await db.execAsync(`INSERT OR IGNORE INTO own_entry_photos(entry_id, uri, sort_order, created_at)
    SELECT id, photo_uri, 0, created_at FROM own_entries WHERE photo_uri IS NOT NULL AND photo_uri <> ''`);
}

type EntryRow = {
  id: number; record_date: string; bill_date: string; trip_no: number; address: string;
  freight_cents: number; upstairs_cents: number; upstairs_note: string | null; photo_uri: string | null;
  note: string | null; created_at: string; updated_at: string;
};

function mapRow(row: EntryRow): LedgerEntry {
  return {
    id: row.id, recordDate: row.record_date, billDate: row.bill_date, tripNo: row.trip_no,
    address: row.address, freightCents: row.freight_cents, upstairsCents: row.upstairs_cents,
    upstairsNote: row.upstairs_note, photoUri: row.photo_uri, note: row.note,
    createdAt: row.created_at, updatedAt: row.updated_at,
  };
}

export async function getEntriesForDate(db: SQLiteDatabase, recordDate: string): Promise<LedgerEntry[]> {
  const rows = await db.getAllAsync<EntryRow>(
    `SELECT * FROM own_entries WHERE record_date = ? ORDER BY trip_no ASC, id ASC`, recordDate,
  );
  return rows.map(mapRow);
}

export async function getEntry(db: SQLiteDatabase, id: number): Promise<LedgerEntry | null> {
  const row = await db.getFirstAsync<EntryRow>('SELECT * FROM own_entries WHERE id = ?', id);
  return row ? mapRow(row) : null;
}

export async function addEntry(db: SQLiteDatabase, draft: LedgerEntryDraft): Promise<number> {
  const now = new Date().toISOString();
  const result = await db.runAsync(
    `INSERT INTO own_entries (
      record_date, bill_date, trip_no, address, freight_cents, upstairs_cents,
      upstairs_note, photo_uri, note, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    draft.recordDate, draft.billDate, draft.tripNo, draft.address.trim(), draft.freightCents,
    draft.upstairsCents, draft.upstairsNote?.trim() || null, draft.photoUri,
    draft.note?.trim() || null, now, now,
  );
  return result.lastInsertRowId;
}

export type OwnEntryPhoto = { id: number; entryId: number; uri: string; sortOrder: number; createdAt: string };
export async function getEntryPhotos(db: SQLiteDatabase, entryId: number): Promise<OwnEntryPhoto[]> {
  const rows = await db.getAllAsync<{ id: number; entry_id: number; uri: string; sort_order: number; created_at: string }>('SELECT * FROM own_entry_photos WHERE entry_id = ? ORDER BY sort_order, id', entryId);
  return rows.map((r) => ({ id: r.id, entryId: r.entry_id, uri: r.uri, sortOrder: r.sort_order, createdAt: r.created_at }));
}
export async function addEntryPhoto(db: SQLiteDatabase, entryId: number, uri: string): Promise<number> {
  const order = await db.getFirstAsync<{ n: number }>('SELECT COALESCE(MAX(sort_order), -1) + 1 AS n FROM own_entry_photos WHERE entry_id = ?', entryId);
  const result = await db.runAsync('INSERT OR IGNORE INTO own_entry_photos(entry_id, uri, sort_order, created_at) VALUES (?, ?, ?, ?)', entryId, uri, order?.n ?? 0, new Date().toISOString());
  await db.runAsync('UPDATE own_entries SET photo_uri = COALESCE(photo_uri, ?), updated_at = ? WHERE id = ?', uri, new Date().toISOString(), entryId);
  return result.lastInsertRowId;
}
export async function deleteEntryPhoto(db: SQLiteDatabase, photoId: number, entryId: number): Promise<void> {
  await db.runAsync('DELETE FROM own_entry_photos WHERE id = ?', photoId);
  const first = await db.getFirstAsync<{ uri: string }>('SELECT uri FROM own_entry_photos WHERE entry_id = ? ORDER BY sort_order, id LIMIT 1', entryId);
  await db.runAsync('UPDATE own_entries SET photo_uri = ?, updated_at = ? WHERE id = ?', first?.uri ?? null, new Date().toISOString(), entryId);
}
export async function clearEntryPhotosForMonth(db: SQLiteDatabase, period: string): Promise<string[]> {
  const rows = await db.getAllAsync<{ uri: string }>(`SELECT p.uri FROM own_entry_photos p JOIN own_entries e ON e.id = p.entry_id WHERE substr(e.record_date,1,7) = ?`, period);
  await db.runAsync(`DELETE FROM own_entry_photos WHERE entry_id IN (SELECT id FROM own_entries WHERE substr(record_date,1,7) = ?)`, period);
  await db.runAsync(`UPDATE own_entries SET photo_uri = NULL, updated_at = ? WHERE substr(record_date,1,7) = ?`, new Date().toISOString(), period);
  return rows.map((r) => r.uri);
}

export async function updateEntry(db: SQLiteDatabase, id: number, draft: LedgerEntryDraft): Promise<void> {
  await db.runAsync(
    `UPDATE own_entries SET record_date = ?, bill_date = ?, trip_no = ?, address = ?,
      freight_cents = ?, upstairs_cents = ?, upstairs_note = ?, photo_uri = ?, note = ?, updated_at = ?
     WHERE id = ?`,
    draft.recordDate, draft.billDate, draft.tripNo, draft.address.trim(), draft.freightCents,
    draft.upstairsCents, draft.upstairsNote?.trim() || null, draft.photoUri,
    draft.note?.trim() || null, new Date().toISOString(), id,
  );
}

export async function deleteEntry(db: SQLiteDatabase, id: number): Promise<void> {
  await db.runAsync('DELETE FROM own_entries WHERE id = ?', id);
}

type SummaryRow = { record_date: string; order_count: number; trip_count: number; total_cents: number };

export async function getDateSummaries(db: SQLiteDatabase): Promise<DateSummary[]> {
  const rows = await db.getAllAsync<SummaryRow>(
    `SELECT record_date, COUNT(*) AS order_count, COUNT(DISTINCT trip_no) AS trip_count,
      COALESCE(SUM(freight_cents + upstairs_cents), 0) AS total_cents
     FROM own_entries GROUP BY record_date ORDER BY record_date DESC LIMIT 366`,
  );
  return rows.map((row) => ({
    recordDate: row.record_date, orderCount: row.order_count, tripCount: row.trip_count, totalCents: row.total_cents,
  }));
}

export async function getSuggestedTripNo(db: SQLiteDatabase, recordDate: string): Promise<number> {
  const row = await db.getFirstAsync<{ trip_no: number | null }>(
    'SELECT MAX(trip_no) AS trip_no FROM own_entries WHERE record_date = ?', recordDate,
  );
  return Math.max(1, row?.trip_no ?? 1);
}

// ---------------- 公司账 ----------------

type BatchRow = {
  id: number; period: string; status: 'reviewing' | 'confirmed' | 'merged'; created_at: string;
  confirmed_at: string | null; merged_at: string | null; photo_count?: number; raw_row_count?: number; merged_row_count?: number;
  import_batch_count?: number; confirmed_import_batch_count?: number; total_cents?: number;
};

function mapBatch(row: BatchRow): CompanyBatch {
  return {
    id: row.id, period: row.period, status: row.status, createdAt: row.created_at,
    confirmedAt: row.confirmed_at, mergedAt: row.merged_at,
    photoCount: row.photo_count ?? 0, rawRowCount: row.raw_row_count ?? 0, mergedRowCount: row.merged_row_count ?? 0,
    importBatchCount: row.import_batch_count ?? 0,
    confirmedImportBatchCount: row.confirmed_import_batch_count ?? 0,
    totalCents: row.total_cents ?? 0,
  };
}

export async function createCompanyBatch(db: SQLiteDatabase, period: string): Promise<number> {
  const now = new Date().toISOString();
  const result = await db.runAsync(
    `INSERT INTO company_batches(period, status, created_at) VALUES (?, 'reviewing', ?)`, period, now,
  );
  return result.lastInsertRowId;
}

export async function updateCompanyBatchPeriod(db: SQLiteDatabase, batchId: number, period: string): Promise<void> {
  await db.runAsync('UPDATE company_batches SET period = ? WHERE id = ?', period.trim(), batchId);
}

export async function getCompanyBatches(db: SQLiteDatabase): Promise<CompanyBatch[]> {
  const rows = await db.getAllAsync<BatchRow>(`
    SELECT b.*,
      (SELECT COUNT(*) FROM company_photos p WHERE p.batch_id = b.id) AS photo_count,
      (SELECT COUNT(*) FROM company_raw_rows r WHERE r.batch_id = b.id) AS raw_row_count,
      (SELECT COUNT(*) FROM company_merged_rows m WHERE m.batch_id = b.id) AS merged_row_count
      ,(SELECT COUNT(*) FROM company_import_batches ib WHERE ib.company_batch_id = b.id) AS import_batch_count
      ,(SELECT COUNT(*) FROM company_import_batches ib WHERE ib.company_batch_id = b.id AND ib.status = 'confirmed') AS confirmed_import_batch_count
      ,(SELECT COALESCE(SUM(r.total_cents), 0) FROM company_raw_rows r WHERE r.batch_id = b.id) AS total_cents
    FROM company_batches b ORDER BY b.id DESC
  `);
  return rows.map(mapBatch);
}

export async function getCompanyBatch(db: SQLiteDatabase, batchId: number): Promise<CompanyBatch | null> {
  const row = await db.getFirstAsync<BatchRow>(`
    SELECT b.*,
      (SELECT COUNT(*) FROM company_photos p WHERE p.batch_id = b.id) AS photo_count,
      (SELECT COUNT(*) FROM company_raw_rows r WHERE r.batch_id = b.id) AS raw_row_count,
      (SELECT COUNT(*) FROM company_merged_rows m WHERE m.batch_id = b.id) AS merged_row_count
      ,(SELECT COUNT(*) FROM company_import_batches ib WHERE ib.company_batch_id = b.id) AS import_batch_count
      ,(SELECT COUNT(*) FROM company_import_batches ib WHERE ib.company_batch_id = b.id AND ib.status = 'confirmed') AS confirmed_import_batch_count
      ,(SELECT COALESCE(SUM(r.total_cents), 0) FROM company_raw_rows r WHERE r.batch_id = b.id) AS total_cents
    FROM company_batches b WHERE b.id = ?
  `, batchId);
  return row ? mapBatch(row) : null;
}

type PhotoRow = { id: number; batch_id: number; uri: string; page_no: number; created_at: string };

function mapPhoto(row: PhotoRow): CompanyPhoto {
  return { id: row.id, batchId: row.batch_id, uri: row.uri, pageNo: row.page_no, createdAt: row.created_at };
}

export async function addCompanyPhoto(db: SQLiteDatabase, batchId: number, uri: string): Promise<number> {
  const count = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) AS count FROM company_photos WHERE batch_id = ?', batchId);
  const result = await db.runAsync(
    'INSERT INTO company_photos(batch_id, uri, page_no, created_at) VALUES (?, ?, ?, ?)',
    batchId, uri, (count?.count ?? 0) + 1, new Date().toISOString(),
  );
  return result.lastInsertRowId;
}

export async function getCompanyPhotos(db: SQLiteDatabase, batchId: number): Promise<CompanyPhoto[]> {
  const rows = await db.getAllAsync<PhotoRow>('SELECT * FROM company_photos WHERE batch_id = ? ORDER BY page_no ASC', batchId);
  return rows.map(mapPhoto);
}

type RawRow = {
  id: number; batch_id: number; import_batch_id: number | null; photo_id: number | null; source_row_no: number; original_sequence: string; order_code: string; recipient_name: string; bill_date: string; address: string;
  freight_cents: number; upstairs_cents: number; total_cents: number; confidence: number | null; created_at: string; updated_at: string;
};

function mapRawRow(row: RawRow): CompanyRawRow {
  return {
    id: row.id, batchId: row.batch_id, importBatchId: row.import_batch_id, photoId: row.photo_id, sourceRowNo: row.source_row_no,
    originalSequence: row.original_sequence, orderCode: row.order_code, recipientName: row.recipient_name,
    billDate: row.bill_date, address: row.address, freightCents: row.freight_cents,
    upstairsCents: row.upstairs_cents, totalCents: row.total_cents, confidence: row.confidence,
    createdAt: row.created_at, updatedAt: row.updated_at,
  };
}

export async function getCompanyRawRows(db: SQLiteDatabase, batchId: number): Promise<CompanyRawRow[]> {
  const rows = await db.getAllAsync<RawRow>(
    'SELECT * FROM company_raw_rows WHERE batch_id = ? ORDER BY source_row_no ASC, id ASC', batchId,
  );
  return rows.map(mapRawRow);
}

export async function getCompanyRawRowsForImportBatch(db: SQLiteDatabase, importBatchId: number): Promise<CompanyRawRow[]> {
  const rows = await db.getAllAsync<RawRow>(
    'SELECT * FROM company_raw_rows WHERE import_batch_id = ? ORDER BY source_row_no ASC, id ASC', importBatchId,
  );
  return rows.map(mapRawRow);
}

export async function addCompanyRawRow(db: SQLiteDatabase, draft: CompanyRawRowDraft): Promise<number> {
  const now = new Date().toISOString();
  const result = await db.runAsync(
    `INSERT INTO company_raw_rows(
      batch_id, import_batch_id, photo_id, source_row_no, original_sequence, order_code, recipient_name, bill_date, address, freight_cents, upstairs_cents,
      total_cents, confidence, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    draft.batchId, draft.importBatchId, draft.photoId, draft.sourceRowNo, draft.originalSequence.trim(), draft.orderCode.trim(), draft.recipientName.trim(), draft.billDate.trim(), draft.address.trim(),
    draft.freightCents, draft.upstairsCents, draft.totalCents, draft.confidence, now, now,
  );
  return result.lastInsertRowId;
}

export async function updateCompanyRawRow(db: SQLiteDatabase, row: CompanyRawRow): Promise<void> {
  await db.runAsync(
    `UPDATE company_raw_rows SET import_batch_id = ?, photo_id = ?, source_row_no = ?, original_sequence = ?, order_code = ?, recipient_name = ?, bill_date = ?, address = ?, freight_cents = ?,
      upstairs_cents = ?, total_cents = ?, confidence = ?, updated_at = ? WHERE id = ?`,
    row.importBatchId, row.photoId, row.sourceRowNo, row.originalSequence.trim(), row.orderCode.trim(), row.recipientName.trim(), row.billDate.trim(), row.address.trim(), row.freightCents,
    row.upstairsCents, row.totalCents, row.confidence, new Date().toISOString(), row.id,
  );
}

export async function deleteCompanyRawRow(db: SQLiteDatabase, rowId: number): Promise<void> {
  await db.runAsync('DELETE FROM company_raw_rows WHERE id = ?', rowId);
}

export async function appendOcrRows(
  db: SQLiteDatabase,
  batchId: number,
  photoId: number,
  rows: Array<{ billDate: string; address: string; freightCents: number; upstairsCents: number; totalCents: number; confidence: number | null }>,
): Promise<void> {
  const last = await db.getFirstAsync<{ max_no: number | null }>(
    'SELECT MAX(source_row_no) AS max_no FROM company_raw_rows WHERE batch_id = ?', batchId,
  );
  let rowNo = last?.max_no ?? 0;
  for (const row of rows) {
    rowNo += 1;
    await addCompanyRawRow(db, {
      ...row, batchId, importBatchId: null, photoId, sourceRowNo: rowNo,
      originalSequence: '', orderCode: '', recipientName: '',
    });
  }
}

type ImportBatchRow = {
  id: number; company_batch_id: number; batch_no: number; status: 'reviewing' | 'confirmed';
  source_type: CompanyImportBatch['sourceType']; source_text: string | null; created_at: string; confirmed_at: string | null;
  row_count?: number; total_cents?: number;
};

function mapImportBatch(row: ImportBatchRow): CompanyImportBatch {
  return {
    id: row.id, companyBatchId: row.company_batch_id, batchNo: row.batch_no, status: row.status,
    sourceType: row.source_type, sourceText: row.source_text, createdAt: row.created_at, confirmedAt: row.confirmed_at,
    rowCount: row.row_count ?? 0, totalCents: row.total_cents ?? 0,
  };
}

export async function createCompanyImportBatch(
  db: SQLiteDatabase, companyBatchId: number, sourceType: CompanyImportBatch['sourceType'], sourceText: string | null,
): Promise<number> {
  const last = await db.getFirstAsync<{ max_no: number | null }>(
    'SELECT MAX(batch_no) AS max_no FROM company_import_batches WHERE company_batch_id = ?', companyBatchId,
  );
  const result = await db.runAsync(
    `INSERT INTO company_import_batches(company_batch_id, batch_no, status, source_type, source_text, created_at)
     VALUES (?, ?, 'reviewing', ?, ?, ?)`,
    companyBatchId, (last?.max_no ?? 0) + 1, sourceType, sourceText, new Date().toISOString(),
  );
  await db.runAsync("UPDATE company_batches SET status = 'reviewing', confirmed_at = NULL, merged_at = NULL WHERE id = ?", companyBatchId);
  await db.runAsync('DELETE FROM company_merged_rows WHERE batch_id = ?', companyBatchId);
  return result.lastInsertRowId;
}

export async function getCompanyImportBatches(db: SQLiteDatabase, companyBatchId: number): Promise<CompanyImportBatch[]> {
  const rows = await db.getAllAsync<ImportBatchRow>(`
    SELECT ib.*,
      (SELECT COUNT(*) FROM company_raw_rows r WHERE r.import_batch_id = ib.id) AS row_count,
      (SELECT COALESCE(SUM(r.total_cents), 0) FROM company_raw_rows r WHERE r.import_batch_id = ib.id) AS total_cents
    FROM company_import_batches ib WHERE ib.company_batch_id = ? ORDER BY ib.batch_no ASC
  `, companyBatchId);
  return rows.map(mapImportBatch);
}

export async function getCompanyImportBatch(db: SQLiteDatabase, importBatchId: number): Promise<CompanyImportBatch | null> {
  const row = await db.getFirstAsync<ImportBatchRow>(`
    SELECT ib.*,
      (SELECT COUNT(*) FROM company_raw_rows r WHERE r.import_batch_id = ib.id) AS row_count,
      (SELECT COALESCE(SUM(r.total_cents), 0) FROM company_raw_rows r WHERE r.import_batch_id = ib.id) AS total_cents
    FROM company_import_batches ib WHERE ib.id = ?
  `, importBatchId);
  return row ? mapImportBatch(row) : null;
}

export async function confirmCompanyImportBatch(db: SQLiteDatabase, importBatchId: number): Promise<void> {
  const count = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) AS count FROM company_raw_rows WHERE import_batch_id = ?', importBatchId);
  if (!count?.count) throw new Error('本批还没有明细，不能确认。');
  await db.runAsync("UPDATE company_import_batches SET status = 'confirmed', confirmed_at = ? WHERE id = ?", new Date().toISOString(), importBatchId);
}

export async function deleteCompanyImportBatch(db: SQLiteDatabase, importBatchId: number): Promise<void> {
  const item = await getCompanyImportBatch(db, importBatchId);
  if (!item) return;
  await db.runAsync('DELETE FROM company_raw_rows WHERE import_batch_id = ?', importBatchId);
  await db.runAsync('DELETE FROM company_import_batches WHERE id = ?', importBatchId);
  await db.runAsync("UPDATE company_batches SET status = 'reviewing', confirmed_at = NULL, merged_at = NULL WHERE id = ?", item.companyBatchId);
  await db.runAsync('DELETE FROM company_merged_rows WHERE batch_id = ?', item.companyBatchId);
}

export async function addParsedRowsToImportBatch(
  db: SQLiteDatabase,
  companyBatchId: number,
  importBatchId: number,
  rows: Array<{ originalSequence: string; orderCode: string; address: string; recipientName: string; billDate: string; freightCents: number; upstairsCents: number; totalCents: number }>,
): Promise<void> {
  let sourceRowNo = 0;
  for (const row of rows) {
    sourceRowNo += 1;
    await addCompanyRawRow(db, {
      batchId: companyBatchId, importBatchId, photoId: null, sourceRowNo,
      originalSequence: row.originalSequence, orderCode: row.orderCode, recipientName: row.recipientName,
      billDate: row.billDate, address: row.address, freightCents: row.freightCents,
      upstairsCents: row.upstairsCents, totalCents: row.totalCents, confidence: null,
    });
  }
}

export async function confirmCompanyBatch(db: SQLiteDatabase, batchId: number): Promise<void> {
  const count = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) AS count FROM company_raw_rows WHERE batch_id = ?', batchId);
  if (!count?.count) throw new Error('还没有公司明细，不能确认。');
  await db.runAsync(
    `UPDATE company_batches SET status = 'confirmed', confirmed_at = ? WHERE id = ?`, new Date().toISOString(), batchId,
  );
}

type MergedRow = {
  id: number; batch_id: number; bill_date: string; address: string; match_address: string; freight_cents: number;
  upstairs_cents: number; total_cents: number; raw_row_ids_json: string; raw_row_count: number; created_at: string;
};

function mapMergedRow(row: MergedRow): CompanyMergedRow {
  let rawRowIds: number[] = [];
  try { rawRowIds = JSON.parse(row.raw_row_ids_json) as number[]; } catch { rawRowIds = []; }
  return {
    id: row.id, batchId: row.batch_id, billDate: row.bill_date, address: row.address, matchAddress: row.match_address,
    freightCents: row.freight_cents, upstairsCents: row.upstairs_cents, totalCents: row.total_cents,
    rawRowIds, rawRowCount: row.raw_row_count, createdAt: row.created_at,
  };
}

export async function mergeCompanyBatch(db: SQLiteDatabase, batchId: number): Promise<void> {
  const batch = await getCompanyBatch(db, batchId);
  if (!batch) throw new Error('公司账不存在。');
  const imports = await getCompanyImportBatches(db, batchId);
  if (!imports.length || imports.some((item) => item.status !== 'confirmed')) throw new Error('还有未核对的原始批次，请先完成核对。');
  const rows = await getCompanyRawRows(db, batchId);
  if (!rows.length) throw new Error('没有可合并的公司明细。');

  const groups = new Map<string, CompanyRawRow[]>();
  rows.forEach((row) => {
    const normalized = normalizeAddress(row.address);
    const existing = [...groups.entries()].find(([, group]) => {
      const first = group[0];
      return first && isSafeAutoAddressMatch(first.address, row.address) && addressSimilarity(first.address, row.address) >= 0.92;
    });
    const key = existing?.[0] ?? normalized;
    groups.set(key, [...(groups.get(key) ?? []), row]);
  });

  await db.runAsync('DELETE FROM company_merged_rows WHERE batch_id = ?', batchId);
  const now = new Date().toISOString();
  for (const group of groups.values()) {
    const first = group[0];
    if (!first) continue;
    await db.runAsync(
      `INSERT INTO company_merged_rows(
        batch_id, bill_date, address, match_address, freight_cents, upstairs_cents, total_cents,
        raw_row_ids_json, raw_row_count, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      batchId, first.billDate, first.address, normalizeAddress(first.address),
      group.reduce((sum, row) => sum + row.freightCents, 0),
      group.reduce((sum, row) => sum + row.upstairsCents, 0),
      group.reduce((sum, row) => sum + row.totalCents, 0),
      JSON.stringify(group.map((row) => row.id)), group.length, now,
    );
  }
  await db.runAsync(
    `UPDATE company_batches SET status = 'merged', confirmed_at = COALESCE(confirmed_at, ?), merged_at = ? WHERE id = ?`, now, now, batchId,
  );
}

export async function getCompanyMergedRows(db: SQLiteDatabase, batchId: number): Promise<CompanyMergedRow[]> {
  const rows = await db.getAllAsync<MergedRow>(
    'SELECT * FROM company_merged_rows WHERE batch_id = ? ORDER BY bill_date ASC, id ASC', batchId,
  );
  return rows.map(mapMergedRow);
}

export async function getCompanyRawRowsByIds(db: SQLiteDatabase, ids: number[]): Promise<CompanyRawRow[]> {
  if (!ids.length) return [];
  const placeholders = ids.map(() => '?').join(',');
  const rows = await db.getAllAsync<RawRow>(
    `SELECT * FROM company_raw_rows WHERE id IN (${placeholders}) ORDER BY source_row_no ASC`, ...ids,
  );
  return rows.map(mapRawRow);
}

// ---------------- 对账 ----------------

type MatchRow = { own_entry_id: number; company_merged_id: number };
type RejectionRow = { own_entry_id: number; company_merged_id: number };

export async function confirmReconciliationMatch(
  db: SQLiteDatabase, batchId: number, ownEntryId: number, companyMergedId: number,
): Promise<void> {
  await db.runAsync('DELETE FROM reconciliation_matches WHERE batch_id = ? AND (own_entry_id = ? OR company_merged_id = ?)', batchId, ownEntryId, companyMergedId);
  await db.runAsync(
    `INSERT INTO reconciliation_matches(batch_id, own_entry_id, company_merged_id, created_at) VALUES (?, ?, ?, ?)`,
    batchId, ownEntryId, companyMergedId, new Date().toISOString(),
  );
  await db.runAsync(
    'DELETE FROM reconciliation_rejections WHERE batch_id = ? AND own_entry_id = ? AND company_merged_id = ?',
    batchId, ownEntryId, companyMergedId,
  );
}

export async function rejectReconciliationCandidate(
  db: SQLiteDatabase, batchId: number, ownEntryId: number, companyMergedId: number,
): Promise<void> {
  await db.runAsync(
    `INSERT OR IGNORE INTO reconciliation_rejections(batch_id, own_entry_id, company_merged_id, created_at) VALUES (?, ?, ?, ?)`,
    batchId, ownEntryId, companyMergedId, new Date().toISOString(),
  );
}

function pairedItem(own: LedgerEntry, company: CompanyMergedRow, manualMatch: boolean, similarity: number): ReconciliationItem {
  const ownTotal = own.freightCents + own.upstairsCents;
  const differenceCents = company.totalCents - ownTotal;
  return {
    key: `pair-${own.id}-${company.id}`,
    kind: Math.abs(differenceCents) <= 1000 ? 'normal' : 'amount_anomaly',
    own, company, differenceCents, addressSimilarity: similarity, manualMatch,
  };
}

export async function getCompanyDateRange(db: SQLiteDatabase, batchId: number): Promise<{ start: string; end: string } | null> {
  const row = await db.getFirstAsync<{ start: string | null; end: string | null }>(
    `SELECT MIN(NULLIF(bill_date, '')) AS start, MAX(NULLIF(bill_date, '')) AS end FROM company_raw_rows WHERE batch_id = ?`, batchId,
  );
  return row?.start && row.end ? { start: row.start, end: row.end } : null;
}

export async function getReconciliationSnapshot(db: SQLiteDatabase, batchId: number, startDate?: string, endDate?: string): Promise<ReconciliationSnapshot> {
  const batch = await getCompanyBatch(db, batchId);
  if (!batch) throw new Error('公司账不存在。');
  if (batch.status !== 'merged') throw new Error('公司账还没有完成合并。');

  const companies = await getCompanyMergedRows(db, batchId);
  const defaultStart = `${batch.period}-01`;
  const defaultEnd = `${batch.period}-31`;
  const ownRows = await db.getAllAsync<EntryRow>(
    `SELECT * FROM own_entries WHERE record_date BETWEEN ? AND ? ORDER BY record_date ASC, bill_date ASC, id ASC`,
    startDate ?? defaultStart, endDate ?? defaultEnd,
  );
  const ownEntries = ownRows.map(mapRow);
  const matches = await db.getAllAsync<MatchRow>('SELECT own_entry_id, company_merged_id FROM reconciliation_matches WHERE batch_id = ?', batchId);
  const rejections = await db.getAllAsync<RejectionRow>('SELECT own_entry_id, company_merged_id FROM reconciliation_rejections WHERE batch_id = ?', batchId);
  const rejected = new Set(rejections.map((row) => `${row.own_entry_id}-${row.company_merged_id}`));

  const items: ReconciliationItem[] = [];
  const usedOwn = new Set<number>();
  const usedCompany = new Set<number>();

  // 1) 人工确认的匹配优先。
  for (const match of matches) {
    const own = ownEntries.find((entry) => entry.id === match.own_entry_id);
    const company = companies.find((entry) => entry.id === match.company_merged_id);
    if (!own || !company) continue;
    items.push(pairedItem(own, company, true, addressSimilarity(own.address, company.address)));
    usedOwn.add(own.id);
    usedCompany.add(company.id);
  }

  // 2) 同一天且安全的高度相似地址自动匹配。关键数字不同绝不自动匹配。
  for (const own of ownEntries) {
    if (usedOwn.has(own.id)) continue;
    const candidates = companies
      .filter((company) => !usedCompany.has(company.id))
      .map((company) => ({ company, score: addressSimilarity(own.address, company.address) }))
      .filter(({ company }) => isSafeAutoAddressMatch(own.address, company.address))
      .sort((a, b) => b.score - a.score);
    const best = candidates[0];
    if (!best) continue;
    items.push(pairedItem(own, best.company, false, best.score));
    usedOwn.add(own.id);
    usedCompany.add(best.company.id);
  }

  // 3) 剩余记录只给“疑似同一单”候选，不自动决定。
  for (const own of ownEntries) {
    if (usedOwn.has(own.id)) continue;
    const candidates = companies
      .filter((company) => !usedCompany.has(company.id))
      .filter((company) => !rejected.has(`${own.id}-${company.id}`))
      .map((company) => ({ company, score: addressSimilarity(own.address, company.address) }))
      .filter(({ company, score }) => score >= 0.55 || (score >= 0.45 && !numberTokensCompatible(own.address, company.address)))
      .sort((a, b) => b.score - a.score);
    const best = candidates[0];
    if (best) {
      items.push({
        key: `candidate-${own.id}-${best.company.id}`,
        kind: 'candidate', own, company: best.company,
        differenceCents: best.company.totalCents - (own.freightCents + own.upstairsCents),
        addressSimilarity: best.score, manualMatch: false,
      });
      usedOwn.add(own.id);
      usedCompany.add(best.company.id);
    }
  }

  // 4) 自己有、公司没有：疑似漏单。
  for (const own of ownEntries) {
    if (usedOwn.has(own.id)) continue;
    items.push({
      key: `missing-${own.id}`, kind: 'missing_company', own, company: null,
      differenceCents: null, addressSimilarity: null, manualMatch: false,
    });
  }

  // 5) 公司有、自己没有：待核对。
  for (const company of companies) {
    if (usedCompany.has(company.id)) continue;
    items.push({
      key: `extra-${company.id}`, kind: 'company_extra', own: null, company,
      differenceCents: null, addressSimilarity: null, manualMatch: false,
    });
  }

  const count = (kind: ReconciliationItem['kind']) => items.filter((item) => item.kind === kind).length;
  return {
    batch,
    items,
    normalCount: count('normal'),
    anomalyCount: count('amount_anomaly'),
    candidateCount: count('candidate'),
    missingCompanyCount: count('missing_company'),
    companyExtraCount: count('company_extra'),
  };
}
