export type LedgerEntry = {
  id: number;
  recordDate: string;
  billDate: string;
  tripNo: number;
  address: string;
  freightCents: number;
  upstairsCents: number;
  upstairsNote: string | null;
  photoUri: string | null;
  note: string | null;
  createdAt: string;
  updatedAt: string;
};

export type LedgerEntryDraft = Omit<LedgerEntry, 'id' | 'createdAt' | 'updatedAt'>;

export type DateSummary = {
  recordDate: string;
  orderCount: number;
  tripCount: number;
  totalCents: number;
};

export type CompanyBatchStatus = 'reviewing' | 'confirmed' | 'merged';

export type CompanyBatch = {
  id: number;
  period: string;
  status: CompanyBatchStatus;
  createdAt: string;
  confirmedAt: string | null;
  mergedAt: string | null;
  photoCount: number;
  rawRowCount: number;
  mergedRowCount: number;
  importBatchCount: number;
  confirmedImportBatchCount: number;
  totalCents: number;
};

export type CompanyImportBatchStatus = 'reviewing' | 'confirmed';

export type CompanyImportBatch = {
  id: number;
  companyBatchId: number;
  batchNo: number;
  status: CompanyImportBatchStatus;
  sourceType: 'paste' | 'photo' | 'file' | 'manual' | 'legacy';
  sourceText: string | null;
  createdAt: string;
  confirmedAt: string | null;
  rowCount: number;
  totalCents: number;
};

export type CompanyPhoto = {
  id: number;
  batchId: number;
  uri: string;
  pageNo: number;
  createdAt: string;
};

export type CompanyRawRow = {
  id: number;
  batchId: number;
  importBatchId: number | null;
  photoId: number | null;
  sourceRowNo: number;
  originalSequence: string;
  orderCode: string;
  recipientName: string;
  billDate: string;
  address: string;
  freightCents: number;
  upstairsCents: number;
  totalCents: number;
  confidence: number | null;
  createdAt: string;
  updatedAt: string;
};

export type CompanyRawRowDraft = Omit<CompanyRawRow, 'id' | 'createdAt' | 'updatedAt'>;

export type CompanyMergedRow = {
  id: number;
  batchId: number;
  billDate: string;
  address: string;
  matchAddress: string;
  freightCents: number;
  upstairsCents: number;
  totalCents: number;
  rawRowIds: number[];
  rawRowCount: number;
  createdAt: string;
};

export type ReconciliationKind = 'normal' | 'amount_anomaly' | 'candidate' | 'missing_company' | 'company_extra';

export type ReconciliationItem = {
  key: string;
  kind: ReconciliationKind;
  own: LedgerEntry | null;
  company: CompanyMergedRow | null;
  differenceCents: number | null;
  addressSimilarity: number | null;
  manualMatch: boolean;
};

export type ReconciliationSnapshot = {
  batch: CompanyBatch;
  items: ReconciliationItem[];
  normalCount: number;
  anomalyCount: number;
  candidateCount: number;
  missingCompanyCount: number;
  companyExtraCount: number;
};

export type RootScreen = 'home' | 'company' | 'reconcile' | 'me';
