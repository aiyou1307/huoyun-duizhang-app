import { useEffect } from 'react';
import { BackHandler, Keyboard } from 'react-native';
/** 与页面左上角使用同一个回退函数。Modal 的 onRequestClose 独立处理。 */
export function useAndroidBack(onBack: () => void, enabled = true) {
  useEffect(() => {
    if (!enabled) return;
    const listener = BackHandler.addEventListener('hardwareBackPress', () => {
      if (Keyboard.isVisible()) Keyboard.dismiss(); else onBack();
      return true;
    });
    return () => listener.remove();
  }, [onBack, enabled]);
}
