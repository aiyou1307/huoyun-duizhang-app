import type { CompanyRawRow } from '../types';
import { addressSimilarity, normalizeAddress, numberTokensCompatible } from './address';
export type MergeDecision = { left_key: string; right_key: string; action: 'merge' | 'separate' };
export type MergeCandidate = { left: CompanyRawRow[]; right: CompanyRawRow[]; reason: string };
export function rawKey(r: CompanyRawRow): string { return JSON.stringify([r.orderCode || `row:${r.importBatchId ?? 'legacy'}`, r.originalSequence || r.sourceRowNo]); }
export function dayGap(a: string, b: string): number { const n = Math.abs(Date.parse(a + 'T00:00:00Z') - Date.parse(b + 'T00:00:00Z')) / 86400000; return Number.isFinite(n) ? n : Infinity; }
export function sumCompany(rows: { freightCents: number; upstairsCents: number; totalCents: number }[]) {
  return rows.reduce((s, r) => ({ freightCents: s.freightCents + r.freightCents, upstairsCents: s.upstairsCents + r.upstairsCents, totalCents: s.totalCents + r.totalCents }), { freightCents: 0, upstairsCents: 0, totalCents: 0 });
}
export function buildCompanyMerge(rows: CompanyRawRow[], decisions: MergeDecision[]) {
  for (const r of rows) if (![r.freightCents,r.upstairsCents,r.totalCents].every(n => Number.isSafeInteger(n) && n >= 0) || r.freightCents + r.upstairsCents !== r.totalCents) throw new Error(`原始第 ${r.sourceRowNo} 行金额校验失败，请核对运费、上楼费与合计。`);
  const groups: CompanyRawRow[][] = rows.map(r => [r]);
  const pair = (a: string, b: string) => JSON.stringify([a, b].sort());
  const choices = new Map(decisions.map(d => [pair(d.left_key, d.right_key), d.action]));
  const separate = (a: CompanyRawRow[], b: CompanyRawRow[]) => a.some(x => b.some(y => choices.get(pair(rawKey(x), rawKey(y))) === 'separate'));
  const combine = (i: number, j: number) => { groups[i]!.push(...groups[j]!); groups.splice(j, 1); };
  // 人工选择具有最高优先级，且保留决定排除当前记录对。
  for (let i = 0; i < groups.length; i++) for (let j = i + 1; j < groups.length; j++) {
    if (!separate(groups[i]!, groups[j]!) && groups[i]!.some(x => groups[j]!.some(y => choices.get(pair(rawKey(x), rawKey(y))) === 'merge'))) { combine(i, j); j--; }
  }
  // 同日同地址分组，不改变任何原始金额。
  for (let i = 0; i < groups.length; i++) for (let j = i + 1; j < groups.length; j++) {
    const a = groups[i]!, b = groups[j]!;
    if (!separate(a, b) && [...a, ...b].every(r => r.billDate === a[0]!.billDate && normalizeAddress(r.address) === normalizeAddress(a[0]!.address))) { combine(i, j); j--; }
  }
  // 仅完整组跨度不超过四天、地址规范化完全一致、且最多一个日期有运费时自动跨日归组。
  // 多个日期都出现运费可能是独立订单，必须人工确认；明确不同的单号日期内运费也视为冲突。
  for (let i = 0; i < groups.length; i++) for (let j = i + 1; j < groups.length; j++) {
    const a = groups[i]!, b = groups[j]!, all = [...a, ...b];
    const dates = [...new Set(all.map(r => r.billDate))].sort();
    const freightDates = new Set(all.filter(r => r.freightCents > 0).map(r => r.billDate));
    const freightCodes = new Set(all.filter(r => r.freightCents > 0 && r.orderCode).map(r => r.orderCode));
    if (!separate(a, b) && dates.length > 1 && dates.every(Boolean) && dayGap(dates[0]!, dates[dates.length - 1]!) <= 4 && all.every(r => normalizeAddress(r.address) === normalizeAddress(a[0]!.address)) && freightDates.size <= 1 && freightCodes.size <= 1 && a[0]!.recipientName === b[0]!.recipientName) { combine(i, j); j--; }
  }
  const candidates: MergeCandidate[] = [];
  for (let i = 0; i < groups.length; i++) for (let j = i + 1; j < groups.length; j++) {
    const a = groups[i]!, b = groups[j]!;
    if (separate(a, b)) continue;
    const dates = [...a, ...b].map(r => r.billDate).sort();
    if (dates.some(d => !d) || dayGap(dates[0]!, dates[dates.length - 1]!) > 4 || a[0]!.billDate === b[0]!.billDate) continue;
    if (numberTokensCompatible(a[0]!.address, b[0]!.address) && addressSimilarity(a[0]!.address, b[0]!.address) >= 0.65) candidates.push({ left: a, right: b, reason: normalizeAddress(a[0]!.address) === normalizeAddress(b[0]!.address) ? '日期接近，但存在多笔独立订单或姓名冲突的可能，请检查单号及运费。' : '日期接近、门牌数字一致，但地址文字有差异。' });
  }
  const before = sumCompany(rows), after = sumCompany(groups.map(g => sumCompany(g)));
  if (JSON.stringify(before) !== JSON.stringify(after) || groups.flat().length !== rows.length) throw new Error('合并金额或记录数量校验失败，已停止保存。');
  const cross = groups.filter(g => new Set(g.map(r => r.billDate)).size > 1);
  return { groups, candidates, totals: before, crossDateCount: cross.length, autoCrossDateCount: cross.filter(g=>!g.some(x=>g.some(y=>choices.get(pair(rawKey(x),rawKey(y)))==='merge'))).length };
}
