function collapseRepeatedCity(value: string): string {
  return value
    .replace(/北京市北京市/g, '北京市')
    .replace(/上海市上海市/g, '上海市')
    .replace(/天津市天津市/g, '天津市')
    .replace(/重庆市重庆市/g, '重庆市');
}

export function normalizeAddress(value: string): string {
  return collapseRepeatedCity(value)
    .toLowerCase()
    .replace(/[\s,，。.;；:：、()（）\-—_]/g, '')
    .replace(/号楼/g, '栋')
    .replace(/幢/g, '栋')
    .replace(/单元楼/g, '单元')
    .trim();
}

export function extractNumberTokens(value: string): string[] {
  return normalizeAddress(value).match(/\d+/g) ?? [];
}

function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const previous = Array.from({ length: b.length + 1 }, (_, i) => i);
  const current = new Array<number>(b.length + 1);
  for (let i = 1; i <= a.length; i += 1) {
    current[0] = i;
    for (let j = 1; j <= b.length; j += 1) {
      current[j] = Math.min(
        current[j - 1]! + 1,
        previous[j]! + 1,
        previous[j - 1]! + (a[i - 1] === b[j - 1] ? 0 : 1),
      );
    }
    for (let j = 0; j <= b.length; j += 1) previous[j] = current[j]!;
  }
  return previous[b.length]!;
}

export function numberTokensCompatible(a: string, b: string): boolean {
  const left = extractNumberTokens(a);
  const right = extractNumberTokens(b);
  if (!left.length || !right.length) return true;
  return left.join('|') === right.join('|');
}

export function addressSimilarity(a: string, b: string): number {
  const left = normalizeAddress(a);
  const right = normalizeAddress(b);
  if (!left || !right) return 0;
  if (left === right) return 1;

  // “北京市原生墅” 与 “原生墅”这一类包含关系应该得到较高分。
  if (left.includes(right) || right.includes(left)) {
    const shorter = Math.min(left.length, right.length);
    const longer = Math.max(left.length, right.length);
    return Math.max(0.82, shorter / longer);
  }

  const distance = levenshtein(left, right);
  const editScore = 1 - distance / Math.max(left.length, right.length);

  const leftChars = new Set(left.split(''));
  const rightChars = new Set(right.split(''));
  const intersection = [...leftChars].filter((char) => rightChars.has(char)).length;
  const union = new Set([...leftChars, ...rightChars]).size;
  const charScore = union ? intersection / union : 0;

  return Math.max(0, Math.min(1, editScore * 0.72 + charScore * 0.28));
}

export function isSafeAutoAddressMatch(a: string, b: string): boolean {
  const score = addressSimilarity(a, b);
  return numberTokensCompatible(a, b) && score >= 0.92;
}
