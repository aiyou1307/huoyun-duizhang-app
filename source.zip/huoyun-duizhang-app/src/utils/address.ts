function collapseRepeatedCity(value: string): string {
  return value
    .replace(/北京市北京市/g, '北京市')
    .replace(/上海市上海市/g, '上海市')
    .replace(/天津市天津市/g, '天津市')
    .replace(/重庆市重庆市/g, '重庆市');
}

const chineseDigits: Record<string, string> = {
  零: '0', 〇: '0', 一: '1', 二: '2', 三: '3', 四: '4', 五: '5', 六: '6', 七: '7', 八: '8', 九: '9',
};

function chineseNumberToArabic(value: string): string {
  if (!value.includes('十')) return [...value].map((char) => chineseDigits[char] ?? char).join('');
  const [tensText = '', onesText = ''] = value.split('十');
  const tens = tensText ? Number(chineseDigits[tensText] ?? tensText) : 1;
  const ones = onesText ? Number(chineseDigits[onesText] ?? onesText) : 0;
  return String(tens * 10 + ones);
}

function normalizeAddressNumbers(value: string): string {
  return value.replace(/[零〇一二三四五六七八九十]+(?=(?:号楼|栋|幢|单元|室))/g, chineseNumberToArabic);
}

export function normalizeAddress(value: string): string {
  return normalizeAddressNumbers(collapseRepeatedCity(value))
    .toLowerCase()
    .replace(/[\s,，。.;；:：、()（）\-—_]/g, '')
    .replace(/^(?:北京市|上海市|天津市|重庆市)+/, '')
    .replace(/号楼/g, '栋')
    .replace(/幢/g, '栋')
    .replace(/单元楼/g, '单元')
    .replace(/室$/g, '')
    .trim();
}

export function extractNumberTokens(value: string): string[] {
  return normalizeAddress(value).match(/\d+/g) ?? [];
}

function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const previous = Array.from({ length: b.length + 1 }, (_, i) => i);
  const current = new Array<number>(b.length + 1);
  for (let i = 1; i <= a.length; i += 1) {
    current[0] = i;
    for (let j = 1; j <= b.length; j += 1) {
      current[j] = Math.min(
        current[j - 1]! + 1,
        previous[j]! + 1,
        previous[j - 1]! + (a[i - 1] === b[j - 1] ? 0 : 1),
      );
    }
    for (let j = 0; j <= b.length; j += 1) previous[j] = current[j]!;
  }
  return previous[b.length]!;
}

export function numberTokensCompatible(a: string, b: string): boolean {
  const left = extractNumberTokens(a);
  const right = extractNumberTokens(b);
  if (!left.length || !right.length) return true;
  return left.join('|') === right.join('|');
}

export function addressSimilarity(a: string, b: string): number {
  const left = normalizeAddress(a);
  const right = normalizeAddress(b);
  if (!left || !right) return 0;
  if (left === right) return 1;

  // “北京市原生墅” 与 “原生墅”这一类包含关系应该得到较高分。
  if (left.includes(right) || right.includes(left)) {
    const shorter = Math.min(left.length, right.length);
    const longer = Math.max(left.length, right.length);
    return Math.max(0.82, shorter / longer);
  }

  const distance = levenshtein(left, right);
  const editScore = 1 - distance / Math.max(left.length, right.length);

  const leftChars = new Set(left.split(''));
  const rightChars = new Set(right.split(''));
  const intersection = [...leftChars].filter((char) => rightChars.has(char)).length;
  const union = new Set([...leftChars, ...rightChars]).size;
  const charScore = union ? intersection / union : 0;

  return Math.max(0, Math.min(1, editScore * 0.72 + charScore * 0.28));
}

export function isSafeAutoAddressMatch(a: string, b: string): boolean {
  const score = addressSimilarity(a, b);
  // 日期约束在调用处单独处理；同一日期内允许行政区前缀、楼栋写法和少量 OCR 差异。
  return numberTokensCompatible(a, b) && score >= 0.82;
}
