export function yuanToCents(value: string): number {
  const normalized = value.replace(/[^0-9.]/g, '');
  if (!/^\d*(?:\.\d{0,2})?$/.test(normalized)) return 0;
  const [whole = '', fraction = ''] = normalized.split('.');
  const cents = Number(whole || 0) * 100 + Number(fraction.padEnd(2, '0'));
  return Number.isSafeInteger(cents) && cents >= 0 ? cents : 0;
}

export function centsToYuan(cents: number): string {
  const yuan = cents / 100;
  return Number.isInteger(yuan) ? String(yuan) : yuan.toFixed(2).replace(/0+$/, '').replace(/\.$/, '');
}

export function formatMoney(cents: number): string {
  return `¥${centsToYuan(cents)}`;
}
