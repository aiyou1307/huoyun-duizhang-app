const pad = (value: number) => String(value).padStart(2, '0');

export function toYmd(date: Date): string {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function todayYmd(): string {
  return toYmd(new Date());
}

export function parseYmd(value: string): Date {
  const [year, month, day] = value.split('-').map(Number);
  return new Date(year || 1970, (month || 1) - 1, day || 1, 12, 0, 0);
}

export function formatChineseDate(value: string, withYear = false): string {
  const date = parseYmd(value);
  if (withYear) {
    return `${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日`;
  }
  return `${date.getMonth() + 1}月${date.getDate()}日`;
}

export function weekdayChinese(value: string): string {
  const names = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
  return names[parseYmd(value).getDay()] ?? '';
}

export function normalizeBillDateInput(value: string, period: string): string | null {
  const text = value.trim().replace(/[年.]/g, '-').replace(/[月/]/g, '-').replace(/日/g, '');
  const parts = text.split('-').filter(Boolean).map((part) => Number(part));
  if (parts.some((part) => !Number.isFinite(part))) return null;

  let year: number;
  let month: number;
  let day: number;
  if (parts.length === 3) {
    [year, month, day] = parts as [number, number, number];
  } else if (parts.length === 2) {
    const [periodYear, periodMonth] = period.split('-').map(Number);
    year = periodYear || new Date().getFullYear();
    month = parts[0] || periodMonth || 1;
    day = parts[1] || 1;
  } else {
    return null;
  }

  if (year < 2000 || month < 1 || month > 12 || day < 1 || day > 31) return null;
  const candidate = new Date(year, month - 1, day, 12, 0, 0);
  if (candidate.getFullYear() !== year || candidate.getMonth() !== month - 1 || candidate.getDate() !== day) return null;
  return `${year}-${pad(month)}-${pad(day)}`;
}
