import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme';

export function PlaceholderScreen({ kind }: { kind: 'me' }) {
  return (
    <View style={styles.root}>
      <View style={styles.header}><Text style={styles.headerTitle}>我的</Text></View>
      <View style={styles.card}>
        <Ionicons name="person-outline" size={52} color={colors.primary} />
        <Text style={styles.title}>备份与导出放在第三阶段</Text>
        <Text style={styles.text}>这里后续会加入 Excel 导出、完整备份、恢复、换手机迁移和应用设置。</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  header: { minHeight: 66, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.primary },
  headerTitle: { fontSize: 24, fontWeight: '900', color: '#fff' },
  card: { margin: 18, marginTop: 28, backgroundColor: '#fff', borderRadius: 18, padding: 28, alignItems: 'center', borderWidth: 1, borderColor: colors.border },
  title: { marginTop: 14, fontSize: 20, color: colors.text, fontWeight: '900' },
  text: { marginTop: 10, fontSize: 16, lineHeight: 25, color: colors.muted, textAlign: 'center' },
});
