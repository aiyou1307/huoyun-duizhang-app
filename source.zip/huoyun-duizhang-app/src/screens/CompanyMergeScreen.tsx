import { Ionicons } from '@expo/vector-icons';
import { useCallback, useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { AppHeader } from '../components/AppHeader';
import { getCompanyBatch, getCompanyMergedRows, mergeCompanyBatch } from '../db/database';
import { colors } from '../theme';
import type { CompanyBatch, CompanyMergedRow } from '../types';
import { formatMoney } from '../utils/money';

export function CompanyMergeScreen({
  batchId,
  onBack,
  onOpenMerged,
}: {
  batchId: number;
  onBack: () => void;
  onOpenMerged: (mergedId: number) => void;
}) {
  const db = useSQLiteContext();
  const [batch, setBatch] = useState<CompanyBatch | null>(null);
  const [rows, setRows] = useState<CompanyMergedRow[]>([]);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setBatch(await getCompanyBatch(db, batchId));
    setRows(await getCompanyMergedRows(db, batchId));
  }, [db, batchId]);
  useEffect(() => { void load(); }, [load]);

  const merge = async () => {
    setBusy(true);
    try {
      await mergeCompanyBatch(db, batchId);
      await load();
    } catch (error) {
      Alert.alert('无法合并', error instanceof Error ? error.message : '请返回检查。');
    } finally { setBusy(false); }
  };

  return (
    <View style={styles.root}>
      <AppHeader title="公司账合并" onBack={onBack} />
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.ruleCard}>
          <Ionicons name="git-merge-outline" size={30} color={colors.primaryDark} />
          <View style={{ flex: 1 }}>
            <Text style={styles.ruleTitle}>合并规则</Text>
            <Text style={styles.ruleText}>按标准化地址合并，运费、上楼费、合计分别求和。只有高置信度地址才自动归组；关键数字不同不会强行合并。原始记录永久保留并可追溯。</Text>
          </View>
        </View>

        {batch?.status !== 'merged' ? (
          <>
            <View style={styles.readyCard}>
              <Text style={styles.readyTitle}>已确认原始明细：{batch?.rawRowCount ?? 0} 行</Text>
              <Text style={styles.readyText}>系统现在才会开始合并；原始逐行数据和照片仍会完整保留。</Text>
            </View>
            <Pressable style={[styles.mergeButton, busy && styles.disabled]} onPress={merge} disabled={busy}>
              <Text style={styles.mergeText}>{busy ? '正在合并…' : '开始合并公司账'}</Text>
            </Pressable>
          </>
        ) : (
          <>
            <View style={styles.successCard}>
              <Ionicons name="checkmark-circle" size={28} color={colors.success} />
              <View><Text style={styles.successTitle}>合并完成</Text><Text style={styles.successText}>{batch.rawRowCount} 行原始明细 → {rows.length} 条对账记录</Text></View>
            </View>
            <Text style={styles.sectionTitle}>合并后的公司账</Text>
            {rows.map((row) => (
              <Pressable key={row.id} style={styles.rowCard} onPress={() => onOpenMerged(row.id)}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.date}>{row.billDate}</Text>
                  <Text style={styles.address}>{row.address}</Text>
                  <Text style={styles.moneyLine}>运费 {formatMoney(row.freightCents)}　上楼 {formatMoney(row.upstairsCents)}　合计 {formatMoney(row.totalCents)}</Text>
                </View>
                <View style={styles.countBadge}><Text style={styles.countText}>{row.rawRowCount} 行</Text></View>
              </Pressable>
            ))}
            <Pressable style={[styles.remergeButton, busy && styles.disabled]} onPress={merge} disabled={busy}><Text style={styles.remergeText}>{busy ? '正在重新合并…' : '按当前原始明细重新合并'}</Text></Pressable>
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background }, content: { padding: 14, paddingBottom: 40 },
  ruleCard: { backgroundColor: '#EAF5FF', borderWidth: 1, borderColor: '#CBE4FB', borderRadius: 15, padding: 14, flexDirection: 'row', gap: 12 },
  ruleTitle: { color: colors.primaryDark, fontWeight: '900', fontSize: 17 }, ruleText: { marginTop: 5, color: '#42637F', lineHeight: 21, fontWeight: '700' },
  readyCard: { marginTop: 14, backgroundColor: '#fff', borderWidth: 1, borderColor: colors.border, borderRadius: 15, padding: 16 },
  readyTitle: { color: colors.text, fontSize: 18, fontWeight: '900' }, readyText: { marginTop: 6, color: colors.muted, lineHeight: 21 },
  mergeButton: { marginTop: 14, height: 58, borderRadius: 15, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' }, mergeText: { color: '#fff', fontSize: 19, fontWeight: '900' }, disabled: { opacity: 0.5 },
  successCard: { marginTop: 14, backgroundColor: '#E9F8F0', borderRadius: 15, borderWidth: 1, borderColor: '#BFE8D2', padding: 14, flexDirection: 'row', gap: 10, alignItems: 'center' },
  successTitle: { color: '#147547', fontWeight: '900', fontSize: 18 }, successText: { color: '#39735A', marginTop: 3 },
  sectionTitle: { marginTop: 18, marginBottom: 8, color: colors.text, fontSize: 19, fontWeight: '900' },
  rowCard: { backgroundColor: '#fff', borderRadius: 15, borderWidth: 1, borderColor: colors.border, padding: 14, marginBottom: 10, flexDirection: 'row', alignItems: 'center', gap: 8 },
  date: { color: colors.primaryDark, fontWeight: '900', fontSize: 14 }, address: { marginTop: 4, color: colors.text, fontSize: 16, fontWeight: '800' }, moneyLine: { marginTop: 7, color: '#5D6E82', fontSize: 13 },
  countBadge: { backgroundColor: '#EEF5FB', paddingHorizontal: 9, paddingVertical: 6, borderRadius: 999 }, countText: { color: '#536A80', fontWeight: '800', fontSize: 12 },
  remergeButton: { marginTop: 8, height: 50, borderRadius: 13, borderWidth: 1, borderColor: colors.primary, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' }, remergeText: { color: colors.primaryDark, fontWeight: '900' },
});
