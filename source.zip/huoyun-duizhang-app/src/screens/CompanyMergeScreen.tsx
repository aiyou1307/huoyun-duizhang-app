import { useCallback, useEffect, useState } from 'react';
import { Alert, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { AppHeader } from '../components/AppHeader';
import { getCompanyBatch, getCompanyMergedRows, getCompanyMergePlan, mergeCompanyBatch, saveCompanyMergeDecision } from '../db/database';
import { useAndroidBack } from '../hooks/useAndroidBack';
import { colors } from '../theme';
import type { CompanyBatch, CompanyMergedRow, CompanyRawRow } from '../types';
import { sumCompany, type MergeCandidate } from '../utils/companyMerge';
import { formatMoney } from '../utils/money';

export function CompanyMergeScreen({ batchId, onBack, onOpenMerged }: { batchId: number; onBack: () => void; onOpenMerged: (id: number) => void }) {
  const db = useSQLiteContext();
  const [batch, setBatch] = useState<CompanyBatch | null>(null);
  const [rows, setRows] = useState<CompanyMergedRow[]>([]);
  const [candidates, setCandidates] = useState<MergeCandidate[]>([]);
  const [crossCount, setCrossCount] = useState(0);
  const [checking, setChecking] = useState(false);
  const [selecting, setSelecting] = useState(false);
  const [selected, setSelected] = useState<number[]>([]);
  const [groups, setGroups] = useState<CompanyRawRow[][]>([]);
  const [busy, setBusy] = useState(false);
  const load = useCallback(async () => {
    setBatch(await getCompanyBatch(db, batchId));
    setRows(await getCompanyMergedRows(db, batchId));
    const plan = await getCompanyMergePlan(db, batchId);
    setCandidates(plan.candidates); setCrossCount(plan.autoCrossDateCount); setGroups(plan.groups);
  }, [db, batchId]);
  useEffect(() => { void load().catch(e => Alert.alert('读取失败', String(e))); }, [load]);
  const back = () => { if (busy) return; if (checking) setChecking(false); else if (selecting) { setSelecting(false); setSelected([]); } else onBack(); };
  useAndroidBack(back);
  const act = async (action: () => Promise<void>) => {
    if (busy) return; setBusy(true);
    try { await action(); setSelected([]); await load(); } catch (e) { Alert.alert('未完成', e instanceof Error ? e.message : String(e)); } finally { setBusy(false); }
  };
  const choose = (c: MergeCandidate, action: 'merge' | 'separate') => act(async () => {
    await saveCompanyMergeDecision(db, batchId, c.left, c.right, action); await mergeCompanyBatch(db, batchId);
  });
  const manualMerge = () => Alert.alert('确认手动合并？', '仅合并所选记录的分组，保留全部原始日期及金额。请核对是否同一订单。', [{ text: '取消' }, { text: '确认合并', onPress: () => void act(async () => {
    const picked = selected.map(i => groups[i]!).filter(Boolean);
    for (let i=0; i<picked.length; i++) for(let j=i+1;j<picked.length;j++) await saveCompanyMergeDecision(db,batchId,picked[i]!,picked[j]!,'merge');
    await mergeCompanyBatch(db,batchId); setSelected([]); setSelecting(false);
  }) }]);
  const split = (group: CompanyRawRow[]) => Alert.alert('拆分为原始行？', '将保持每条原始记录分开。决定会保存；之后可重新选择部分记录手动合并。', [{ text:'取消' }, { text:'确认拆分', onPress: () => void act(async () => {
    for (let i=0;i<group.length;i++) await saveCompanyMergeDecision(db,batchId,[group[i]!],group.slice(i+1),'separate');
    await mergeCompanyBatch(db,batchId);
  }) }]);
  const button = (label: string, fn: () => void, disabled = false) => <Pressable disabled={busy || disabled} style={[styles.button,(busy || disabled) && {opacity:0.5}]} onPress={fn}><Text style={styles.buttonText}>{label}</Text></Pressable>;
  const totals = sumCompany(rows);
  return <View style={styles.root}><AppHeader title={checking ? '检查跨日期订单' : selecting ? '手动合并 / 拆分' : '公司账合并'} onBack={back} />
    {checking ? <FlatList data={candidates} keyExtractor={(_,i)=>String(i)} contentContainerStyle={styles.content} ListEmptyComponent={<Text style={styles.text}>没有待确认的跨日期订单。</Text>} renderItem={({item})=><View style={styles.card}><Text style={styles.title}>{item.reason}</Text>{[...item.left,...item.right].map(r=><Text key={r.id} style={styles.text}>{r.billDate}　{r.address}\n运费 {formatMoney(r.freightCents)}　上楼 {formatMoney(r.upstairsCents)}</Text>)}{button('确认合并',()=>void choose(item,'merge'))}{button('保持分开',()=>void choose(item,'separate'))}</View>} /> : selecting ? <FlatList data={groups} keyExtractor={g=>String(g[0]!.id)} contentContainerStyle={styles.content} ListHeaderComponent={<>{button(`合并所选 ${selected.length} 组`,manualMerge,selected.length<2)}<Text style={styles.text}>点击记录选择；超过4天也可以人工确认合并。拆分后可重新选择部分原始行。</Text></>} renderItem={({item,index})=><View style={styles.card}><Pressable onPress={()=>setSelected(s=>s.includes(index)?s.filter(i=>i!==index):[...s,index])}><Text style={styles.title}>{selected.includes(index)?'☑':'□'} {item[0]!.address}</Text><Text style={styles.text}>{[...new Set(item.map(r=>r.billDate))].join('、')}　{item.length} 行　{formatMoney(sumCompany(item).totalCents)}</Text></Pressable>{item.length>1 && button('拆分此组',()=>split(item))}</View>} /> : <FlatList data={rows} keyExtractor={r=>String(r.id)} contentContainerStyle={styles.content} initialNumToRender={12} windowSize={7} ListHeaderComponent={<>
      <View style={styles.card}><Text style={styles.title}>{batch?.needsRemerge ? '待重新合并：原始明细已修改' : batch?.status === 'merged' ? '合并检查' : '准备合并'}</Text>
      <Text style={styles.text}>{batch?.sourceName ? `来源：导入已合并账 ${batch.sourceName}；文件不含完整原始明细。` : '同日同地址自动合并；1～4天同地址且无订单冲突时自动归组。地址差异或多笔运费需人工确认。超过4天仅人工合并。'}</Text>
      <Text style={styles.text}>原始记录：{batch?.rawRowCount ?? 0} 条\n合并后记录：{rows.length} 条\n跨日期自动合并：{crossCount} 组\n待人工确认：{candidates.length} 组\n运费：{formatMoney(totals.freightCents)}\n上楼费：{formatMoney(totals.upstairsCents)}\n总金额：{formatMoney(totals.totalCents)}\n金额校验：{batch?.needsRemerge ? '待重新合并校验' : batch?.status === 'merged' ? '✓ 一致（全部记录）' : '合并前后自动校验'}</Text></View>
      {!batch?.sourceName && <>{button(busy?'正在计算…':'按最新原始明细合并',()=>void act(()=>mergeCompanyBatch(db,batchId)))}{button(`检查跨日期订单（待确认${candidates.length}组）`,()=>setChecking(true))}{button('手动选择合并 / 拆分',()=>setSelecting(true))}</>}
    </>} renderItem={({item})=><Pressable style={styles.card} onPress={()=>onOpenMerged(item.id)}><Text style={styles.title}>{item.address}</Text><Text style={styles.text}>{(item.sourceDates?.length?item.sourceDates:[item.billDate]).join('、')}\n运费 {formatMoney(item.freightCents)}　上楼 {formatMoney(item.upstairsCents)}\n合计 {formatMoney(item.totalCents)}　来源 {item.rawRowCount} 行</Text></Pressable>} />}
  </View>;
}
const styles=StyleSheet.create({root:{flex:1,backgroundColor:colors.background},content:{padding:14,paddingBottom:40},card:{padding:15,backgroundColor:'#fff',borderRadius:14,marginBottom:12,borderWidth:1,borderColor:colors.border},title:{fontSize:18,color:colors.text,fontWeight:'800'},text:{fontSize:16,color:colors.text,lineHeight:25,marginTop:8},button:{padding:15,backgroundColor:colors.primary,borderRadius:12,marginVertical:7,alignItems:'center'},buttonText:{fontSize:17,fontWeight:'800',color:'#fff'}});
