import DateTimePicker, { DateTimePickerEvent } from '@react-native-community/datetimepicker';
import { Ionicons } from '@expo/vector-icons';
import { useEffect, useMemo, useState } from 'react';
import { Alert, Image, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { AppHeader } from '../components/AppHeader';
import { addEntry, deleteEntry, getEntry, getSuggestedTripNo, updateEntry } from '../db/database';
import { takeReceiptPhoto, pickReceiptPhoto } from '../services/photos';
import { colors } from '../theme';
import type { LedgerEntryDraft } from '../types';
import { formatChineseDate, parseYmd, todayYmd, toYmd } from '../utils/date';
import { centsToYuan, formatMoney, yuanToCents } from '../utils/money';

type Props = { entryId?: number; onBack: () => void; onSaved: (recordDate: string) => void };

export function EntryFormScreen({ entryId, onBack, onSaved }: Props) {
  const db = useSQLiteContext();
  const editing = typeof entryId === 'number';
  const [recordDate, setRecordDate] = useState(todayYmd());
  const [billDate, setBillDate] = useState(todayYmd());
  const [tripNo, setTripNo] = useState(1);
  const [address, setAddress] = useState('');
  const [freight, setFreight] = useState('');
  const [upstairs, setUpstairs] = useState('');
  const [upstairsNote, setUpstairsNote] = useState('');
  const [note, setNote] = useState('');
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [datePickerTarget, setDatePickerTarget] = useState<'record' | 'bill' | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let active = true;
    (async () => {
      if (editing && entryId) {
        const entry = await getEntry(db, entryId);
        if (!active || !entry) return;
        setRecordDate(entry.recordDate);
        setBillDate(entry.billDate);
        setTripNo(entry.tripNo);
        setAddress(entry.address);
        setFreight(centsToYuan(entry.freightCents));
        setUpstairs(centsToYuan(entry.upstairsCents));
        setUpstairsNote(entry.upstairsNote ?? '');
        setNote(entry.note ?? '');
        setPhotoUri(entry.photoUri);
      } else {
        const today = todayYmd();
        setRecordDate(today);
        setBillDate(today);
        setTripNo(await getSuggestedTripNo(db, today));
      }
    })();
    return () => { active = false; };
  }, [db, editing, entryId]);

  const freightCents = useMemo(() => yuanToCents(freight), [freight]);
  const upstairsCents = useMemo(() => yuanToCents(upstairs), [upstairs]);
  const total = freightCents + upstairsCents;

  const save = async () => {
    if (!address.trim()) {
      Alert.alert('还没填地址', '地址是必填项，请先填写送货地址。');
      return;
    }
    if (tripNo < 1) {
      Alert.alert('趟次不正确', '第几趟必须从 1 开始。');
      return;
    }
    setSaving(true);
    const draft: LedgerEntryDraft = {
      recordDate,
      billDate,
      tripNo,
      address: address.trim(),
      freightCents,
      upstairsCents,
      upstairsNote: upstairsNote || null,
      photoUri,
      note: note || null,
    };
    try {
      if (editing && entryId) await updateEntry(db, entryId, draft);
      else await addEntry(db, draft);
      onSaved(recordDate);
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = () => {
    if (!editing || !entryId) return;
    Alert.alert('删除这张单？', '删除后这条账目会从本机账本中移除。', [
      { text: '取消', style: 'cancel' },
      { text: '确认删除', style: 'destructive', onPress: async () => { await deleteEntry(db, entryId); onSaved(recordDate); } },
    ]);
  };

  const onDateChange = (_event: DateTimePickerEvent, date?: Date) => {
    const target = datePickerTarget;
    if (Platform.OS !== 'ios') setDatePickerTarget(null);
    if (date && target === 'record') setRecordDate(toYmd(date));
    if (date && target === 'bill') setBillDate(toYmd(date));
  };

  const choosePhoto = () => {
    Alert.alert('添加货单照片', '选择照片来源', [
      { text: '拍照', onPress: async () => { const uri = await takeReceiptPhoto(); if (uri) setPhotoUri(uri); } },
      { text: '从相册选择', onPress: async () => { const uri = await pickReceiptPhoto(); if (uri) setPhotoUri(uri); } },
      { text: '取消', style: 'cancel' },
    ]);
  };

  return (
    <View style={styles.root}>
      <AppHeader title={editing ? '修改一单' : '记一单'} onBack={onBack} />
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <FieldLabel text="实际日期 / 工作日期" />
          <Pressable style={styles.inputLike} onPress={() => setDatePickerTarget('record')}>
            <Text style={styles.inputLikeText}>{formatChineseDate(recordDate, true)}</Text>
            <Ionicons name="calendar-outline" size={22} color={colors.primaryDark} />
          </Pressable>
          <Text style={styles.dateHint}>默认今天，也可以选择任意需要补录的历史工作日期。首页分组和统计会按这里更新。</Text>

          <FieldLabel text="单子日期" />
          <Pressable style={styles.inputLike} onPress={() => setDatePickerTarget('bill')}>
            <Text style={styles.inputLikeText}>{formatChineseDate(billDate, true)}</Text>
            <Ionicons name="calendar-outline" size={22} color={colors.primaryDark} />
          </Pressable>
          {datePickerTarget ? <DateTimePicker value={parseYmd(datePickerTarget === 'record' ? recordDate : billDate)} mode="date" display="default" onChange={onDateChange} /> : null}

          <FieldLabel text="第几趟" />
          <View style={styles.stepper}>
            <Pressable style={styles.stepButton} onPress={() => setTripNo((v) => Math.max(1, v - 1))}><Text style={styles.stepText}>−</Text></Pressable>
            <Text style={styles.tripValue}>第 {tripNo} 趟</Text>
            <Pressable style={styles.stepButton} onPress={() => setTripNo((v) => v + 1)}><Text style={styles.stepText}>＋</Text></Pressable>
          </View>

          <FieldLabel text="地址（必填）" />
          <TextInput style={[styles.input, styles.multiline]} value={address} onChangeText={setAddress} placeholder="请输入送货地址，例如：晨月园1805" placeholderTextColor="#A1AAB7" multiline />

          <View style={styles.moneyPair}>
            <View style={styles.moneyField}><FieldLabel text="运费（元）" /><TextInput style={styles.input} value={freight} onChangeText={setFreight} keyboardType="decimal-pad" placeholder="0" /></View>
            <View style={styles.moneyField}><FieldLabel text="上楼费（元）" /><TextInput style={styles.input} value={upstairs} onChangeText={setUpstairs} keyboardType="decimal-pad" placeholder="0" /></View>
          </View>

          <FieldLabel text="上楼费备注（选填）" />
          <TextInput style={styles.input} value={upstairsNote} onChangeText={setUpstairsNote} placeholder="有异议或特殊情况可写这里" placeholderTextColor="#A1AAB7" />

          <View style={styles.totalBox}>
            <Text style={styles.totalLabel}>合计（自动计算）</Text>
            <Text style={styles.totalValue}>{formatMoney(total)}</Text>
          </View>

          <FieldLabel text="货单照片（选填）" />
          <Pressable style={styles.photoBox} onPress={choosePhoto}>
            {photoUri ? <Image source={{ uri: photoUri }} style={styles.photo} /> : <><Ionicons name="camera-outline" size={32} color={colors.primary} /><Text style={styles.photoText}>拍照或从相册选择</Text></>}
          </Pressable>

          <FieldLabel text="整单备注（选填）" />
          <TextInput style={[styles.input, styles.note]} value={note} onChangeText={setNote} placeholder="其他特殊情况" placeholderTextColor="#A1AAB7" multiline />

          <Pressable style={[styles.saveButton, saving && styles.disabled]} onPress={save} disabled={saving}>
            <Text style={styles.saveText}>{saving ? '正在保存…' : editing ? '保存修改' : '保存这张单'}</Text>
          </Pressable>

          {editing ? <Pressable style={styles.deleteButton} onPress={confirmDelete}><Text style={styles.deleteText}>删除这张单</Text></Pressable> : null}
          <View style={{ height: 30 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

function FieldLabel({ text }: { text: string }) {
  return <Text style={styles.label}>{text}</Text>;
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  flex: { flex: 1 },
  content: { padding: 14 },
  readOnlyBox: { backgroundColor: '#EAF5FF', borderRadius: 14, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: '#CDE7FF' },
  readOnlyLabel: { fontSize: 13, color: '#53708F', fontWeight: '700' },
  readOnlyValue: { marginTop: 3, fontSize: 18, color: colors.primaryDark, fontWeight: '900' },
  readOnlyHint: { marginTop: 4, fontSize: 12, color: '#6E839A', lineHeight: 18 },
  dateHint: { marginTop: 5, color: colors.muted, fontSize: 12, lineHeight: 18 },
  label: { marginTop: 12, marginBottom: 6, fontSize: 15, color: colors.text, fontWeight: '800' },
  input: { minHeight: 50, backgroundColor: '#fff', borderRadius: 12, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 13, fontSize: 17, color: colors.text },
  multiline: { minHeight: 78, paddingTop: 12, textAlignVertical: 'top' },
  note: { minHeight: 70, paddingTop: 12, textAlignVertical: 'top' },
  inputLike: { minHeight: 52, backgroundColor: '#fff', borderRadius: 12, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  inputLikeText: { fontSize: 17, color: colors.text, fontWeight: '700' },
  stepper: { backgroundColor: '#fff', height: 54, borderRadius: 12, borderWidth: 1, borderColor: colors.border, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  stepButton: { width: 64, height: '100%', alignItems: 'center', justifyContent: 'center' },
  stepText: { color: colors.primary, fontSize: 28, fontWeight: '800' },
  tripValue: { fontSize: 18, color: colors.text, fontWeight: '900' },
  moneyPair: { flexDirection: 'row', gap: 10 },
  moneyField: { flex: 1 },
  totalBox: { marginTop: 16, backgroundColor: '#fff', borderRadius: 14, padding: 15, borderWidth: 1, borderColor: colors.border, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  totalLabel: { fontSize: 16, fontWeight: '800', color: colors.text },
  totalValue: { fontSize: 25, fontWeight: '900', color: colors.primaryDark },
  photoBox: { minHeight: 120, backgroundColor: '#fff', borderRadius: 14, borderWidth: 1, borderStyle: 'dashed', borderColor: '#A9CFF3', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  photo: { width: '100%', height: 220, resizeMode: 'contain', backgroundColor: '#F5F7FA' },
  photoText: { marginTop: 7, color: colors.primaryDark, fontSize: 15, fontWeight: '700' },
  saveButton: { marginTop: 20, height: 58, backgroundColor: colors.primary, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  saveText: { color: '#fff', fontSize: 20, fontWeight: '900' },
  disabled: { opacity: 0.55 },
  deleteButton: { marginTop: 12, height: 50, borderRadius: 13, borderWidth: 1, borderColor: '#F1B7B9', alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFF7F7' },
  deleteText: { color: colors.danger, fontSize: 16, fontWeight: '800' },
});
