import { Ionicons } from '@expo/vector-icons';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, FlatList, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import * as ScreenOrientation from 'expo-screen-orientation';
import { AppHeader } from '../components/AppHeader';
import { CompanyRawCompactRow, CompanyRawTableHeader } from '../components/CompanyRawCompactRow';
import {
  addCompanyRawRow, addParsedRowsToImportBatch, confirmCompanyImportBatch, createCompanyImportBatch,
  addCompanyPhoto,
  deleteCompanyBatch, deleteCompanyImportBatch, deleteCompanyRawRow, getCompanyBatch, getCompanyImportBatch,
  getCompanyImportBatches, getCompanyRawRows, getCompanyRawRowsForImportBatch, updateCompanyBatchPeriod,
  updateCompanyRawRow,
} from '../db/database';
import { parsePastedCompanyTable } from '../services/companyTableParser';
import { pickCompanyBillPhotos, takeCompanyBillPhoto } from '../services/companyPhotos';
import { recognizeCompanyBill } from '../services/ocr';
import { pickAndParseCompanyFile } from '../services/companyFileImport';
import { colors } from '../theme';
import type { CompanyBatch, CompanyImportBatch, CompanyRawRow } from '../types';
import { centsToYuan, formatMoney, yuanToCents } from '../utils/money';

type Mode = { kind: 'detail' } | { kind: 'paste' } | { kind: 'review'; importBatchId: number } |
  { kind: 'success'; importBatchId: number } | { kind: 'all' } | { kind: 'fileSummary'; importBatchId: number; fileName: string; errors: string[] };

export function CompanyAccountScreen({ batchId, onBack, onStartMerge }: { batchId: number; onBack: () => void; onStartMerge: () => void }) {
  const db = useSQLiteContext();
  const [account, setAccount] = useState<CompanyBatch | null>(null);
  const [imports, setImports] = useState<CompanyImportBatch[]>([]);
  const [mode, setMode] = useState<Mode>({ kind: 'detail' });
  const [pasteText, setPasteText] = useState('');
  const [rows, setRows] = useState<CompanyRawRow[]>([]);
  const [currentImport, setCurrentImport] = useState<CompanyImportBatch | null>(null);
  const [busy, setBusy] = useState(false);
  const [editingRow, setEditingRow] = useState<CompanyRawRow | null>(null);
  const [periodDraft, setPeriodDraft] = useState('');
  const [landscape, setLandscape] = useState(false);

  const loadAccount = useCallback(async () => {
    const next = await getCompanyBatch(db, batchId);
    setAccount(next);
    if (next) setPeriodDraft(next.period);
    setImports(await getCompanyImportBatches(db, batchId));
  }, [db, batchId]);
  useEffect(() => { void loadAccount(); }, [loadAccount]);
  useEffect(() => () => { void ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP); }, []);

  const openReview = useCallback(async (importBatchId: number) => {
    setCurrentImport(await getCompanyImportBatch(db, importBatchId));
    setRows(await getCompanyRawRowsForImportBatch(db, importBatchId));
    setMode({ kind: 'review', importBatchId });
  }, [db]);

  const openAll = async () => {
    setRows(await getCompanyRawRows(db, batchId));
    setMode({ kind: 'all' });
  };

  const parsePaste = async () => {
    if (!pasteText.trim()) { Alert.alert('请先粘贴表格', '把识别工具输出的一整批表格复制到文本框。'); return; }
    if (pasteText.length > 100000) { Alert.alert('内容太长', '单批最多支持 100,000 个字符，请分批粘贴。'); return; }
    const parsed = parsePastedCompanyTable(pasteText, account?.period ?? '');
    if (!parsed.rows.length) {
      Alert.alert('没有识别到数据行', '请保留表格列分隔符。支持竖线、Tab 或多个空格分隔，列顺序应为：序号、编号、地址、姓名、数值1、数值2、合计。');
      return;
    }
    setBusy(true);
    try {
      const importBatchId = await createCompanyImportBatch(db, batchId, 'paste', pasteText);
      await addParsedRowsToImportBatch(db, batchId, importBatchId, parsed.rows);
      await loadAccount();
      if (parsed.skippedLines > 0) Alert.alert('解析完成', `识别 ${parsed.rows.length} 条；另有 ${parsed.skippedLines} 行未识别，请在预览页与纸质表逐行核对。`);
      await openReview(importBatchId);
      setPasteText('');
    } finally { setBusy(false); }
  };

  const importPhoto = () => Alert.alert('拍照识别', '识别后会立即进入本批核对，不会直接合并。', [
    { text: '拍照', onPress: async () => { const uri = await takeCompanyBillPhoto(); if (uri) await recognizePhoto(uri); } },
    { text: '从相册选择', onPress: async () => { const uris = await pickCompanyBillPhotos(); const uri = uris[0]; if (uri) await recognizePhoto(uri); } },
    { text: '取消', style: 'cancel' },
  ]);

  const recognizePhoto = async (uri: string) => {
    setBusy(true);
    try {
      const importBatchId = await createCompanyImportBatch(db, batchId, 'photo', null);
      await addCompanyPhoto(db, batchId, uri);
      const result = await recognizeCompanyBill(uri, account?.period ?? '');
      if (!result.configured || !result.rows.length) {
        await deleteCompanyImportBatch(db, importBatchId);
        Alert.alert('没有识别到表格', result.message || '建议改用豆包识别后粘贴表格。');
        await loadAccount();
        return;
      }
      await addParsedRowsToImportBatch(db, batchId, importBatchId, result.rows.map((row) => ({
        originalSequence: '', orderCode: '', recipientName: '', ...row,
      })));
      await loadAccount();
      await openReview(importBatchId);
    } catch (error) {
      Alert.alert('识别失败', error instanceof Error ? error.message : '请改用粘贴表格。');
    } finally { setBusy(false); }
  };

  const importFile = async () => {
    setBusy(true);
    try {
      const result = await pickAndParseCompanyFile(account?.period ?? '');
      if (!result) return;
      if (!result.rows.length) { Alert.alert('文件无法导入', result.errors.join('\n') || '没有读取到记录。'); return; }
      const importBatchId = await createCompanyImportBatch(db, batchId, 'file', result.name);
      await addParsedRowsToImportBatch(db, batchId, importBatchId, result.rows);
      await loadAccount();
      if (result.errors.length) Alert.alert('文件已读取，请重点核对', result.errors.join('\n'));
      await openReview(importBatchId);
    } catch (error) { Alert.alert('文件读取失败', error instanceof Error ? error.message : '请检查文件格式。'); }
    finally { setBusy(false); }
  };

  const persistRows = async () => { for (const row of rows) await updateCompanyRawRow(db, row); };
  const confirmImport = async () => {
    if (!currentImport) return;
    if (!rows.length || rows.some((row) => !row.address.trim())) { Alert.alert('还有空内容', '本批至少要有一条记录，且地址不能为空。'); return; }
    setBusy(true);
    try {
      await persistRows();
      await confirmCompanyImportBatch(db, currentImport.id);
      await loadAccount();
      setCurrentImport(await getCompanyImportBatch(db, currentImport.id));
      setMode({ kind: 'success', importBatchId: currentImport.id });
    } finally { setBusy(false); }
  };

  const addRow = async () => {
    if (!currentImport) return;
    await persistRows();
    await addCompanyRawRow(db, {
      batchId, importBatchId: currentImport.id, photoId: null, sourceRowNo: rows.length + 1,
      originalSequence: '', orderCode: '', recipientName: '', billDate: '', address: '',
      freightCents: 0, upstairsCents: 0, totalCents: 0, confidence: null,
    });
    await openReview(currentImport.id);
  };

  const removeImport = (item: CompanyImportBatch) => Alert.alert(
    `删除第${item.batchNo}批？`, '本批的原始明细会被删除，其他批次不受影响。此操作无法撤销。',
    [{ text: '取消', style: 'cancel' }, { text: '确认删除', style: 'destructive', onPress: async () => { await deleteCompanyImportBatch(db, item.id); await loadAccount(); } }],
  );

  const savePeriod = async () => {
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(periodDraft)) { Alert.alert('月份格式不正确', '请输入例如 2026-09。'); return; }
    await updateCompanyBatchPeriod(db, batchId, periodDraft);
    await loadAccount();
    Alert.alert('已保存', '公司账月份已经保存，退出和重启后仍会保留。');
  };

  const saveEditingRow = async () => {
    if (!editingRow) return;
    const next = { ...editingRow, totalCents: editingRow.freightCents + editingRow.upstairsCents };
    await updateCompanyRawRow(db, next);
    setRows((all) => all.map((row) => row.id === next.id ? next : row));
    setEditingRow(null);
  };

  const toggleOrientation = async () => {
    const next = !landscape;
    await ScreenOrientation.lockAsync(next ? ScreenOrientation.OrientationLock.LANDSCAPE : ScreenOrientation.OrientationLock.PORTRAIT_UP);
    setLandscape(next);
  };

  const leaveReview = async () => {
    await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
    setLandscape(false); await loadAccount(); setMode({ kind: 'detail' });
  };

  if (!account) return <View style={styles.root}><AppHeader title="公司账" onBack={onBack} /></View>;

  if (mode.kind === 'paste') return (
    <View style={styles.root}>
      <AppHeader title="添加新批次" onBack={() => setMode({ kind: 'detail' })} />
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <View style={styles.hero}><Ionicons name="clipboard-outline" size={30} color={colors.primaryDark} /><View style={styles.flex}><Text style={styles.heroTitle}>粘贴表格</Text><Text style={styles.heroText}>将豆包或其他识别工具输出的表格内容完整复制并粘贴到这里。</Text></View></View>
        <TextInput style={styles.pasteBox} value={pasteText} onChangeText={setPasteText} multiline textAlignVertical="top" maxLength={100000} placeholder={'序号 | 编号 | 地址 | 姓名 | 数值1 | 数值2 | 合计\n184 | XH-0052-26-08-08-0019 | 石景山区… | 崔宗仁 | 0 | 126.8 | 126.8'} placeholderTextColor="#94A2B2" />
        <Text style={styles.counter}>{pasteText.length.toLocaleString()} / 100,000 字符</Text>
        <Pressable style={[styles.primaryButton, busy && styles.disabled]} onPress={parsePaste} disabled={busy}><Text style={styles.primaryText}>{busy ? '正在解析…' : '解析表格并立即核对'}</Text></Pressable>
        <Text style={styles.sectionTitle}>其他录入方式</Text>
        <View style={styles.otherMethods}><Method icon="document-attach-outline" label="上传 Excel/CSV" onPress={importFile} /><Method icon="camera-outline" label="拍照识别" onPress={importPhoto} /><Method icon="create-outline" label="手动输入" onPress={async () => { const id = await createCompanyImportBatch(db, batchId, 'manual', null); await loadAccount(); await openReview(id); }} /></View>
        <Text style={styles.smallHint}>推荐使用粘贴表格，准确率更高。拍照识别后仍必须逐行人工核对。</Text>
      </ScrollView>
    </View>
  );

  if (mode.kind === 'review') return <View style={styles.root}>
    <AppHeader title={`第${currentImport?.batchNo ?? ''}批 - 预览与编辑`} onBack={() => { void leaveReview(); }} />
    <FlatList data={rows} keyExtractor={(row) => String(row.id)} renderItem={({ item }) => <CompanyRawCompactRow row={item} onEdit={setEditingRow} />}
      ListHeaderComponent={<><View style={styles.infoCard}><View style={styles.orientationLine}><View style={styles.flex}><Text style={styles.infoBig}>共 {rows.length} 条记录</Text><Text style={styles.infoText}>点击日期、地址或金额所在行即可修改；合计自动计算，0 元记录会保留。</Text></View><Pressable style={styles.orientationButton} onPress={toggleOrientation}><Ionicons name={landscape ? 'phone-portrait-outline' : 'phone-landscape-outline'} size={21} color={colors.primaryDark} /><Text style={styles.orientationText}>{landscape ? '返回竖屏' : '横屏查看'}</Text></Pressable></View></View><CompanyRawTableHeader /></>}
      ListFooterComponent={<View style={styles.listFooter}><Pressable style={styles.outlineButton} onPress={addRow}><Text style={styles.outlineText}>＋ 新增一行</Text></Pressable><Pressable style={[styles.primaryButton, busy && styles.disabled]} onPress={confirmImport} disabled={busy}><Text style={styles.primaryText}>确认本批核对无误</Text></Pressable></View>}
      contentContainerStyle={styles.listContent} initialNumToRender={14} maxToRenderPerBatch={12} windowSize={7} removeClippedSubviews keyboardShouldPersistTaps="handled" />
    <RowEditModal row={editingRow} onChange={setEditingRow} onSave={saveEditingRow} onClose={() => setEditingRow(null)} onDelete={() => editingRow && Alert.alert('删除这一行？', '只删除本批这一条原始记录。', [{ text: '取消' }, { text: '删除', style: 'destructive', onPress: async () => { await deleteCompanyRawRow(db, editingRow.id); setEditingRow(null); await openReview(mode.importBatchId); } }])} />
  </View>;

  if (mode.kind === 'success') return (
    <View style={styles.root}><AppHeader title="本批核对完成" onBack={() => setMode({ kind: 'detail' })} /><ScrollView contentContainerStyle={styles.content}>
      <View style={styles.success}><Ionicons name="checkmark-circle" size={54} color={colors.success} /><Text style={styles.successTitle}>第{currentImport?.batchNo}批 已核对完成</Text><Text style={styles.successText}>本批记录：{currentImport?.rowCount ?? rows.length} 条</Text><Text style={styles.successText}>本批金额：{formatMoney(currentImport?.totalCents ?? 0)}</Text></View>
      <Pressable style={styles.outlineButton} onPress={() => currentImport && openReview(currentImport.id)}><Text style={styles.outlineText}>查看本批明细</Text></Pressable>
      <Pressable style={styles.primaryButton} onPress={() => setMode({ kind: 'paste' })}><Text style={styles.primaryText}>继续添加下一批</Text></Pressable>
      <Pressable style={styles.linkButton} onPress={() => setMode({ kind: 'detail' })}><Text style={styles.linkText}>返回公司账详情</Text></Pressable>
    </ScrollView></View>
  );

  if (mode.kind === 'all') return <View style={styles.root}><AppHeader title="全部原始明细" onBack={() => setMode({ kind: 'detail' })} /><FlatList data={rows} keyExtractor={(row) => String(row.id)} renderItem={({ item }) => <CompanyRawCompactRow row={item} batchNo={imports.find((entry) => entry.id === item.importBatchId)?.batchNo} />}
    ListHeaderComponent={<><View style={styles.infoCard}><Text style={styles.infoBig}>共 {rows.length} 条原始记录</Text><Text style={styles.infoText}>这里只组合显示，不会合并或删除任何记录。</Text></View><CompanyRawTableHeader /></>}
    contentContainerStyle={styles.listContent} initialNumToRender={16} maxToRenderPerBatch={14} windowSize={7} removeClippedSubviews /></View>;

  if (mode.kind === 'fileSummary') {
    const freight = rows.reduce((sum, row) => sum + row.freightCents, 0), upstairs = rows.reduce((sum, row) => sum + row.upstairsCents, 0);
    const dates = rows.map((row) => row.billDate).filter(Boolean).sort();
    return <View style={styles.root}><AppHeader title="导入摘要" onBack={() => setMode({ kind: 'detail' })} /><ScrollView contentContainerStyle={styles.content}>
      <View style={styles.success}><Ionicons name="document-text-outline" size={48} color={colors.primaryDark} /><Text style={styles.successTitle}>{mode.fileName}</Text><Text style={styles.successText}>读取记录：{rows.length} 条</Text><Text style={styles.successText}>日期范围：{dates.length ? `${dates[0]} ～ ${dates[dates.length - 1]}` : '文件未提供日期'}</Text><Text style={styles.successText}>运费：{formatMoney(freight)}　上楼费：{formatMoney(upstairs)}</Text><Text style={styles.successText}>总金额：{formatMoney(freight + upstairs)}</Text></View>
      {mode.errors.length ? <View style={styles.warning}><Text style={styles.pending}>请先检查</Text><Text style={styles.infoText}>{mode.errors.join('\n')}</Text></View> : null}
      <Pressable style={styles.outlineButton} onPress={() => openReview(mode.importBatchId)}><Text style={styles.outlineText}>查看全部明细</Text></Pressable>
      <Pressable style={[styles.primaryButton, mode.errors.length > 0 && styles.disabled]} disabled={mode.errors.length > 0} onPress={async () => { await confirmCompanyImportBatch(db, mode.importBatchId); await loadAccount(); setMode({ kind: 'success', importBatchId: mode.importBatchId }); }}><Text style={styles.primaryText}>确认导入</Text></Pressable>
    </ScrollView></View>;
  }

  const allConfirmed = imports.length > 0 && imports.every((item) => item.status === 'confirmed');
  return (
    <View style={styles.root}><AppHeader title="公司账详情" onBack={onBack} /><ScrollView contentContainerStyle={styles.content}>
      <View style={styles.periodRow}><TextInput style={styles.periodInput} value={periodDraft} onChangeText={setPeriodDraft} placeholder="2026-09" /><Pressable style={styles.periodSave} onPress={savePeriod}><Text style={styles.periodSaveText}>保存月份</Text></Pressable></View>
      <Text style={styles.accountTitle}>{account.period.replace('-', '年')}月 公司账</Text><Text style={styles.statusText}>{account.status === 'merged' ? '已合并' : '进行中'}</Text>
      <View style={styles.stats}><Stat label="已添加批次" value={`${imports.length}`} /><Stat label="原始记录" value={`${account.rawRowCount}`} /><Stat label="原始金额" value={formatMoney(account.totalCents)} /></View>
      <Text style={styles.sectionTitle}>原始明细批次</Text>
      {imports.length === 0 ? <View style={styles.empty}><Text style={styles.infoText}>还没有批次。添加一批后即可立即核对或确认。</Text></View> : imports.map((item) => <View key={item.id} style={styles.batchCard}><Pressable style={styles.flex} onPress={() => openReview(item.id)}><Text style={styles.batchTitle}>第{item.batchNo}批</Text><Text style={styles.batchMeta}>{item.rowCount}条　{formatMoney(item.totalCents)}</Text><Text style={item.status === 'confirmed' ? styles.checked : styles.pending}>{item.status === 'confirmed' ? '✓ 已核对' : '待核对'}</Text></Pressable><Pressable onPress={() => openReview(item.id)}><Text style={styles.action}>查看 / 编辑</Text></Pressable><Pressable onPress={() => removeImport(item)}><Text style={styles.delete}>删除</Text></Pressable></View>)}
      <Pressable style={styles.primaryButton} onPress={() => setMode({ kind: 'paste' })}><Text style={styles.primaryText}>＋ 添加新批次</Text></Pressable>
      <Pressable style={styles.outlineButton} onPress={openAll}><Text style={styles.outlineText}>查看全部原始明细</Text></Pressable>
      <Pressable style={[styles.mergeButton, !allConfirmed && styles.disabled]} onPress={() => allConfirmed ? onStartMerge() : Alert.alert('暂时不能合并', '还有未核对的原始批次，请先完成核对。')}><Text style={styles.primaryText}>{account.status === 'merged' ? '查看合并结果 / 重新合并' : '开始合并'}</Text></Pressable>
      <Pressable style={styles.deleteAccountButton} onPress={() => Alert.alert(`删除 ${account.period} 这份公司账？`, `包含 ${imports.length} 个批次、${account.rawRowCount} 条原始记录。删除后无法恢复。只会删除当前这一份，同月份其他公司账不受影响。`, [{ text: '取消', style: 'cancel' }, { text: '确认删除整份', style: 'destructive', onPress: async () => { await deleteCompanyBatch(db, batchId); onBack(); } }])}><Text style={styles.deleteAccountText}>删除这份公司账</Text></Pressable>
    </ScrollView></View>
  );
}

function Stat({ label, value }: { label: string; value: string }) { return <View style={styles.stat}><Text style={styles.statValue}>{value}</Text><Text style={styles.statLabel}>{label}</Text></View>; }
function Method({ icon, label, onPress }: { icon: keyof typeof Ionicons.glyphMap; label: string; onPress?: () => void }) { return <Pressable style={styles.method} onPress={onPress}><Ionicons name={icon} size={24} color={colors.primaryDark} /><Text style={styles.methodText}>{label}</Text></Pressable>; }

function RowEditModal({ row, onChange, onSave, onClose, onDelete }: { row: CompanyRawRow | null; onChange: (row: CompanyRawRow | null) => void; onSave: () => void; onClose: () => void; onDelete: () => void }) {
  if (!row) return null;
  const money = (key: 'freightCents' | 'upstairsCents', text: string) => onChange({ ...row, [key]: yuanToCents(text) });
  return <Modal visible transparent animationType="slide" onRequestClose={onClose}><KeyboardAvoidingView style={styles.modalShade} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}><View style={styles.modalCard}>
    <Text style={styles.modalTitle}>修改第 {row.sourceRowNo} 行</Text>
    <Text style={styles.editLabel}>日期</Text><TextInput style={styles.editInput} value={row.billDate} onChangeText={(billDate) => onChange({ ...row, billDate })} placeholder="2026-09-18" />
    <Text style={styles.editLabel}>完整地址 / 工地</Text><TextInput style={[styles.editInput, styles.editAddress]} value={row.address} onChangeText={(address) => onChange({ ...row, address })} multiline autoFocus />
    <View style={styles.moneyRow}><View style={styles.flex}><Text style={styles.editLabel}>运费</Text><TextInput style={styles.editInput} value={centsToYuan(row.freightCents)} onChangeText={(text) => money('freightCents', text)} keyboardType="decimal-pad" /></View><View style={styles.flex}><Text style={styles.editLabel}>上楼费</Text><TextInput style={styles.editInput} value={centsToYuan(row.upstairsCents)} onChangeText={(text) => money('upstairsCents', text)} keyboardType="decimal-pad" /></View></View>
    <Text style={styles.autoTotal}>合计（自动）：{formatMoney(row.freightCents + row.upstairsCents)}</Text>
    <Pressable style={styles.primaryButton} onPress={onSave}><Text style={styles.primaryText}>保存这一行</Text></Pressable>
    <View style={styles.modalActions}><Pressable onPress={onClose}><Text style={styles.linkText}>取消</Text></Pressable><Pressable onPress={onDelete}><Text style={styles.delete}>删除此行</Text></Pressable></View>
  </View></KeyboardAvoidingView></Modal>;
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background }, content: { padding: 14, paddingBottom: 44 }, listContent: { padding: 10, paddingBottom: 44 }, listFooter: { paddingBottom: 20 }, flex: { flex: 1 },
  hero: { backgroundColor: '#EAF5FF', borderRadius: 15, borderWidth: 1, borderColor: '#CBE5FC', padding: 14, flexDirection: 'row', gap: 11 }, heroTitle: { fontSize: 20, color: colors.primaryDark, fontWeight: '900' }, heroText: { marginTop: 5, color: '#496B88', lineHeight: 21, fontWeight: '700' },
  pasteBox: { marginTop: 14, minHeight: 270, maxHeight: 520, backgroundColor: '#fff', borderRadius: 14, borderWidth: 1.5, borderColor: '#A9CFF3', padding: 13, fontSize: 16, color: colors.text, lineHeight: 23 }, counter: { color: colors.muted, textAlign: 'right', marginTop: 5 },
  primaryButton: { marginTop: 14, minHeight: 57, borderRadius: 15, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 10 }, mergeButton: { marginTop: 12, minHeight: 57, borderRadius: 15, backgroundColor: '#176DC1', alignItems: 'center', justifyContent: 'center' }, primaryText: { color: '#fff', fontSize: 17, fontWeight: '900', textAlign: 'center' }, disabled: { opacity: 0.45 },
  sectionTitle: { marginTop: 21, marginBottom: 9, color: colors.text, fontSize: 19, fontWeight: '900' }, otherMethods: { flexDirection: 'row', gap: 8 }, method: { flex: 1, backgroundColor: '#fff', borderWidth: 1, borderColor: colors.border, borderRadius: 13, paddingVertical: 14, alignItems: 'center', gap: 5 }, methodText: { color: colors.text, fontWeight: '800', fontSize: 12 }, smallHint: { marginTop: 9, color: colors.muted, lineHeight: 19 },
  infoCard: { backgroundColor: '#EAF5FF', borderRadius: 14, padding: 14, marginBottom: 13 }, infoBig: { color: colors.primaryDark, fontSize: 19, fontWeight: '900' }, infoText: { color: '#587087', lineHeight: 21, marginTop: 4 },
  outlineButton: { marginTop: 12, minHeight: 52, borderRadius: 14, borderWidth: 1.3, borderColor: colors.primary, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' }, outlineText: { color: colors.primaryDark, fontWeight: '900', fontSize: 16 }, linkButton: { minHeight: 48, alignItems: 'center', justifyContent: 'center' }, linkText: { color: colors.primaryDark, fontWeight: '900' },
  success: { backgroundColor: '#fff', borderRadius: 18, borderWidth: 1, borderColor: colors.border, padding: 28, alignItems: 'center' }, successTitle: { marginTop: 10, color: colors.text, fontSize: 22, fontWeight: '900' }, successText: { marginTop: 8, color: colors.muted, fontSize: 16 }, batchSource: { color: colors.primaryDark, fontWeight: '900', marginBottom: 5 },
  periodInput: { alignSelf: 'flex-start', backgroundColor: '#fff', borderWidth: 1, borderColor: colors.border, borderRadius: 10, paddingHorizontal: 10, minHeight: 42, minWidth: 130, color: colors.text, fontWeight: '800' }, accountTitle: { marginTop: 12, color: colors.text, fontSize: 23, fontWeight: '900' }, statusText: { color: '#9A6500', fontWeight: '800', marginTop: 3 }, stats: { flexDirection: 'row', gap: 8, marginTop: 13 }, stat: { flex: 1, backgroundColor: '#fff', borderWidth: 1, borderColor: colors.border, borderRadius: 13, padding: 10, alignItems: 'center' }, statValue: { color: colors.text, fontWeight: '900', fontSize: 17 }, statLabel: { color: colors.muted, marginTop: 3, fontSize: 11 },
  batchCard: { backgroundColor: '#fff', borderRadius: 15, borderWidth: 1, borderColor: colors.border, padding: 13, marginBottom: 9, flexDirection: 'row', alignItems: 'center', gap: 10 }, batchTitle: { color: colors.text, fontSize: 17, fontWeight: '900' }, batchMeta: { color: colors.muted, marginTop: 3 }, checked: { color: colors.success, fontWeight: '900', marginTop: 4 }, pending: { color: '#9A6500', fontWeight: '900', marginTop: 4 }, action: { color: colors.primaryDark, fontWeight: '800', fontSize: 12 }, delete: { color: colors.danger, fontWeight: '800', fontSize: 12 }, empty: { backgroundColor: '#fff', borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: 18 },
  periodRow: { flexDirection: 'row', alignItems: 'center', gap: 8 }, periodSave: { minHeight: 42, borderRadius: 10, backgroundColor: colors.primary, paddingHorizontal: 14, alignItems: 'center', justifyContent: 'center' }, periodSaveText: { color: '#fff', fontWeight: '900' },
  warning: { marginTop: 12, padding: 13, borderRadius: 12, backgroundColor: '#FFF4DA' },
  modalShade: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(10,25,40,0.42)' }, modalCard: { backgroundColor: '#fff', borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 18, paddingBottom: 28 }, modalTitle: { fontSize: 20, fontWeight: '900', color: colors.text }, editLabel: { marginTop: 10, marginBottom: 5, color: colors.text, fontWeight: '800' }, editInput: { minHeight: 46, borderWidth: 1, borderColor: colors.border, borderRadius: 10, paddingHorizontal: 11, fontSize: 16, color: colors.text, backgroundColor: '#FAFCFE' }, editAddress: { minHeight: 78, paddingTop: 10, textAlignVertical: 'top' }, moneyRow: { flexDirection: 'row', gap: 10 }, autoTotal: { marginTop: 13, fontSize: 18, color: colors.primaryDark, fontWeight: '900' }, modalActions: { flexDirection: 'row', justifyContent: 'space-around', paddingTop: 18 },
  deleteAccountButton: { marginTop: 28, minHeight: 48, alignItems: 'center', justifyContent: 'center' }, deleteAccountText: { color: colors.danger, fontWeight: '800' },
  orientationLine: { flexDirection: 'row', gap: 10, alignItems: 'center' }, orientationButton: { minWidth: 92, minHeight: 44, borderRadius: 10, borderWidth: 1, borderColor: '#A9CFF3', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 8 }, orientationText: { color: colors.primaryDark, fontWeight: '900', fontSize: 12, marginTop: 2 },
});
