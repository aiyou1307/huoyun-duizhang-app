import { Ionicons } from '@expo/vector-icons';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { AppHeader } from '../components/AppHeader';
import { CompanyRawRowEditor } from '../components/CompanyRawRowEditor';
import {
  addCompanyRawRow, addParsedRowsToImportBatch, confirmCompanyImportBatch, createCompanyImportBatch,
  deleteCompanyImportBatch, deleteCompanyRawRow, getCompanyBatch, getCompanyImportBatch,
  getCompanyImportBatches, getCompanyRawRows, getCompanyRawRowsForImportBatch, updateCompanyBatchPeriod,
  updateCompanyRawRow,
} from '../db/database';
import { parsePastedCompanyTable } from '../services/companyTableParser';
import { colors } from '../theme';
import type { CompanyBatch, CompanyImportBatch, CompanyRawRow } from '../types';
import { formatMoney } from '../utils/money';

type Mode = { kind: 'detail' } | { kind: 'paste' } | { kind: 'review'; importBatchId: number } |
  { kind: 'success'; importBatchId: number } | { kind: 'all' };

export function CompanyAccountScreen({ batchId, onBack, onStartMerge }: { batchId: number; onBack: () => void; onStartMerge: () => void }) {
  const db = useSQLiteContext();
  const [account, setAccount] = useState<CompanyBatch | null>(null);
  const [imports, setImports] = useState<CompanyImportBatch[]>([]);
  const [mode, setMode] = useState<Mode>({ kind: 'detail' });
  const [pasteText, setPasteText] = useState('');
  const [rows, setRows] = useState<CompanyRawRow[]>([]);
  const [currentImport, setCurrentImport] = useState<CompanyImportBatch | null>(null);
  const [busy, setBusy] = useState(false);

  const loadAccount = useCallback(async () => {
    setAccount(await getCompanyBatch(db, batchId));
    setImports(await getCompanyImportBatches(db, batchId));
  }, [db, batchId]);
  useEffect(() => { void loadAccount(); }, [loadAccount]);

  const openReview = useCallback(async (importBatchId: number) => {
    setCurrentImport(await getCompanyImportBatch(db, importBatchId));
    setRows(await getCompanyRawRowsForImportBatch(db, importBatchId));
    setMode({ kind: 'review', importBatchId });
  }, [db]);

  const openAll = async () => {
    setRows(await getCompanyRawRows(db, batchId));
    setMode({ kind: 'all' });
  };

  const parsePaste = async () => {
    if (!pasteText.trim()) { Alert.alert('请先粘贴表格', '把豆包输出的一整张 A4 表格复制到文本框。'); return; }
    if (pasteText.length > 100000) { Alert.alert('内容太长', '单批最多支持 100,000 个字符，建议按每张 A4 分批粘贴。'); return; }
    const parsed = parsePastedCompanyTable(pasteText, account?.period ?? '');
    if (!parsed.rows.length) {
      Alert.alert('没有识别到数据行', '请保留表格列分隔符。支持竖线、Tab 或多个空格分隔，列顺序应为：序号、编号、地址、姓名、数值1、数值2、合计。');
      return;
    }
    setBusy(true);
    try {
      const importBatchId = await createCompanyImportBatch(db, batchId, 'paste', pasteText);
      await addParsedRowsToImportBatch(db, batchId, importBatchId, parsed.rows);
      await loadAccount();
      if (parsed.skippedLines > 0) Alert.alert('解析完成', `识别 ${parsed.rows.length} 条；另有 ${parsed.skippedLines} 行未识别，请在预览页与纸质表逐行核对。`);
      await openReview(importBatchId);
      setPasteText('');
    } finally { setBusy(false); }
  };

  const persistRows = async () => { for (const row of rows) await updateCompanyRawRow(db, row); };
  const confirmImport = async () => {
    if (!currentImport) return;
    if (!rows.length || rows.some((row) => !row.address.trim())) { Alert.alert('还有空内容', '本批至少要有一条记录，且地址不能为空。'); return; }
    setBusy(true);
    try {
      await persistRows();
      await confirmCompanyImportBatch(db, currentImport.id);
      await loadAccount();
      setCurrentImport(await getCompanyImportBatch(db, currentImport.id));
      setMode({ kind: 'success', importBatchId: currentImport.id });
    } finally { setBusy(false); }
  };

  const addRow = async () => {
    if (!currentImport) return;
    await persistRows();
    await addCompanyRawRow(db, {
      batchId, importBatchId: currentImport.id, photoId: null, sourceRowNo: rows.length + 1,
      originalSequence: '', orderCode: '', recipientName: '', billDate: '', address: '',
      freightCents: 0, upstairsCents: 0, totalCents: 0, confidence: null,
    });
    await openReview(currentImport.id);
  };

  const removeImport = (item: CompanyImportBatch) => Alert.alert(
    `删除第${item.batchNo}批？`, '本批的原始明细会被删除，其他批次不受影响。此操作无法撤销。',
    [{ text: '取消', style: 'cancel' }, { text: '确认删除', style: 'destructive', onPress: async () => { await deleteCompanyImportBatch(db, item.id); await loadAccount(); } }],
  );

  if (!account) return <View style={styles.root}><AppHeader title="公司账" onBack={onBack} /></View>;

  if (mode.kind === 'paste') return (
    <View style={styles.root}>
      <AppHeader title="添加新批次" onBack={() => setMode({ kind: 'detail' })} />
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <View style={styles.hero}><Ionicons name="clipboard-outline" size={30} color={colors.primaryDark} /><View style={styles.flex}><Text style={styles.heroTitle}>粘贴表格</Text><Text style={styles.heroText}>将豆包识别后的表格内容完整复制并粘贴到这里。每张 A4 建议单独作为一批。</Text></View></View>
        <TextInput style={styles.pasteBox} value={pasteText} onChangeText={setPasteText} multiline textAlignVertical="top" maxLength={100000} placeholder={'序号 | 编号 | 地址 | 姓名 | 数值1 | 数值2 | 合计\n184 | XH-0052-26-08-08-0019 | 石景山区… | 崔宗仁 | 0 | 126.8 | 126.8'} placeholderTextColor="#94A2B2" />
        <Text style={styles.counter}>{pasteText.length.toLocaleString()} / 100,000 字符</Text>
        <Pressable style={[styles.primaryButton, busy && styles.disabled]} onPress={parsePaste} disabled={busy}><Text style={styles.primaryText}>{busy ? '正在解析…' : '解析表格并立即核对'}</Text></Pressable>
        <Text style={styles.sectionTitle}>其他录入方式</Text>
        <View style={styles.otherMethods}><Method icon="document-attach-outline" label="Excel / CSV" /><Method icon="camera-outline" label="拍照识别" /><Method icon="create-outline" label="手动输入" onPress={async () => { const id = await createCompanyImportBatch(db, batchId, 'manual', null); await loadAccount(); await openReview(id); }} /></View>
        <Text style={styles.smallHint}>当前版本优先优化“粘贴表格”。拍照识别仍保留在旧数据兼容流程中；Excel / CSV 后续可继续扩展。</Text>
      </ScrollView>
    </View>
  );

  if (mode.kind === 'review') return (
    <View style={styles.root}>
      <AppHeader title={`第${currentImport?.batchNo ?? ''}批 - 预览与编辑`} onBack={() => { void persistRows().then(() => { void loadAccount(); setMode({ kind: 'detail' }); }); }} />
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <View style={styles.infoCard}><Text style={styles.infoBig}>共识别 {rows.length} 条记录</Text><Text style={styles.infoText}>拿着本张纸质 A4 逐行查看；发现错误直接点击字段修改。0 元记录会保留。</Text></View>
        {rows.map((row) => <CompanyRawRowEditor key={row.id} row={row} onChange={(next) => setRows((all) => all.map((item) => item.id === next.id ? next : item))} onCommit={updateCompanyRawRow.bind(null, db)} onDelete={() => Alert.alert('删除这一行？', '只删除本批这一条原始记录。', [{ text: '取消' }, { text: '删除', style: 'destructive', onPress: async () => { await deleteCompanyRawRow(db, row.id); await openReview(mode.importBatchId); } }])} />)}
        <Pressable style={styles.outlineButton} onPress={addRow}><Text style={styles.outlineText}>＋ 新增一行</Text></Pressable>
        <Pressable style={[styles.primaryButton, busy && styles.disabled]} onPress={confirmImport} disabled={busy}><Text style={styles.primaryText}>确认本批核对无误</Text></Pressable>
      </ScrollView>
    </View>
  );

  if (mode.kind === 'success') return (
    <View style={styles.root}><AppHeader title="本批核对完成" onBack={() => setMode({ kind: 'detail' })} /><ScrollView contentContainerStyle={styles.content}>
      <View style={styles.success}><Ionicons name="checkmark-circle" size={54} color={colors.success} /><Text style={styles.successTitle}>第{currentImport?.batchNo}批 已核对完成</Text><Text style={styles.successText}>本批记录：{currentImport?.rowCount ?? rows.length} 条</Text><Text style={styles.successText}>本批金额：{formatMoney(currentImport?.totalCents ?? 0)}</Text></View>
      <Pressable style={styles.outlineButton} onPress={() => currentImport && openReview(currentImport.id)}><Text style={styles.outlineText}>查看本批明细</Text></Pressable>
      <Pressable style={styles.primaryButton} onPress={() => setMode({ kind: 'paste' })}><Text style={styles.primaryText}>继续添加下一批</Text></Pressable>
      <Pressable style={styles.linkButton} onPress={() => setMode({ kind: 'detail' })}><Text style={styles.linkText}>返回公司账详情</Text></Pressable>
    </ScrollView></View>
  );

  if (mode.kind === 'all') return (
    <View style={styles.root}><AppHeader title="全部原始明细" onBack={() => setMode({ kind: 'detail' })} /><ScrollView contentContainerStyle={styles.content}>
      <View style={styles.infoCard}><Text style={styles.infoBig}>共 {rows.length} 条原始记录</Text><Text style={styles.infoText}>这里只组合显示，不会合并或删除任何记录。</Text></View>
      {rows.map((row) => { const item = imports.find((entry) => entry.id === row.importBatchId); return <View key={row.id}><Text style={styles.batchSource}>来自第 {item?.batchNo ?? 1} 批</Text><CompanyRawRowEditor row={row} onChange={() => undefined} onCommit={() => undefined} onDelete={() => undefined} /></View>; })}
    </ScrollView></View>
  );

  const allConfirmed = imports.length > 0 && imports.every((item) => item.status === 'confirmed');
  return (
    <View style={styles.root}><AppHeader title="公司账详情" onBack={onBack} /><ScrollView contentContainerStyle={styles.content}>
      <TextInput style={styles.periodInput} value={account.period} onChangeText={(period) => setAccount({ ...account, period })} onEndEditing={async () => updateCompanyBatchPeriod(db, batchId, account.period)} />
      <Text style={styles.accountTitle}>{account.period.replace('-', '年')}月 公司账</Text><Text style={styles.statusText}>{account.status === 'merged' ? '已合并' : '进行中'}</Text>
      <View style={styles.stats}><Stat label="已添加批次" value={`${imports.length}`} /><Stat label="原始记录" value={`${account.rawRowCount}`} /><Stat label="原始金额" value={formatMoney(account.totalCents)} /></View>
      <Text style={styles.sectionTitle}>原始明细批次</Text>
      {imports.length === 0 ? <View style={styles.empty}><Text style={styles.infoText}>还没有批次。每张 A4 单独添加、立即核对。</Text></View> : imports.map((item) => <View key={item.id} style={styles.batchCard}><Pressable style={styles.flex} onPress={() => openReview(item.id)}><Text style={styles.batchTitle}>第{item.batchNo}批</Text><Text style={styles.batchMeta}>{item.rowCount}条　{formatMoney(item.totalCents)}</Text><Text style={item.status === 'confirmed' ? styles.checked : styles.pending}>{item.status === 'confirmed' ? '✓ 已核对' : '待核对'}</Text></Pressable><Pressable onPress={() => openReview(item.id)}><Text style={styles.action}>查看 / 编辑</Text></Pressable><Pressable onPress={() => removeImport(item)}><Text style={styles.delete}>删除</Text></Pressable></View>)}
      <Pressable style={styles.primaryButton} onPress={() => setMode({ kind: 'paste' })}><Text style={styles.primaryText}>＋ 添加新批次（导入下一张A4）</Text></Pressable>
      <Pressable style={styles.outlineButton} onPress={openAll}><Text style={styles.outlineText}>查看全部原始明细</Text></Pressable>
      <Pressable style={[styles.mergeButton, !allConfirmed && styles.disabled]} onPress={() => allConfirmed ? onStartMerge() : Alert.alert('暂时不能合并', '还有未核对的原始批次，请先完成核对。')}><Text style={styles.primaryText}>{account.status === 'merged' ? '查看合并结果 / 重新合并' : '开始合并'}</Text></Pressable>
    </ScrollView></View>
  );
}

function Stat({ label, value }: { label: string; value: string }) { return <View style={styles.stat}><Text style={styles.statValue}>{value}</Text><Text style={styles.statLabel}>{label}</Text></View>; }
function Method({ icon, label, onPress }: { icon: keyof typeof Ionicons.glyphMap; label: string; onPress?: () => void }) { return <Pressable style={styles.method} onPress={onPress}><Ionicons name={icon} size={24} color={colors.primaryDark} /><Text style={styles.methodText}>{label}</Text></Pressable>; }

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background }, content: { padding: 14, paddingBottom: 44 }, flex: { flex: 1 },
  hero: { backgroundColor: '#EAF5FF', borderRadius: 15, borderWidth: 1, borderColor: '#CBE5FC', padding: 14, flexDirection: 'row', gap: 11 }, heroTitle: { fontSize: 20, color: colors.primaryDark, fontWeight: '900' }, heroText: { marginTop: 5, color: '#496B88', lineHeight: 21, fontWeight: '700' },
  pasteBox: { marginTop: 14, minHeight: 270, maxHeight: 520, backgroundColor: '#fff', borderRadius: 14, borderWidth: 1.5, borderColor: '#A9CFF3', padding: 13, fontSize: 16, color: colors.text, lineHeight: 23 }, counter: { color: colors.muted, textAlign: 'right', marginTop: 5 },
  primaryButton: { marginTop: 14, minHeight: 57, borderRadius: 15, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 10 }, mergeButton: { marginTop: 12, minHeight: 57, borderRadius: 15, backgroundColor: '#176DC1', alignItems: 'center', justifyContent: 'center' }, primaryText: { color: '#fff', fontSize: 17, fontWeight: '900', textAlign: 'center' }, disabled: { opacity: 0.45 },
  sectionTitle: { marginTop: 21, marginBottom: 9, color: colors.text, fontSize: 19, fontWeight: '900' }, otherMethods: { flexDirection: 'row', gap: 8 }, method: { flex: 1, backgroundColor: '#fff', borderWidth: 1, borderColor: colors.border, borderRadius: 13, paddingVertical: 14, alignItems: 'center', gap: 5 }, methodText: { color: colors.text, fontWeight: '800', fontSize: 12 }, smallHint: { marginTop: 9, color: colors.muted, lineHeight: 19 },
  infoCard: { backgroundColor: '#EAF5FF', borderRadius: 14, padding: 14, marginBottom: 13 }, infoBig: { color: colors.primaryDark, fontSize: 19, fontWeight: '900' }, infoText: { color: '#587087', lineHeight: 21, marginTop: 4 },
  outlineButton: { marginTop: 12, minHeight: 52, borderRadius: 14, borderWidth: 1.3, borderColor: colors.primary, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' }, outlineText: { color: colors.primaryDark, fontWeight: '900', fontSize: 16 }, linkButton: { minHeight: 48, alignItems: 'center', justifyContent: 'center' }, linkText: { color: colors.primaryDark, fontWeight: '900' },
  success: { backgroundColor: '#fff', borderRadius: 18, borderWidth: 1, borderColor: colors.border, padding: 28, alignItems: 'center' }, successTitle: { marginTop: 10, color: colors.text, fontSize: 22, fontWeight: '900' }, successText: { marginTop: 8, color: colors.muted, fontSize: 16 }, batchSource: { color: colors.primaryDark, fontWeight: '900', marginBottom: 5 },
  periodInput: { alignSelf: 'flex-start', backgroundColor: '#fff', borderWidth: 1, borderColor: colors.border, borderRadius: 10, paddingHorizontal: 10, minHeight: 42, minWidth: 130, color: colors.text, fontWeight: '800' }, accountTitle: { marginTop: 12, color: colors.text, fontSize: 23, fontWeight: '900' }, statusText: { color: '#9A6500', fontWeight: '800', marginTop: 3 }, stats: { flexDirection: 'row', gap: 8, marginTop: 13 }, stat: { flex: 1, backgroundColor: '#fff', borderWidth: 1, borderColor: colors.border, borderRadius: 13, padding: 10, alignItems: 'center' }, statValue: { color: colors.text, fontWeight: '900', fontSize: 17 }, statLabel: { color: colors.muted, marginTop: 3, fontSize: 11 },
  batchCard: { backgroundColor: '#fff', borderRadius: 15, borderWidth: 1, borderColor: colors.border, padding: 13, marginBottom: 9, flexDirection: 'row', alignItems: 'center', gap: 10 }, batchTitle: { color: colors.text, fontSize: 17, fontWeight: '900' }, batchMeta: { color: colors.muted, marginTop: 3 }, checked: { color: colors.success, fontWeight: '900', marginTop: 4 }, pending: { color: '#9A6500', fontWeight: '900', marginTop: 4 }, action: { color: colors.primaryDark, fontWeight: '800', fontSize: 12 }, delete: { color: colors.danger, fontWeight: '800', fontSize: 12 }, empty: { backgroundColor: '#fff', borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: 18 },
});
