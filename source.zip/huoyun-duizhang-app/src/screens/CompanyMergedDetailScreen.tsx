import { useCallback, useEffect, useState } from 'react';
import { Image, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { AppHeader } from '../components/AppHeader';
import { getCompanyMergedRows, getCompanyPhotos, getCompanyRawRowsByIds } from '../db/database';
import { colors } from '../theme';
import type { CompanyMergedRow, CompanyPhoto, CompanyRawRow } from '../types';
import { formatMoney } from '../utils/money';

export function CompanyMergedDetailScreen({ batchId, mergedId, onBack }: { batchId: number; mergedId: number; onBack: () => void }) {
  const db = useSQLiteContext();
  const [merged, setMerged] = useState<CompanyMergedRow | null>(null);
  const [rawRows, setRawRows] = useState<CompanyRawRow[]>([]);
  const [photos, setPhotos] = useState<CompanyPhoto[]>([]);

  const load = useCallback(async () => {
    const rows = await getCompanyMergedRows(db, batchId);
    const item = rows.find((row) => row.id === mergedId) ?? null;
    setMerged(item);
    setRawRows(item ? await getCompanyRawRowsByIds(db, item.rawRowIds) : []);
    setPhotos(await getCompanyPhotos(db, batchId));
  }, [db, batchId, mergedId]);
  useEffect(() => { void load(); }, [load]);

  return (
    <View style={styles.root}>
      <AppHeader title="公司账追溯" onBack={onBack} />
      <ScrollView contentContainerStyle={styles.content}>
        {merged ? (
          <>
            <View style={styles.summary}>
              <Text style={styles.date}>{merged.billDate}</Text>
              <Text style={styles.address}>{merged.address}</Text>
              <Text style={styles.total}>{formatMoney(merged.totalCents)}</Text>
              <Text style={styles.sub}>运费 {formatMoney(merged.freightCents)}　上楼 {formatMoney(merged.upstairsCents)}</Text>
              <Text style={styles.sub}>由下面 {merged.rawRowCount} 行公司原始明细合并而成</Text>
            </View>

            <Text style={styles.sectionTitle}>合并前原始行</Text>
            {rawRows.map((row) => (
              <View key={row.id} style={styles.rawCard}>
                <Text style={styles.rowNo}>第 {row.sourceRowNo} 行 · {row.billDate}</Text>
                <Text style={styles.rawAddress}>{row.address}</Text>
                <Text style={styles.rawMoney}>运费 {formatMoney(row.freightCents)}　上楼 {formatMoney(row.upstairsCents)}　合计 {formatMoney(row.totalCents)}</Text>
              </View>
            ))}

            <Text style={styles.sectionTitle}>公司原始照片</Text>
            {photos.map((photo) => <Image key={photo.id} source={{ uri: photo.uri }} style={styles.photo} />)}
          </>
        ) : null}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background }, content: { padding: 14, paddingBottom: 40 },
  summary: { backgroundColor: '#fff', borderRadius: 16, borderWidth: 1, borderColor: colors.border, padding: 16 },
  date: { color: colors.primaryDark, fontWeight: '900' }, address: { marginTop: 5, color: colors.text, fontSize: 18, fontWeight: '900' }, total: { marginTop: 10, color: colors.primaryDark, fontSize: 30, fontWeight: '900' }, sub: { marginTop: 5, color: colors.muted },
  sectionTitle: { marginTop: 18, marginBottom: 8, fontSize: 18, fontWeight: '900', color: colors.text },
  rawCard: { backgroundColor: '#fff', borderRadius: 13, borderWidth: 1, borderColor: colors.border, padding: 12, marginBottom: 8 },
  rowNo: { color: '#66788C', fontWeight: '800', fontSize: 12 }, rawAddress: { marginTop: 4, color: colors.text, fontWeight: '800' }, rawMoney: { marginTop: 6, color: '#5A6C80' },
  photo: { width: '100%', height: 430, resizeMode: 'contain', backgroundColor: '#E8EDF2', borderRadius: 14, marginBottom: 12 },
});
