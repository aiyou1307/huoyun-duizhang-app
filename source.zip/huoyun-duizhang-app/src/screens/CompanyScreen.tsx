import { Ionicons } from '@expo/vector-icons';
import { useCallback, useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { AppHeader } from '../components/AppHeader';
import { createCompanyBatch, getCompanyBatches, importMergedCompanyFile } from '../db/database';
import { pickAndParseCompanyFile } from '../services/companyFileImport';
import { sumCompany } from '../utils/companyMerge';
import { colors } from '../theme';
import type { CompanyBatch } from '../types';
import { formatMoney } from '../utils/money';

function currentPeriod(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}

export function CompanyScreen({ onOpenBatch }: { onOpenBatch: (batchId: number) => void }) {
  const db = useSQLiteContext();
  const [batches, setBatches] = useState<CompanyBatch[]>([]);

  const load = useCallback(async () => setBatches(await getCompanyBatches(db)), [db]);
  useEffect(() => { void load(); }, [load]);

  const createNew = async () => {
    const batchId = await createCompanyBatch(db, currentPeriod());
    await load();
    onOpenBatch(batchId);
  };

  const importMerged = async () => {
    try {
      const file = await pickAndParseCompanyFile(currentPeriod()); if (!file) return;
      if (file.errors.length) throw new Error(file.errors.join('\n'));
      const totals = sumCompany(file.rows);
      const dates = file.rows.map(r=>r.billDate).filter(Boolean).sort();
      Alert.alert('确认导入已合并账', `月份：${file.period}\n记录：${file.rows.length} 条\n日期：${dates[0] ?? '未知'} ～ ${dates[dates.length-1] ?? '未知'}\n运费：${formatMoney(totals.freightCents)}\n上楼费：${formatMoney(totals.upstairsCents)}\n总金额：${formatMoney(totals.totalCents)}\n仅导入合并结果，不会伪造原始明细。`, [
        { text: '取消' }, { text: '确认导入', onPress: async () => { try { const id = await importMergedCompanyFile(db,file,file.name); await load(); onOpenBatch(id); } catch(e) { Alert.alert('导入未完成',String(e)); } } },
      ]);
    } catch(e) { Alert.alert('无法导入',e instanceof Error?e.message:String(e)); }
  };
  return (
    <View style={styles.root}>
      <AppHeader title="公司账" />
      <ScrollView contentContainerStyle={styles.content}>
        <Pressable style={styles.uploadButton} onPress={createNew}>
          <Ionicons name="add-circle-outline" size={34} color="#fff" />
          <View>
            <Text style={styles.uploadTitle}>＋ 新建公司账</Text>
            <Text style={styles.uploadHint}>按月份建立，一份公司账可添加多个批次</Text>
          </View>
        </Pressable>

        <Pressable style={[styles.uploadButton, { marginTop: 12 }]} onPress={importMerged}><Text style={styles.uploadTitle}>导入已合并账（Excel/CSV）</Text></Pressable>
        <View style={styles.notice}>
          <Ionicons name="shield-checkmark-outline" size={24} color={colors.primaryDark} />
          <Text style={styles.noticeText}>推荐把豆包识别出的表格直接粘贴。每批录入后立即核对，全部批次确认后再合并。</Text>
        </View>

        <Text style={styles.sectionTitle}>历史公司账</Text>
        {batches.length === 0 ? (
          <View style={styles.empty}><Text style={styles.emptyText}>还没有上传过公司账单。</Text></View>
        ) : batches.map((batch) => (
          <Pressable key={batch.id} style={styles.batchCard} onPress={() => onOpenBatch(batch.id)}>
            <View>
              <Text style={styles.period}>{batch.period.replace('-', '年')}月</Text>
              <Text style={styles.meta}>{batch.sourceName ? `已合并账导入：${batch.mergedRowCount}条` : `已导入：${batch.importBatchCount}批（${batch.rawRowCount}条）`}</Text>
              <Text style={styles.meta}>公司账金额：{formatMoney(batch.totalCents)}</Text>
            </View>
            <View style={[styles.status, batch.status === 'merged' ? styles.merged : batch.status === 'confirmed' ? styles.confirmed : styles.reviewing]}>
              <Text style={styles.statusText}>{batch.needsRemerge ? '待重新合并' : batch.status === 'merged' ? '已合并' : batch.status === 'confirmed' ? '已确认' : '待核对'}</Text>
            </View>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { padding: 14, paddingBottom: 40 },
  uploadButton: { backgroundColor: colors.primary, borderRadius: 18, padding: 18, flexDirection: 'row', alignItems: 'center', gap: 14 },
  uploadTitle: { color: '#fff', fontSize: 21, fontWeight: '900' },
  uploadHint: { color: '#DCEEFF', fontSize: 13, marginTop: 3 },
  notice: { marginTop: 12, backgroundColor: '#EAF5FF', borderRadius: 14, padding: 13, flexDirection: 'row', gap: 10, alignItems: 'flex-start', borderWidth: 1, borderColor: '#CCE6FF' },
  noticeText: { flex: 1, color: '#365979', lineHeight: 21, fontWeight: '700' },
  sectionTitle: { marginTop: 22, marginBottom: 10, fontSize: 19, fontWeight: '900', color: colors.text },
  empty: { backgroundColor: '#fff', borderRadius: 14, borderWidth: 1, borderColor: colors.border, padding: 24, alignItems: 'center' },
  emptyText: { color: colors.muted, fontSize: 15 },
  batchCard: { backgroundColor: '#fff', borderRadius: 15, borderWidth: 1, borderColor: colors.border, padding: 14, marginBottom: 10, flexDirection: 'row', alignItems: 'center', gap: 10 },
  period: { color: colors.text, fontWeight: '900', fontSize: 18 },
  meta: { color: colors.muted, marginTop: 5, fontSize: 13 },
  status: { marginLeft: 'auto', borderRadius: 999, paddingHorizontal: 10, paddingVertical: 6 },
  reviewing: { backgroundColor: '#FFF4DA' },
  confirmed: { backgroundColor: '#EAF5FF' },
  merged: { backgroundColor: '#E9F8F0' },
  statusText: { color: colors.text, fontWeight: '800', fontSize: 12 },
});
