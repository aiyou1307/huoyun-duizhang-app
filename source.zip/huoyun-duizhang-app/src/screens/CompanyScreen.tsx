import { Ionicons } from '@expo/vector-icons';
import { useCallback, useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { AppHeader } from '../components/AppHeader';
import { addCompanyPhoto, createCompanyBatch, getCompanyBatches } from '../db/database';
import { pickCompanyBillPhotos, takeCompanyBillPhoto } from '../services/companyPhotos';
import { colors } from '../theme';
import type { CompanyBatch } from '../types';

function currentPeriod(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}

export function CompanyScreen({ onOpenBatch }: { onOpenBatch: (batchId: number) => void }) {
  const db = useSQLiteContext();
  const [batches, setBatches] = useState<CompanyBatch[]>([]);

  const load = useCallback(async () => setBatches(await getCompanyBatches(db)), [db]);
  useEffect(() => { void load(); }, [load]);

  const createFromUris = async (uris: string[]) => {
    if (!uris.length) return;
    const batchId = await createCompanyBatch(db, currentPeriod());
    for (const uri of uris) await addCompanyPhoto(db, batchId, uri);
    await load();
    onOpenBatch(batchId);
  };

  const upload = () => {
    Alert.alert('上传公司账单', '可以一次上传多张。先识别核对，确认与原账单一致后才能合并。', [
      { text: '拍照', onPress: async () => { const uri = await takeCompanyBillPhoto(); if (uri) await createFromUris([uri]); } },
      { text: '从相册选择', onPress: async () => { await createFromUris(await pickCompanyBillPhotos()); } },
      { text: '取消', style: 'cancel' },
    ]);
  };

  return (
    <View style={styles.root}>
      <AppHeader title="公司账" />
      <ScrollView contentContainerStyle={styles.content}>
        <Pressable style={styles.uploadButton} onPress={upload}>
          <Ionicons name="cloud-upload-outline" size={34} color="#fff" />
          <View>
            <Text style={styles.uploadTitle}>一键上传公司账单</Text>
            <Text style={styles.uploadHint}>拍照或从相册选择，可连续多张</Text>
          </View>
        </Pressable>

        <View style={styles.notice}>
          <Ionicons name="shield-checkmark-outline" size={24} color={colors.primaryDark} />
          <Text style={styles.noticeText}>先逐行核对 OCR 结果。只有你确认“与公司原账单一致”后，系统才允许合并。</Text>
        </View>

        <Text style={styles.sectionTitle}>历史公司账</Text>
        {batches.length === 0 ? (
          <View style={styles.empty}><Text style={styles.emptyText}>还没有上传过公司账单。</Text></View>
        ) : batches.map((batch) => (
          <Pressable key={batch.id} style={styles.batchCard} onPress={() => onOpenBatch(batch.id)}>
            <View>
              <Text style={styles.period}>{batch.period.replace('-', '年')}月</Text>
              <Text style={styles.meta}>{batch.photoCount} 张原图 · {batch.rawRowCount} 行原始明细 · {batch.mergedRowCount} 条合并记录</Text>
            </View>
            <View style={[styles.status, batch.status === 'merged' ? styles.merged : batch.status === 'confirmed' ? styles.confirmed : styles.reviewing]}>
              <Text style={styles.statusText}>{batch.status === 'merged' ? '已合并' : batch.status === 'confirmed' ? '已确认' : '待核对'}</Text>
            </View>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { padding: 14, paddingBottom: 40 },
  uploadButton: { backgroundColor: colors.primary, borderRadius: 18, padding: 18, flexDirection: 'row', alignItems: 'center', gap: 14 },
  uploadTitle: { color: '#fff', fontSize: 21, fontWeight: '900' },
  uploadHint: { color: '#DCEEFF', fontSize: 13, marginTop: 3 },
  notice: { marginTop: 12, backgroundColor: '#EAF5FF', borderRadius: 14, padding: 13, flexDirection: 'row', gap: 10, alignItems: 'flex-start', borderWidth: 1, borderColor: '#CCE6FF' },
  noticeText: { flex: 1, color: '#365979', lineHeight: 21, fontWeight: '700' },
  sectionTitle: { marginTop: 22, marginBottom: 10, fontSize: 19, fontWeight: '900', color: colors.text },
  empty: { backgroundColor: '#fff', borderRadius: 14, borderWidth: 1, borderColor: colors.border, padding: 24, alignItems: 'center' },
  emptyText: { color: colors.muted, fontSize: 15 },
  batchCard: { backgroundColor: '#fff', borderRadius: 15, borderWidth: 1, borderColor: colors.border, padding: 14, marginBottom: 10, flexDirection: 'row', alignItems: 'center', gap: 10 },
  period: { color: colors.text, fontWeight: '900', fontSize: 18 },
  meta: { color: colors.muted, marginTop: 5, fontSize: 13 },
  status: { marginLeft: 'auto', borderRadius: 999, paddingHorizontal: 10, paddingVertical: 6 },
  reviewing: { backgroundColor: '#FFF4DA' },
  confirmed: { backgroundColor: '#EAF5FF' },
  merged: { backgroundColor: '#E9F8F0' },
  statusText: { color: colors.text, fontWeight: '800', fontSize: 12 },
});
