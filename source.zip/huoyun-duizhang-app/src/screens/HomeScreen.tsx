import { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { AppHeader } from '../components/AppHeader';
import { EntryCard } from '../components/EntryCard';
import { colors } from '../theme';
import type { LedgerEntry } from '../types';
import { formatChineseDate, todayYmd, weekdayChinese } from '../utils/date';
import { formatMoney } from '../utils/money';
import { getEntriesForDate } from '../db/database';

type Props = {
  selectedDate: string;
  refreshKey: number;
  onOpenDateLookup: () => void;
  onAdd: () => void;
  onEdit: (id: number) => void;
};

export function HomeScreen({ selectedDate, refreshKey, onOpenDateLookup, onAdd, onEdit }: Props) {
  const db = useSQLiteContext();
  const [entries, setEntries] = useState<LedgerEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    const next = await getEntriesForDate(db, selectedDate);
    setEntries(next);
    setLoading(false);
  }, [db, selectedDate]);

  useEffect(() => { void load(); }, [load, refreshKey]);

  const grouped = useMemo(() => {
    const groups = new Map<number, LedgerEntry[]>();
    entries.forEach((entry) => groups.set(entry.tripNo, [...(groups.get(entry.tripNo) ?? []), entry]));
    return [...groups.entries()].sort(([a], [b]) => a - b);
  }, [entries]);

  const total = entries.reduce((sum, entry) => sum + entry.freightCents + entry.upstairsCents, 0);

  return (
    <View style={styles.root}>
      <AppHeader title="我的账" rightIcon="calendar-outline" onRightPress={onOpenDateLookup} />
      <Pressable style={styles.dateBanner} onPress={onOpenDateLookup}>
        <View>
          <Text style={styles.dateText}>{formatChineseDate(selectedDate, true)} · {weekdayChinese(selectedDate)}</Text>
          <Text style={styles.dateHint}>记账日期，仅用于查找，不参与工资核算</Text>
        </View>
        <Text style={styles.dateArrow}>›</Text>
      </Pressable>

      {loading ? (
        <View style={styles.loading}><ActivityIndicator size="large" color={colors.primary} /></View>
      ) : (
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.content}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }} />}
        >
          <View style={styles.daySummary}>
            <Text style={styles.summaryText}>共 {grouped.length} 趟 · {entries.length} 单</Text>
            <Text style={styles.summaryTotal}>当天合计 {formatMoney(total)}</Text>
          </View>

          {grouped.length === 0 ? (
            <View style={styles.empty}>
              <Text style={styles.emptyTitle}>这一天还没有记录</Text>
              <Text style={styles.emptyText}>{selectedDate === todayYmd() ? '点下面“记一单”开始记账。' : '可以返回今天，或选择其他日期查看。'}</Text>
            </View>
          ) : grouped.map(([tripNo, tripEntries]) => {
            const tripTotal = tripEntries.reduce((sum, entry) => sum + entry.freightCents + entry.upstairsCents, 0);
            return (
              <View key={tripNo} style={styles.tripBlock}>
                <View style={styles.tripHeader}>
                  <Text style={styles.tripTitle}>第 {tripNo} 趟</Text>
                  <Text style={styles.tripMeta}>{tripEntries.length} 单　合计 {formatMoney(tripTotal)}</Text>
                </View>
                {tripEntries.map((entry) => <EntryCard key={entry.id} entry={entry} onPress={() => onEdit(entry.id)} />)}
              </View>
            );
          })}
          <View style={{ height: 92 }} />
        </ScrollView>
      )}

      <Pressable style={styles.addButton} onPress={onAdd}>
        <Text style={styles.addButtonText}>＋ {selectedDate === todayYmd() ? '记一单' : '记今天一单'}</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  dateBanner: { margin: 12, marginBottom: 6, paddingHorizontal: 16, paddingVertical: 12, borderRadius: 14, backgroundColor: '#DFF0FF', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  dateText: { color: colors.primaryDark, fontSize: 18, fontWeight: '900' },
  dateHint: { marginTop: 3, color: '#53708F', fontSize: 12 },
  dateArrow: { color: colors.primaryDark, fontSize: 32, fontWeight: '300' },
  scroll: { flex: 1 },
  content: { paddingHorizontal: 12, paddingTop: 6 },
  daySummary: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 4, paddingVertical: 8 },
  summaryText: { fontSize: 15, color: colors.muted, fontWeight: '700' },
  summaryTotal: { fontSize: 16, color: colors.text, fontWeight: '900' },
  tripBlock: { backgroundColor: '#fff', borderRadius: 15, overflow: 'hidden', marginBottom: 12, borderWidth: 1, borderColor: colors.border },
  tripHeader: { backgroundColor: colors.primarySoft, paddingHorizontal: 14, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  tripTitle: { color: colors.primaryDark, fontSize: 20, fontWeight: '900' },
  tripMeta: { color: '#496783', fontSize: 14, fontWeight: '700' },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  empty: { marginTop: 30, backgroundColor: '#fff', borderRadius: 16, padding: 28, alignItems: 'center', borderWidth: 1, borderColor: colors.border },
  emptyTitle: { fontSize: 20, fontWeight: '900', color: colors.text },
  emptyText: { marginTop: 8, fontSize: 15, color: colors.muted, textAlign: 'center' },
  addButton: { position: 'absolute', left: 18, right: 18, bottom: 14, height: 58, borderRadius: 16, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOpacity: 0.14, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 5 },
  addButtonText: { color: '#fff', fontSize: 22, fontWeight: '900' },
});
