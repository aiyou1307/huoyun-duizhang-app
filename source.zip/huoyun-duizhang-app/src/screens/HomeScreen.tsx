import { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Modal, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { AppHeader } from '../components/AppHeader';
import { EntryCard } from '../components/EntryCard';
import { colors } from '../theme';
import type { LedgerEntry } from '../types';
import { formatChineseDate, todayYmd, weekdayChinese } from '../utils/date';
import { formatMoney } from '../utils/money';
import { countOwnEntryImportDuplicates, getEntriesForDate, importOwnEntries } from '../db/database';
import { pickOwnLedgerFile, type OwnLedgerImport } from '../services/ownLedgerFileImport';

type Props = {
  selectedDate: string;
  refreshKey: number;
  onOpenDateLookup: () => void;
  onAdd: () => void;
  onEdit: (id: number) => void;
};

export function HomeScreen({ selectedDate, refreshKey, onOpenDateLookup, onAdd, onEdit }: Props) {
  const db = useSQLiteContext();
  const [entries, setEntries] = useState<LedgerEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [importPreview, setImportPreview] = useState<OwnLedgerImport | null>(null);
  const [importing, setImporting] = useState(false);
  const [possibleDuplicates, setPossibleDuplicates] = useState(0);

  const load = useCallback(async () => {
    const next = await getEntriesForDate(db, selectedDate);
    setEntries(next);
    setLoading(false);
  }, [db, selectedDate]);

  useEffect(() => { void load(); }, [load, refreshKey]);

  const grouped = useMemo(() => {
    const groups = new Map<number, LedgerEntry[]>();
    entries.forEach((entry) => groups.set(entry.tripNo, [...(groups.get(entry.tripNo) ?? []), entry]));
    return [...groups.entries()].sort(([a], [b]) => a - b);
  }, [entries]);

  const total = entries.reduce((sum, entry) => sum + entry.freightCents + entry.upstairsCents, 0);

  return (
    <View style={styles.root}>
      <AppHeader title="我的账" rightIcon="calendar-outline" onRightPress={onOpenDateLookup} />
      <Pressable style={styles.dateBanner} onPress={onOpenDateLookup}>
        <View>
          <Text style={styles.dateText}>{formatChineseDate(selectedDate, true)} · {weekdayChinese(selectedDate)}</Text>
          <Text style={styles.dateHint}>记账日期，仅用于查找，不参与工资核算</Text>
        </View>
        <Text style={styles.dateArrow}>›</Text>
      </Pressable>
      <Pressable style={styles.importButton} onPress={async () => { try { const preview = await pickOwnLedgerFile(); if (preview) { setPossibleDuplicates(await countOwnEntryImportDuplicates(db, preview.rows)); setImportPreview(preview); } } catch (error) { Alert.alert('无法导入', error instanceof Error ? error.message : '请检查文件。'); } }}><Text style={styles.importButtonText}>导入我的账（CSV / Excel）</Text></Pressable>

      {loading ? (
        <View style={styles.loading}><ActivityIndicator size="large" color={colors.primary} /></View>
      ) : (
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.content}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }} />}
        >
          <View style={styles.daySummary}>
            <Text style={styles.summaryText}>共 {grouped.length} 趟 · {entries.length} 单</Text>
            <Text style={styles.summaryTotal}>当天合计 {formatMoney(total)}</Text>
          </View>

          {grouped.length === 0 ? (
            <View style={styles.empty}>
              <Text style={styles.emptyTitle}>这一天还没有记录</Text>
              <Text style={styles.emptyText}>{selectedDate === todayYmd() ? '点下面“记一单”开始记账。' : '可以返回今天，或选择其他日期查看。'}</Text>
            </View>
          ) : grouped.map(([tripNo, tripEntries]) => {
            const tripTotal = tripEntries.reduce((sum, entry) => sum + entry.freightCents + entry.upstairsCents, 0);
            return (
              <View key={tripNo} style={styles.tripBlock}>
                <View style={styles.tripHeader}>
                  <Text style={styles.tripTitle}>第 {tripNo} 趟</Text>
                  <Text style={styles.tripMeta}>{tripEntries.length} 单　合计 {formatMoney(tripTotal)}</Text>
                </View>
                {tripEntries.map((entry) => <EntryCard key={entry.id} entry={entry} onPress={() => onEdit(entry.id)} />)}
              </View>
            );
          })}
          <View style={{ height: 92 }} />
        </ScrollView>
      )}

      <Pressable style={styles.addButton} onPress={onAdd}>
        <Text style={styles.addButtonText}>＋ {selectedDate === todayYmd() ? '记一单' : '记今天一单'}</Text>
      </Pressable>
      <Modal visible={Boolean(importPreview)} transparent animationType="slide" onRequestClose={() => setImportPreview(null)}><View style={styles.modalShade}><View style={styles.modalCard}><Text style={styles.modalTitle}>导入预览</Text><Text style={styles.modalFile}>{importPreview?.fileName}</Text><Text style={styles.modalStat}>共 {importPreview?.dayCount ?? 0} 天 · {importPreview?.tripCount ?? 0} 趟 · {importPreview?.rows.length ?? 0} 条</Text><Text style={styles.modalTotal}>总金额 {formatMoney(importPreview?.totalCents ?? 0)}</Text>{possibleDuplicates > 0 ? <Text style={styles.modalWarn}>发现 {possibleDuplicates} 条可能已经存在，确认后会自动跳过，不会重复记账。</Text> : null}{importPreview?.errors.length ? <Text style={styles.modalWarn}>另有 {importPreview.errors.length} 行无法解析，将不会导入。</Text> : null}<Text style={styles.modalHint}>重复判断会核对实际日期、单子日期、趟次、地址和金额。CSV/Excel 只恢复文字账目，不包含照片。</Text><Pressable style={styles.confirmImport} disabled={importing} onPress={async () => { if (!importPreview) return; setImporting(true); try { const result = await importOwnEntries(db, importPreview.rows); setImportPreview(null); await load(); Alert.alert('导入完成', `新增 ${result.inserted} 条，跳过重复 ${result.duplicates} 条。`); } finally { setImporting(false); } }}><Text style={styles.confirmImportText}>{importing ? '正在导入…' : '确认导入我的账'}</Text></Pressable><Pressable style={styles.cancelImport} onPress={() => setImportPreview(null)}><Text style={styles.cancelImportText}>取消</Text></Pressable></View></View></Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  dateBanner: { margin: 12, marginBottom: 6, paddingHorizontal: 16, paddingVertical: 12, borderRadius: 14, backgroundColor: '#DFF0FF', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  dateText: { color: colors.primaryDark, fontSize: 18, fontWeight: '900' },
  dateHint: { marginTop: 3, color: '#53708F', fontSize: 12 },
  dateArrow: { color: colors.primaryDark, fontSize: 32, fontWeight: '300' },
  importButton: { marginHorizontal: 12, marginBottom: 5, minHeight: 42, borderRadius: 11, borderWidth: 1, borderColor: colors.primary, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' }, importButtonText: { color: colors.primaryDark, fontWeight: '900' },
  scroll: { flex: 1 },
  content: { paddingHorizontal: 12, paddingTop: 6 },
  daySummary: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 4, paddingVertical: 8 },
  summaryText: { fontSize: 15, color: colors.muted, fontWeight: '700' },
  summaryTotal: { fontSize: 16, color: colors.text, fontWeight: '900' },
  tripBlock: { backgroundColor: '#fff', borderRadius: 15, overflow: 'hidden', marginBottom: 12, borderWidth: 1, borderColor: colors.border },
  tripHeader: { backgroundColor: colors.primarySoft, paddingHorizontal: 14, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  tripTitle: { color: colors.primaryDark, fontSize: 20, fontWeight: '900' },
  tripMeta: { color: '#496783', fontSize: 14, fontWeight: '700' },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  empty: { marginTop: 30, backgroundColor: '#fff', borderRadius: 16, padding: 28, alignItems: 'center', borderWidth: 1, borderColor: colors.border },
  emptyTitle: { fontSize: 20, fontWeight: '900', color: colors.text },
  emptyText: { marginTop: 8, fontSize: 15, color: colors.muted, textAlign: 'center' },
  addButton: { position: 'absolute', left: 18, right: 18, bottom: 14, height: 58, borderRadius: 16, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOpacity: 0.14, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 5 },
  addButtonText: { color: '#fff', fontSize: 22, fontWeight: '900' },
  modalShade: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(15,35,55,.45)' }, modalCard: { backgroundColor: '#fff', borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 20, paddingBottom: 30 }, modalTitle: { color: colors.text, fontSize: 22, fontWeight: '900' }, modalFile: { marginTop: 7, color: colors.muted }, modalStat: { marginTop: 18, color: colors.text, fontSize: 18, fontWeight: '900' }, modalTotal: { marginTop: 7, color: colors.primaryDark, fontSize: 24, fontWeight: '900' }, modalWarn: { marginTop: 10, color: '#9A6500', fontWeight: '800' }, modalHint: { marginTop: 13, color: colors.muted, lineHeight: 20 }, confirmImport: { marginTop: 18, height: 56, borderRadius: 14, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' }, confirmImportText: { color: '#fff', fontSize: 18, fontWeight: '900' }, cancelImport: { height: 48, alignItems: 'center', justifyContent: 'center' }, cancelImportText: { color: colors.muted, fontWeight: '800' },
});
