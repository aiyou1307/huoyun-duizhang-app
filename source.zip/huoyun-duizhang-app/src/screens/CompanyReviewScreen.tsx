import { Ionicons } from '@expo/vector-icons';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, Image, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { AppHeader } from '../components/AppHeader';
import { CompanyRawRowEditor } from '../components/CompanyRawRowEditor';
import {
  addCompanyPhoto,
  addCompanyRawRow,
  appendOcrRows,
  confirmCompanyBatch,
  deleteCompanyRawRow,
  getCompanyBatch,
  getCompanyPhotos,
  getCompanyRawRows,
  updateCompanyBatchPeriod,
  updateCompanyRawRow,
} from '../db/database';
import { pickCompanyBillPhotos, takeCompanyBillPhoto } from '../services/companyPhotos';
import { recognizeCompanyBill } from '../services/ocr';
import { colors } from '../theme';
import { normalizeBillDateInput } from '../utils/date';
import type { CompanyBatch, CompanyPhoto, CompanyRawRow } from '../types';

export function CompanyReviewScreen({
  batchId,
  onBack,
  onNext,
}: {
  batchId: number;
  onBack: () => void;
  onNext: () => void;
}) {
  const db = useSQLiteContext();
  const [batch, setBatch] = useState<CompanyBatch | null>(null);
  const [photos, setPhotos] = useState<CompanyPhoto[]>([]);
  const [rows, setRows] = useState<CompanyRawRow[]>([]);
  const [checked, setChecked] = useState(false);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setBatch(await getCompanyBatch(db, batchId));
    setPhotos(await getCompanyPhotos(db, batchId));
    setRows(await getCompanyRawRows(db, batchId));
  }, [db, batchId]);

  useEffect(() => { void load(); }, [load]);

  const hasErrors = useMemo(
    () => rows.some((row) => !row.billDate.trim() || !row.address.trim() || row.freightCents + row.upstairsCents !== row.totalCents),
    [rows],
  );

  const addPhotos = () => {
    Alert.alert('继续添加账单照片', '可以拍照，也可以从相册一次选择多张。', [
      { text: '拍照', onPress: async () => { const uri = await takeCompanyBillPhoto(); if (uri) { await addCompanyPhoto(db, batchId, uri); await load(); } } },
      { text: '从相册选择', onPress: async () => { const uris = await pickCompanyBillPhotos(); for (const uri of uris) await addCompanyPhoto(db, batchId, uri); await load(); } },
      { text: '取消', style: 'cancel' },
    ]);
  };

  const runOcr = async () => {
    if (!photos.length) return;
    await persistAllRows();
    setBusy(true);
    try {
      let total = 0;
      let unconfigured = false;
      for (const photo of photos) {
        const result = await recognizeCompanyBill(photo.uri, batch?.period ?? '');
        if (!result.configured) { unconfigured = true; break; }
        if (result.rows.length) {
          await appendOcrRows(db, batchId, photo.id, result.rows);
          total += result.rows.length;
        }
      }
      await load();
      if (unconfigured) {
        Alert.alert('OCR服务还没接上', '页面和人工核对流程已经可用。正式接入 OCR 服务后，点这里会自动填入“日期、地址、运费、上楼费、合计”。现在可以先手动添加一行测试整个流程。');
      } else {
        Alert.alert('识别完成', `共新增识别 ${total} 行。请逐行对照原图修改，确认完全一致后再进入合并。`);
      }
    } catch (error) {
      Alert.alert('识别失败', error instanceof Error ? error.message : '请稍后再试。');
    } finally {
      setBusy(false);
    }
  };

  const addManualRow = async () => {
    await persistAllRows();
    const nextNo = rows.reduce((max, row) => Math.max(max, row.sourceRowNo), 0) + 1;
    await addCompanyRawRow(db, {
      batchId,
      photoId: photos[0]?.id ?? null,
      sourceRowNo: nextNo,
      billDate: batch?.period ? `${batch.period}-01` : '',
      address: '',
      freightCents: 0,
      upstairsCents: 0,
      totalCents: 0,
      confidence: null,
    });
    await load();
  };

  const changeRow = (row: CompanyRawRow) => {
    setRows((current) => current.map((item) => item.id === row.id ? row : item));
  };

  const commitRow = async (row: CompanyRawRow) => {
    await updateCompanyRawRow(db, row);
  };

  const persistAllRows = async () => {
    for (const row of rows) await updateCompanyRawRow(db, row);
  };

  const removeRow = (row: CompanyRawRow) => {
    Alert.alert('删除这一行？', '只删除识别/录入结果，不会删除公司原始照片。', [
      { text: '取消', style: 'cancel' },
      { text: '删除', style: 'destructive', onPress: async () => { await deleteCompanyRawRow(db, row.id); await load(); } },
    ]);
  };

  const confirm = async () => {
    if (!rows.length) { Alert.alert('还没有明细', '请先识别或手动添加公司账单明细。'); return; }
    if (!checked) { Alert.alert('请先确认', '请先勾选“我已逐行核对，与公司原账单一致”。'); return; }
    if (rows.some((row) => !row.billDate.trim() || !row.address.trim())) {
      Alert.alert('还有空字段', '单子日期和地址不能为空。'); return;
    }
    const normalizedRows = rows.map((row) => {
      const normalized = normalizeBillDateInput(row.billDate, batch?.period ?? '');
      return normalized ? { ...row, billDate: normalized } : null;
    });
    if (normalizedRows.some((row) => row === null)) {
      Alert.alert('日期格式需要检查', '单子日期请填写成“2026-09-16”或“9/16”这类格式。'); return;
    }
    const finalRows = normalizedRows.filter((row): row is CompanyRawRow => row !== null);
    setRows(finalRows);
    try {
      for (const row of finalRows) await updateCompanyRawRow(db, row);
      await confirmCompanyBatch(db, batchId);
      onNext();
    } catch (error) {
      Alert.alert('无法确认', error instanceof Error ? error.message : '请检查数据。');
    }
  };

  if (!batch) return <View style={styles.root}><AppHeader title="识别结果确认" onBack={onBack} /></View>;

  return (
    <View style={styles.root}>
      <AppHeader title="识别结果确认" onBack={onBack} />
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <View style={styles.stepBar}>
          <Text style={styles.stepActive}>① 识别核对</Text><Text style={styles.stepArrow}>›</Text><Text style={styles.step}>② 确认</Text><Text style={styles.stepArrow}>›</Text><Text style={styles.step}>③ 合并</Text>
        </View>

        <Text style={styles.label}>账单月份</Text>
        <TextInput
          style={styles.periodInput}
          value={batch.period}
          onChangeText={(value) => setBatch({ ...batch, period: value })}
          onEndEditing={async () => { await updateCompanyBatchPeriod(db, batchId, batch.period); }}
          placeholder="例如：2026-09"
        />
        <Text style={styles.help}>这个月份用于确定和“我的账”里哪一个月的单子进行对账。</Text>

        <View style={styles.titleLine}>
          <Text style={styles.sectionTitle}>公司原始照片</Text>
          <Pressable onPress={addPhotos}><Text style={styles.link}>＋继续上传</Text></Pressable>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.photoStrip}>
          {photos.map((photo) => (
            <View key={photo.id} style={styles.photoWrap}>
              <Image source={{ uri: photo.uri }} style={styles.photo} />
              <Text style={styles.pageText}>第 {photo.pageNo} 页</Text>
            </View>
          ))}
        </ScrollView>

        <Pressable style={[styles.ocrButton, busy && styles.disabled]} onPress={runOcr} disabled={busy}>
          <Ionicons name="scan-outline" size={24} color="#fff" />
          <Text style={styles.ocrText}>{busy ? '正在识别…' : '自动识别这些照片'}</Text>
        </Pressable>

        <View style={styles.warningBox}>
          <Ionicons name="warning-outline" size={22} color="#9B6200" />
          <Text style={styles.warningText}>识别结果现在绝不参与合并。请先把下面每一行改到和公司纸质账单完全一致。</Text>
        </View>

        <View style={styles.titleLine}>
          <Text style={styles.sectionTitle}>逐行核对</Text>
          <Pressable onPress={addManualRow}><Text style={styles.link}>＋手动加一行</Text></Pressable>
        </View>
        {rows.length === 0 ? (
          <View style={styles.empty}><Text style={styles.emptyText}>还没有识别结果。可以点“自动识别”，或者先手动添加一行测试。</Text></View>
        ) : rows.map((row) => (
          <CompanyRawRowEditor key={row.id} row={row} onChange={changeRow} onCommit={commitRow} onDelete={() => removeRow(row)} />
        ))}

        {hasErrors ? (
          <View style={styles.checkHint}><Text style={styles.checkHintText}>黄色提醒只是帮助你找可能的错误；最终以公司原账单为准，系统不会擅自改数字。</Text></View>
        ) : null}

        <Pressable style={styles.confirmCheck} onPress={() => setChecked((value) => !value)}>
          <Ionicons name={checked ? 'checkbox' : 'square-outline'} size={28} color={checked ? colors.primary : '#7A8A9C'} />
          <Text style={styles.confirmCheckText}>我已逐行核对，以上内容与公司原账单一致</Text>
        </Pressable>

        <Pressable style={[styles.nextButton, (!checked || !rows.length) && styles.disabled]} onPress={confirm}>
          <Text style={styles.nextText}>确认无误，下一步：合并公司账</Text>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { padding: 14, paddingBottom: 40 },
  stepBar: { backgroundColor: '#fff', borderRadius: 14, padding: 12, borderWidth: 1, borderColor: colors.border, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8 },
  stepActive: { color: colors.primaryDark, fontWeight: '900' }, step: { color: '#8190A1', fontWeight: '800' }, stepArrow: { color: '#A5B1BE', fontSize: 20 },
  label: { marginTop: 16, marginBottom: 6, fontWeight: '900', color: colors.text, fontSize: 15 },
  periodInput: { backgroundColor: '#fff', borderRadius: 12, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 12, minHeight: 48, fontSize: 17, color: colors.text },
  help: { marginTop: 5, color: colors.muted, fontSize: 12, lineHeight: 18 },
  titleLine: { marginTop: 18, marginBottom: 8, flexDirection: 'row', alignItems: 'center' },
  sectionTitle: { fontSize: 18, fontWeight: '900', color: colors.text }, link: { marginLeft: 'auto', color: colors.primaryDark, fontWeight: '900' },
  photoStrip: { marginHorizontal: -2 }, photoWrap: { marginRight: 10, alignItems: 'center' },
  photo: { width: 145, height: 190, borderRadius: 12, backgroundColor: '#E8EDF2', resizeMode: 'cover' }, pageText: { marginTop: 5, color: colors.muted, fontSize: 12 },
  ocrButton: { marginTop: 12, height: 54, borderRadius: 14, backgroundColor: colors.primary, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  ocrText: { color: '#fff', fontSize: 18, fontWeight: '900' },
  warningBox: { marginTop: 12, backgroundColor: '#FFF4DA', borderRadius: 12, padding: 12, flexDirection: 'row', gap: 8, borderWidth: 1, borderColor: '#F7D68B' },
  warningText: { flex: 1, color: '#805100', lineHeight: 20, fontWeight: '700' },
  empty: { backgroundColor: '#fff', borderRadius: 14, borderWidth: 1, borderColor: colors.border, padding: 20 }, emptyText: { color: colors.muted, lineHeight: 22 },
  checkHint: { backgroundColor: '#FFF9EC', borderRadius: 12, padding: 12 }, checkHintText: { color: '#7A5A1A', lineHeight: 20 },
  confirmCheck: { marginTop: 18, backgroundColor: '#fff', borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.border, flexDirection: 'row', gap: 10, alignItems: 'center' },
  confirmCheckText: { flex: 1, color: colors.text, fontWeight: '900', lineHeight: 22 },
  nextButton: { marginTop: 14, height: 58, borderRadius: 15, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' },
  nextText: { color: '#fff', fontSize: 18, fontWeight: '900' }, disabled: { opacity: 0.45 },
});
