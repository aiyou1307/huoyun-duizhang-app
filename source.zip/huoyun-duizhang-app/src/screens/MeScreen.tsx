import { Ionicons } from '@expo/vector-icons';
import { useState } from 'react';
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { AppHeader } from '../components/AppHeader';
import { exportCompanyMergedCsv, exportFullBackup, exportOwnLedgerCsv, restoreFullBackup } from '../services/exportBackup';
import { colors } from '../theme';

export function MeScreen({ onDataRestored }: { onDataRestored: () => void }) {
  const db = useSQLiteContext();
  const [busy, setBusy] = useState<string | null>(null);

  const run = async (key: string, task: () => Promise<void>) => {
    if (busy) return;
    setBusy(key);
    try { await task(); } finally { setBusy(null); }
  };

  const exportMine = () => run('mine', async () => {
    try {
      const result = await exportOwnLedgerCsv(db);
      Alert.alert('导出完成', `已导出 ${result.rowCount} 条“我的账”。\n文件：${result.fileName}\n\n可以用 Excel 或 WPS 打开。`);
    } catch (error) {
      Alert.alert('没有导出', error instanceof Error ? error.message : '请重新选择保存位置。');
    }
  });

  const exportCompany = () => run('company', async () => {
    try {
      const result = await exportCompanyMergedCsv(db);
      Alert.alert('导出完成', `已导出 ${result.rowCount} 条公司合并账。\n文件：${result.fileName}`);
    } catch (error) {
      Alert.alert('没有导出', error instanceof Error ? error.message : '请重新选择保存位置。');
    }
  });

  const backup = () => run('backup', async () => {
    try {
      const result = await exportFullBackup(db);
      const extra = result.warnings.length ? `\n\n有 ${result.warnings.length} 个照片备份提醒，账目数据仍已备份。` : '';
      Alert.alert('完整备份完成', `备份文件：${result.manifestName}\n照片：${result.mediaCount} 张${extra}\n\n以后换手机时，选择这个备份所在的文件夹即可恢复。`);
    } catch (error) {
      Alert.alert('备份没有完成', error instanceof Error ? error.message : '请重新选择保存位置。');
    }
  });

  const restore = () => {
    Alert.alert(
      '恢复完整备份？',
      '恢复会替换当前手机里已有的账目、公司账和对账结果。建议先做一次完整备份。',
      [
        { text: '取消', style: 'cancel' },
        {
          text: '继续恢复',
          style: 'destructive',
          onPress: () => run('restore', async () => {
            try {
              const result = await restoreFullBackup(db);
              Alert.alert('恢复完成', `已从 ${result.manifestName} 恢复。\n恢复照片 ${result.mediaRestored} 张。`);
              onDataRestored();
            } catch (error) {
              Alert.alert('恢复失败', error instanceof Error ? error.message : '请选择正确的备份文件夹。');
            }
          }),
        },
      ],
    );
  };

  return (
    <View style={styles.root}>
      <AppHeader title="我的" />
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.storageCard}>
          <Ionicons name="phone-portrait-outline" size={30} color={colors.primaryDark} />
          <View style={styles.storageTextWrap}>
            <Text style={styles.storageTitle}>数据主要存在这台手机里</Text>
            <Text style={styles.storageText}>平时记账不需要登录，也不依赖网络。为了防止换手机或手机损坏，建议每月公司对账结束后做一次完整备份。</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>导出表格</Text>
        <ActionCard
          icon="document-text-outline"
          title="导出我的账 CSV"
          description="包含记账日期、单子日期、趟次、地址、运费、上楼费和合计，可用 Excel / WPS 打开。"
          onPress={exportMine}
          busy={busy === 'mine'}
        />
        <ActionCard
          icon="layers-outline"
          title="导出公司合并账 CSV"
          description="导出的是确认并合并后的公司账，不是 OCR 未确认数据。"
          onPress={exportCompany}
          busy={busy === 'company'}
        />

        <Text style={styles.sectionTitle}>备份与换手机</Text>
        <ActionCard
          icon="shield-checkmark-outline"
          title="完整备份"
          description="保存我的账、公司账、对账关系和相关照片。建议保存到手机“下载”或你自己容易找到的文件夹。"
          onPress={backup}
          busy={busy === 'backup'}
        />
        <ActionCard
          icon="cloud-download-outline"
          title="从完整备份恢复"
          description="换手机时使用。会替换当前 App 里的现有数据，操作前会再次确认。"
          onPress={restore}
          busy={busy === 'restore'}
          danger
        />

        <View style={styles.tipCard}>
          <Ionicons name="information-circle-outline" size={23} color="#7B5A16" />
          <Text style={styles.tipText}>“导出 CSV”是为了看表格；“完整备份”才是为了以后恢复 App 数据和照片。两者用途不一样。</Text>
        </View>
      </ScrollView>
      {busy ? <View style={styles.busyOverlay}><ActivityIndicator size="large" color="#fff" /><Text style={styles.busyText}>正在处理，请不要退出…</Text></View> : null}
    </View>
  );
}

function ActionCard({
  icon,
  title,
  description,
  onPress,
  busy,
  danger = false,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
  onPress: () => void;
  busy: boolean;
  danger?: boolean;
}) {
  return (
    <Pressable style={styles.actionCard} onPress={onPress} disabled={busy}>
      <View style={[styles.iconWrap, danger && styles.dangerIconWrap]}>
        <Ionicons name={icon} size={27} color={danger ? colors.danger : colors.primaryDark} />
      </View>
      <View style={styles.actionTextWrap}>
        <Text style={[styles.actionTitle, danger && styles.dangerTitle]}>{title}</Text>
        <Text style={styles.actionDescription}>{description}</Text>
      </View>
      <Ionicons name="chevron-forward" size={22} color="#8B9AAD" />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { padding: 14, paddingBottom: 40 },
  storageCard: { backgroundColor: '#EAF5FF', borderRadius: 16, borderWidth: 1, borderColor: '#CAE3FA', padding: 15, flexDirection: 'row', gap: 12, alignItems: 'flex-start' },
  storageTextWrap: { flex: 1 },
  storageTitle: { color: colors.text, fontWeight: '900', fontSize: 18 },
  storageText: { marginTop: 6, color: '#4B6580', lineHeight: 21, fontWeight: '600' },
  sectionTitle: { marginTop: 22, marginBottom: 9, color: colors.text, fontWeight: '900', fontSize: 19 },
  actionCard: { backgroundColor: '#fff', borderRadius: 15, borderWidth: 1, borderColor: colors.border, padding: 13, marginBottom: 10, flexDirection: 'row', alignItems: 'center', gap: 12 },
  iconWrap: { width: 46, height: 46, borderRadius: 13, backgroundColor: '#EAF5FF', alignItems: 'center', justifyContent: 'center' },
  dangerIconWrap: { backgroundColor: '#FFF0F0' },
  actionTextWrap: { flex: 1 },
  actionTitle: { color: colors.text, fontWeight: '900', fontSize: 16 },
  dangerTitle: { color: '#B42328' },
  actionDescription: { marginTop: 4, color: colors.muted, lineHeight: 19, fontSize: 13 },
  tipCard: { marginTop: 8, backgroundColor: '#FFF7E7', borderRadius: 13, borderWidth: 1, borderColor: '#EFD595', padding: 12, flexDirection: 'row', gap: 9 },
  tipText: { flex: 1, color: '#76551C', lineHeight: 20, fontWeight: '700' },
  busyOverlay: { position: 'absolute', top: 0, right: 0, bottom: 0, left: 0, backgroundColor: 'rgba(15, 36, 60, 0.70)', alignItems: 'center', justifyContent: 'center', gap: 12 },
  busyText: { color: '#fff', fontWeight: '900', fontSize: 16 },
});
