import { Ionicons } from '@expo/vector-icons';
import { useCallback, useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { AppHeader } from '../components/AppHeader';
import { getCompanyBatches } from '../db/database';
import { colors } from '../theme';
import type { CompanyBatch } from '../types';

export function ReconcileScreen({ onOpenBatch }: { onOpenBatch: (batchId: number) => void }) {
  const db = useSQLiteContext();
  const [batches, setBatches] = useState<CompanyBatch[]>([]);
  const load = useCallback(async () => {
    const all = await getCompanyBatches(db);
    setBatches(all.filter((batch) => batch.status === 'merged'));
  }, [db]);
  useEffect(() => { void load(); }, [load]);

  return (
    <View style={styles.root}>
      <AppHeader title="工资对账" />
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.notice}>
          <Ionicons name="information-circle-outline" size={25} color={colors.primaryDark} />
          <Text style={styles.noticeText}>这里比较的是“我的账”与公司已经确认并合并后的账。地址只负责找单，金额负责验单。</Text>
        </View>
        <Text style={styles.title}>选择一个月开始对账</Text>
        {batches.length === 0 ? (
          <View style={styles.empty}><Text style={styles.emptyTitle}>还没有可对账的公司账</Text><Text style={styles.emptyText}>先到“公司账”完成：上传 → 识别核对 → 确认 → 合并。</Text></View>
        ) : batches.map((batch) => (
          <Pressable key={batch.id} style={styles.card} onPress={() => onOpenBatch(batch.id)}>
            <View style={styles.icon}><Ionicons name="calculator-outline" size={25} color={colors.primaryDark} /></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.period}>{batch.period.replace('-', '年')}月工资对账</Text>
              <Text style={styles.meta}>{batch.mergedRowCount} 条公司合并记录</Text>
            </View>
            <Ionicons name="chevron-forward" size={24} color="#93A2B1" />
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background }, content: { padding: 14, paddingBottom: 40 },
  notice: { backgroundColor: '#EAF5FF', borderRadius: 14, borderWidth: 1, borderColor: '#CCE4F8', padding: 13, flexDirection: 'row', gap: 9 },
  noticeText: { flex: 1, color: '#3E617E', fontWeight: '700', lineHeight: 21 },
  title: { marginTop: 20, marginBottom: 9, color: colors.text, fontSize: 19, fontWeight: '900' },
  empty: { backgroundColor: '#fff', borderWidth: 1, borderColor: colors.border, borderRadius: 15, padding: 24, alignItems: 'center' },
  emptyTitle: { color: colors.text, fontWeight: '900', fontSize: 18 }, emptyText: { marginTop: 7, color: colors.muted, textAlign: 'center', lineHeight: 21 },
  card: { backgroundColor: '#fff', borderRadius: 15, borderWidth: 1, borderColor: colors.border, padding: 14, marginBottom: 10, flexDirection: 'row', alignItems: 'center', gap: 11 },
  icon: { width: 44, height: 44, borderRadius: 12, backgroundColor: '#EAF5FF', alignItems: 'center', justifyContent: 'center' },
  period: { color: colors.text, fontWeight: '900', fontSize: 17 }, meta: { marginTop: 4, color: colors.muted, fontSize: 13 },
});
