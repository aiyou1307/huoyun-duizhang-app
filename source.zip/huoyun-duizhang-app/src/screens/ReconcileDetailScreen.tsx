import { Ionicons } from '@expo/vector-icons';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { AppHeader } from '../components/AppHeader';
import {
  confirmReconciliationMatch,
  getReconciliationSnapshot,
  rejectReconciliationCandidate,
} from '../db/database';
import { colors } from '../theme';
import type { ReconciliationItem, ReconciliationKind, ReconciliationSnapshot } from '../types';
import { formatMoney } from '../utils/money';

const filters: Array<{ key: 'all' | ReconciliationKind; label: string }> = [
  { key: 'all', label: '全部' },
  { key: 'amount_anomaly', label: '金额异常' },
  { key: 'candidate', label: '疑似地址' },
  { key: 'missing_company', label: '疑似漏单' },
  { key: 'company_extra', label: '公司多出' },
  { key: 'normal', label: '正常' },
];

export function ReconcileDetailScreen({
  batchId,
  onBack,
  onOpenMerged,
}: {
  batchId: number;
  onBack: () => void;
  onOpenMerged: (mergedId: number) => void;
}) {
  const db = useSQLiteContext();
  const [snapshot, setSnapshot] = useState<ReconciliationSnapshot | null>(null);
  const [filter, setFilter] = useState<'all' | ReconciliationKind>('all');

  const load = useCallback(async () => setSnapshot(await getReconciliationSnapshot(db, batchId)), [db, batchId]);
  useEffect(() => { void load(); }, [load]);

  const visible = useMemo(() => {
    if (!snapshot) return [];
    return filter === 'all' ? snapshot.items : snapshot.items.filter((item) => item.kind === filter);
  }, [snapshot, filter]);

  const confirmCandidate = async (item: ReconciliationItem) => {
    if (!item.own || !item.company) return;
    await confirmReconciliationMatch(db, batchId, item.own.id, item.company.id);
    await load();
  };

  const rejectCandidate = (item: ReconciliationItem) => {
    if (!item.own || !item.company) return;
    Alert.alert('确认不是同一单？', '确认后系统不会再把这两条作为疑似匹配。', [
      { text: '取消', style: 'cancel' },
      { text: '不是同一单', style: 'destructive', onPress: async () => { await rejectReconciliationCandidate(db, batchId, item.own!.id, item.company!.id); await load(); } },
    ]);
  };

  if (!snapshot) return <View style={styles.root}><AppHeader title="工资对账" onBack={onBack} /></View>;

  return (
    <View style={styles.root}>
      <AppHeader title={`${snapshot.batch.period.replace('-', '年')}月对账`} onBack={onBack} />
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.summaryGrid}>
          <SummaryBox label="正常" value={snapshot.normalCount} tone="good" />
          <SummaryBox label="金额异常" value={snapshot.anomalyCount} tone="bad" />
          <SummaryBox label="疑似地址" value={snapshot.candidateCount} tone="warn" />
          <SummaryBox label="疑似漏单" value={snapshot.missingCompanyCount} tone="bad" />
          <SummaryBox label="公司多出" value={snapshot.companyExtraCount} tone="warn" />
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterStrip}>
          {filters.map((item) => (
            <Pressable key={item.key} style={[styles.chip, filter === item.key && styles.chipActive]} onPress={() => setFilter(item.key)}>
              <Text style={[styles.chipText, filter === item.key && styles.chipTextActive]}>{item.label}</Text>
            </Pressable>
          ))}
        </ScrollView>

        {visible.length === 0 ? <View style={styles.empty}><Text style={styles.emptyText}>这个分类里没有记录。</Text></View> : null}
        {visible.map((item) => (
          <ReconcileCard key={item.key} item={item} onConfirm={() => confirmCandidate(item)} onReject={() => rejectCandidate(item)} onOpenMerged={onOpenMerged} />
        ))}
      </ScrollView>
    </View>
  );
}

function SummaryBox({ label, value, tone }: { label: string; value: number; tone: 'good' | 'bad' | 'warn' }) {
  return (
    <View style={[styles.summaryBox, tone === 'good' ? styles.goodBox : tone === 'bad' ? styles.badBox : styles.warnBox]}>
      <Text style={styles.summaryValue}>{value}</Text><Text style={styles.summaryLabel}>{label}</Text>
    </View>
  );
}

function ReconcileCard({
  item,
  onConfirm,
  onReject,
  onOpenMerged,
}: {
  item: ReconciliationItem;
  onConfirm: () => void;
  onReject: () => void;
  onOpenMerged: (id: number) => void;
}) {
  const config = kindConfig(item.kind);
  return (
    <View style={[styles.itemCard, { borderColor: config.border }]}> 
      <View style={styles.itemHeader}>
        <View style={[styles.kindBadge, { backgroundColor: config.bg }]}><Text style={[styles.kindText, { color: config.text }]}>{config.label}</Text></View>
        {item.differenceCents !== null ? <Text style={styles.diff}>差额 {item.differenceCents >= 0 ? '+' : '-'}{formatMoney(Math.abs(item.differenceCents))}</Text> : null}
      </View>

      {item.own ? (
        <View style={styles.sideCard}>
          <Text style={styles.sideTitle}>我的账</Text>
          <Text style={styles.date}>{item.own.billDate}</Text>
          <Text style={styles.address}>{item.own.address}</Text>
          <Text style={styles.money}>运费 {formatMoney(item.own.freightCents)}　上楼 {formatMoney(item.own.upstairsCents)}　合计 {formatMoney(item.own.freightCents + item.own.upstairsCents)}</Text>
        </View>
      ) : null}

      {item.company ? (
        <Pressable style={styles.sideCard} onPress={() => onOpenMerged(item.company!.id)}>
          <View style={styles.companyTitleLine}><Text style={styles.sideTitle}>公司合并账</Text><Text style={styles.trace}>查看来源 ›</Text></View>
          <Text style={styles.date}>{item.company.billDate}</Text>
          <Text style={styles.address}>{item.company.address}</Text>
          <Text style={styles.money}>运费 {formatMoney(item.company.freightCents)}　上楼 {formatMoney(item.company.upstairsCents)}　合计 {formatMoney(item.company.totalCents)}</Text>
        </Pressable>
      ) : null}

      {item.kind === 'candidate' ? (
        <>
          <View style={styles.candidateHint}>
            <Ionicons name="help-circle-outline" size={21} color="#9B6200" />
            <Text style={styles.candidateHintText}>地址很相似，但系统不替你决定。请看是不是同一张单。</Text>
          </View>
          <View style={styles.actions}>
            <Pressable style={styles.rejectButton} onPress={onReject}><Text style={styles.rejectText}>不是同一单</Text></Pressable>
            <Pressable style={styles.confirmButton} onPress={onConfirm}><Text style={styles.confirmText}>确认是同一单</Text></Pressable>
          </View>
        </>
      ) : null}
    </View>
  );
}

function kindConfig(kind: ReconciliationKind) {
  if (kind === 'normal') return { label: '正常', bg: '#E9F8F0', text: '#137347', border: '#BDE4CE' };
  if (kind === 'amount_anomaly') return { label: '金额异常', bg: '#FFE9E9', text: '#B42328', border: '#F0B6B8' };
  if (kind === 'candidate') return { label: '疑似同一单', bg: '#FFF4DA', text: '#8A5700', border: '#EBC979' };
  if (kind === 'missing_company') return { label: '疑似漏单', bg: '#FFE9E9', text: '#B42328', border: '#F0B6B8' };
  return { label: '公司多出 / 待核对', bg: '#FFF4DA', text: '#8A5700', border: '#EBC979' };
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background }, content: { padding: 14, paddingBottom: 40 },
  summaryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  summaryBox: { minWidth: '30%', flexGrow: 1, borderRadius: 13, padding: 11, borderWidth: 1, alignItems: 'center' },
  goodBox: { backgroundColor: '#E9F8F0', borderColor: '#C3E8D3' }, badBox: { backgroundColor: '#FFF0F0', borderColor: '#F0C0C2' }, warnBox: { backgroundColor: '#FFF7E7', borderColor: '#EFD595' },
  summaryValue: { color: colors.text, fontSize: 22, fontWeight: '900' }, summaryLabel: { marginTop: 2, color: '#647386', fontSize: 12, fontWeight: '800' },
  filterStrip: { marginTop: 14, marginHorizontal: -2, marginBottom: 4 }, chip: { paddingHorizontal: 13, paddingVertical: 8, borderRadius: 999, backgroundColor: '#fff', borderWidth: 1, borderColor: colors.border, marginRight: 8 }, chipActive: { backgroundColor: colors.primary, borderColor: colors.primary }, chipText: { color: '#607286', fontWeight: '800' }, chipTextActive: { color: '#fff' },
  empty: { marginTop: 12, backgroundColor: '#fff', borderRadius: 14, padding: 20, borderWidth: 1, borderColor: colors.border, alignItems: 'center' }, emptyText: { color: colors.muted },
  itemCard: { marginTop: 11, backgroundColor: '#fff', borderRadius: 16, borderWidth: 1.3, padding: 13 },
  itemHeader: { flexDirection: 'row', alignItems: 'center' }, kindBadge: { borderRadius: 999, paddingHorizontal: 9, paddingVertical: 5 }, kindText: { fontWeight: '900', fontSize: 12 }, diff: { marginLeft: 'auto', color: colors.text, fontWeight: '900' },
  sideCard: { marginTop: 10, borderRadius: 12, backgroundColor: '#F8FBFE', borderWidth: 1, borderColor: '#E1EAF3', padding: 11 }, sideTitle: { color: '#5E7185', fontWeight: '900', fontSize: 13 }, companyTitleLine: { flexDirection: 'row', alignItems: 'center' }, trace: { marginLeft: 'auto', color: colors.primaryDark, fontWeight: '800', fontSize: 12 }, date: { marginTop: 5, color: colors.primaryDark, fontWeight: '900', fontSize: 13 }, address: { marginTop: 3, color: colors.text, fontWeight: '900', fontSize: 16 }, money: { marginTop: 7, color: '#596D82', lineHeight: 20, fontSize: 13 },
  candidateHint: { marginTop: 10, backgroundColor: '#FFF7E7', borderRadius: 11, padding: 10, flexDirection: 'row', gap: 7 }, candidateHintText: { flex: 1, color: '#76541A', lineHeight: 19, fontWeight: '700' },
  actions: { flexDirection: 'row', gap: 9, marginTop: 10 }, rejectButton: { flex: 1, height: 46, borderRadius: 12, borderWidth: 1, borderColor: '#D3DFEA', alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff' }, rejectText: { color: '#5D6E82', fontWeight: '900' }, confirmButton: { flex: 1, height: 46, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.primary }, confirmText: { color: '#fff', fontWeight: '900' },
});
