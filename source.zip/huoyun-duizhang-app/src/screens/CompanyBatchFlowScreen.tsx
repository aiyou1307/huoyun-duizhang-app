import { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { getCompanyBatch } from '../db/database';
import { colors } from '../theme';
import { CompanyMergeScreen } from './CompanyMergeScreen';
import { CompanyAccountScreen } from './CompanyAccountScreen';

export function CompanyBatchFlowScreen({
  batchId,
  onBack,
  onOpenMerged,
}: {
  batchId: number;
  onBack: () => void;
  onOpenMerged: (mergedId: number) => void;
}) {
  const db = useSQLiteContext();
  const [phase, setPhase] = useState<'loading' | 'review' | 'merge'>('loading');
  const load = useCallback(async () => {
    const batch = await getCompanyBatch(db, batchId);
    setPhase('review');
  }, [db, batchId]);
  useEffect(() => { void load(); }, [load]);

  if (phase === 'loading') return <View style={styles.loading}><ActivityIndicator size="large" color={colors.primary} /></View>;
  if (phase === 'review') {
    return <CompanyAccountScreen batchId={batchId} onBack={onBack} onStartMerge={() => setPhase('merge')} />;
  }
  return <CompanyMergeScreen batchId={batchId} onBack={onBack} onOpenMerged={onOpenMerged} />;
}

const styles = StyleSheet.create({ loading: { flex: 1, backgroundColor: colors.background, alignItems: 'center', justifyContent: 'center' } });
