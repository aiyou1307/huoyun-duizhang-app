import { useAndroidBack } from '../hooks/useAndroidBack';
import DateTimePicker, { DateTimePickerEvent } from '@react-native-community/datetimepicker';
import { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { AppHeader } from '../components/AppHeader';
import { getOwnLedgerSummary, type OwnLedgerSummary } from '../db/database';
import { colors } from '../theme';
import { parseYmd, toYmd } from '../utils/date';
import { formatMoney } from '../utils/money';

function monthRange(offset = 0): { start: string; end: string } {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth() + offset, 1, 12);
  const end = new Date(now.getFullYear(), now.getMonth() + offset + 1, 0, 12);
  return { start: toYmd(start), end: toYmd(end) };
}

export function OwnLedgerTotalScreen({ onBack, refreshKey }: { onBack: () => void; refreshKey: number }) {
  useAndroidBack(onBack);
  const db = useSQLiteContext();
  const initial = monthRange();
  const [startDate, setStartDate] = useState(initial.start);
  const [endDate, setEndDate] = useState(initial.end);
  const [summary, setSummary] = useState<OwnLedgerSummary | null>(null);
  const [picker, setPicker] = useState<'start' | 'end' | null>(null);

  const load = useCallback(async (start = startDate, end = endDate) => {
    setSummary(null);
    setSummary(await getOwnLedgerSummary(db, start, end));
  }, [db, startDate, endDate]);

  useEffect(() => { void load(); }, [load, refreshKey]);

  const chooseRange = async (offset: number) => {
    const next = monthRange(offset);
    setStartDate(next.start);
    setEndDate(next.end);
    await load(next.start, next.end);
  };

  const changeDate = (_event: DateTimePickerEvent, date?: Date) => {
    const target = picker;
    if (Platform.OS !== 'ios') setPicker(null);
    if (!date || !target) return;
    const value = toYmd(date);
    const nextStart = target === 'start' ? value : startDate;
    const nextEnd = target === 'end' ? value : endDate;
    if (nextStart > nextEnd) {
      if (target === 'start') setEndDate(value);
      else setStartDate(value);
      setStartDate(value);
      setEndDate(value);
      void load(value, value);
      return;
    }
    setStartDate(nextStart);
    setEndDate(nextEnd);
    void load(nextStart, nextEnd);
  };

  return (
    <View style={styles.root}>
      <AppHeader title="我的账总额" onBack={onBack} />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.help}>按实际日期（记账日期）统计，仅用于查看。</Text>
        <View style={styles.quickRow}>
          <Pressable style={styles.quickButton} onPress={() => chooseRange(0)}><Text style={styles.quickText}>本月</Text></Pressable>
          <Pressable style={styles.quickButton} onPress={() => chooseRange(-1)}><Text style={styles.quickText}>上月</Text></Pressable>
          <View style={styles.quickHint}><Text style={styles.quickHintText}>点日期可自定义</Text></View>
        </View>

        <View style={styles.dateCard}>
          <Pressable style={styles.dateButton} onPress={() => setPicker('start')}><Text style={styles.dateLabel}>开始日期</Text><Text style={styles.dateValue}>{startDate}</Text></Pressable>
          <Text style={styles.to}>至</Text>
          <Pressable style={styles.dateButton} onPress={() => setPicker('end')}><Text style={styles.dateLabel}>结束日期</Text><Text style={styles.dateValue}>{endDate}</Text></Pressable>
        </View>
        {picker ? <DateTimePicker value={parseYmd(picker === 'start' ? startDate : endDate)} mode="date" display="default" onChange={changeDate} /> : null}

        {!summary ? <ActivityIndicator style={styles.loading} size="large" color={colors.primary} /> : (
          <>
            <View style={styles.totalCard}>
              <Text style={styles.totalLabel}>我的账总额</Text>
              <Text style={styles.totalValue}>{formatMoney(summary.totalCents)}</Text>
              <Text style={styles.rangeText}>{startDate} 至 {endDate}</Text>
            </View>
            <View style={styles.grid}>
              <Stat label="共多少单" value={`${summary.entryCount} 单`} />
              <Stat label="运费总额" value={formatMoney(summary.freightCents)} />
              <Stat label="上楼费总额" value={formatMoney(summary.upstairsCents)} />
              <Stat label="总金额" value={formatMoney(summary.totalCents)} />
            </View>
          </>
        )}
      </ScrollView>
    </View>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return <View style={styles.stat}><Text style={styles.statLabel}>{label}</Text><Text style={styles.statValue}>{value}</Text></View>;
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { padding: 14, paddingBottom: 40 },
  help: { color: colors.muted, fontSize: 14, lineHeight: 20, fontWeight: '700' },
  quickRow: { flexDirection: 'row', gap: 8, marginTop: 12 },
  quickButton: { minWidth: 82, height: 44, borderRadius: 11, backgroundColor: '#E4F2FF', borderWidth: 1, borderColor: '#B9D9F5', alignItems: 'center', justifyContent: 'center' },
  quickText: { color: colors.primaryDark, fontWeight: '900', fontSize: 16 },
  quickHint: { flex: 1, height: 44, borderRadius: 11, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: colors.border },
  quickHintText: { color: colors.muted, fontWeight: '700', fontSize: 13 },
  dateCard: { marginTop: 12, backgroundColor: '#fff', borderRadius: 15, padding: 12, borderWidth: 1, borderColor: colors.border, flexDirection: 'row', alignItems: 'center', gap: 8 },
  dateButton: { flex: 1, minHeight: 62, borderRadius: 11, backgroundColor: '#F3F8FD', padding: 10, justifyContent: 'center' },
  dateLabel: { color: colors.muted, fontSize: 12, fontWeight: '700' },
  dateValue: { marginTop: 5, color: colors.primaryDark, fontSize: 16, fontWeight: '900' },
  to: { color: colors.muted, fontWeight: '800' },
  loading: { marginTop: 70 },
  totalCard: { marginTop: 16, borderRadius: 18, backgroundColor: colors.primary, paddingVertical: 25, paddingHorizontal: 18, alignItems: 'center' },
  totalLabel: { color: '#DCEEFF', fontSize: 17, fontWeight: '800' },
  totalValue: { marginTop: 7, color: '#fff', fontSize: 36, fontWeight: '900' },
  rangeText: { marginTop: 8, color: '#DCEEFF', fontSize: 13, fontWeight: '700' },
  grid: { marginTop: 13, flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  stat: { width: '48%', flexGrow: 1, minHeight: 96, borderRadius: 15, backgroundColor: '#fff', borderWidth: 1, borderColor: colors.border, padding: 14, justifyContent: 'center' },
  statLabel: { color: colors.muted, fontSize: 13, fontWeight: '700' },
  statValue: { marginTop: 7, color: colors.text, fontSize: 21, fontWeight: '900' },
});
