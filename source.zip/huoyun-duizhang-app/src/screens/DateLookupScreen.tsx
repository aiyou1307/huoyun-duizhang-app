import { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSQLiteContext } from 'expo-sqlite';
import { AppHeader } from '../components/AppHeader';
import { getDateSummaries } from '../db/database';
import { colors } from '../theme';
import type { DateSummary } from '../types';
import { formatChineseDate, weekdayChinese } from '../utils/date';
import { formatMoney } from '../utils/money';

export function DateLookupScreen({ onBack, onSelect }: { onBack: () => void; onSelect: (date: string) => void }) {
  const db = useSQLiteContext();
  const [rows, setRows] = useState<DateSummary[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setRows(await getDateSummaries(db));
    setLoading(false);
  }, [db]);

  useEffect(() => { void load(); }, [load]);

  return (
    <View style={styles.root}>
      <AppHeader title="按日期查找" onBack={onBack} />
      <View style={styles.tip}>
        <Text style={styles.tipText}>按记账日期查找（不参与工资核算）</Text>
      </View>
      {loading ? <View style={styles.loading}><ActivityIndicator size="large" color={colors.primary} /></View> : (
        <ScrollView contentContainerStyle={styles.content}>
          {rows.length === 0 ? (
            <View style={styles.empty}>
              <Text style={styles.emptyTitle}>还没有历史账目</Text>
              <Text style={styles.emptyText}>记过一单以后，这里会按日期显示当天金额、趟数和单数。</Text>
            </View>
          ) : rows.map((row) => (
            <Pressable key={row.recordDate} style={styles.row} onPress={() => onSelect(row.recordDate)}>
              <View>
                <View style={styles.dateLine}>
                  <Text style={styles.date}>{formatChineseDate(row.recordDate)}</Text>
                  <Text style={styles.weekday}>{weekdayChinese(row.recordDate)}</Text>
                </View>
                <Text style={styles.meta}>{row.tripCount} 趟　/　{row.orderCount} 单</Text>
              </View>
              <View style={styles.amountBox}>
                <Text style={styles.amountLabel}>合计</Text>
                <Text style={styles.amount}>{formatMoney(row.totalCents)}</Text>
                <Text style={styles.arrow}>›</Text>
              </View>
            </Pressable>
          ))}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  tip: { margin: 12, paddingHorizontal: 15, paddingVertical: 12, backgroundColor: '#DFF0FF', borderRadius: 14 },
  tipText: { fontSize: 15, color: colors.primaryDark, fontWeight: '800' },
  content: { paddingHorizontal: 12, paddingBottom: 24 },
  row: { minHeight: 104, backgroundColor: '#fff', borderRadius: 16, borderWidth: 1, borderColor: colors.border, marginBottom: 10, padding: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  dateLine: { flexDirection: 'row', gap: 12, alignItems: 'baseline' },
  date: { color: '#083EA8', fontSize: 25, fontWeight: '900' },
  weekday: { color: '#5A6D84', fontSize: 17, fontWeight: '700' },
  meta: { marginTop: 8, fontSize: 16, color: '#60748D', fontWeight: '700' },
  amountBox: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  amountLabel: { color: '#60748D', fontSize: 15 },
  amount: { color: '#073EA8', fontSize: 25, fontWeight: '900' },
  arrow: { color: '#60748D', fontSize: 32 },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  empty: { padding: 28, backgroundColor: '#fff', borderRadius: 16, alignItems: 'center' },
  emptyTitle: { fontSize: 20, color: colors.text, fontWeight: '900' },
  emptyText: { marginTop: 8, fontSize: 15, color: colors.muted, textAlign: 'center', lineHeight: 22 },
});
