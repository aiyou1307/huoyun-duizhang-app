export const colors = {
  primary: '#1287F5',
  primaryDark: '#075DC4',
  primarySoft: '#EAF5FF',
  background: '#F4F8FC',
  card: '#FFFFFF',
  text: '#13233A',
  muted: '#718096',
  border: '#DDE8F3',
  danger: '#E5484D',
  warning: '#F59E0B',
  success: '#1EAE68',
};
