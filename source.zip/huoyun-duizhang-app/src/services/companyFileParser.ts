import * as XLSX from 'xlsx';
import { normalizeBillDateInput } from '../utils/date';
import { parsePastedCompanyTable, type ParsedCompanyTableRow } from './companyTableParser';
export type CompanyParsedFile = { rows: ParsedCompanyTableRow[]; errors: string[]; period: string; sourceCounts: number[]; sourceDates?: string[][] };
export function parseCompanyWorkbook(workbook: XLSX.WorkBook, period: string): CompanyParsedFile {
  const sheet = workbook.Sheets[workbook.SheetNames[0] ?? ''];
  if (!sheet) throw new Error('文件中没有可读取的工作表。');
  const matrix = XLSX.utils.sheet_to_json<any[]>(sheet, { header: 1, raw: true, defval: '' });
  const headerIndex = matrix.findIndex(r => r.some(c => /地址|工地/.test(String(c))) && r.some(c => /运费|数值1/.test(String(c))));
  if (headerIndex < 0) {
    const parsed = parsePastedCompanyTable(matrix.map(r => r.join(' | ')).join('\n'), period);
    return { rows: parsed.rows, errors: parsed.skippedLines ? [`${parsed.skippedLines} 行无法解析，请检查列标题。`] : [], period, sourceCounts: parsed.rows.map(() => 0) };
  }
  const headers = matrix[headerIndex]!.map(c => String(c).replace(/\s/g, ''));
  const col = (...names: string[]) => headers.findIndex(h => names.includes(h));
  const address = col('地址', '地址/工地', '工地', '收货地址');
  const freight = col('公司运费', '运费', '数值1');
  const upstairs = col('公司上楼费', '上楼费', '上楼', '数值2');
  const total = col('公司合计', '合计', '总金额');
  const date = col('单子日期', '日期', '单据日期');
  const code = col('编号', '单号', '订单编号');
  const seq = col('序号'); const name = col('姓名'); const month = col('月份'); const count = col('合并前原始行数'); const origins = col('来源日期');
  if ([address, freight, upstairs].some(i => i < 0)) throw new Error('缺少地址、运费或上楼费列。');
  const rows: ParsedCompanyTableRow[] = []; const errors: string[] = []; const sourceCounts: number[] = []; const sourceDates: string[][] = [];
  const cents = (v: unknown): number => {
    const s = String(v).replace(/[￥¥,，\s]/g, '');
    if (!/^\d+(?:\.\d{1,2})?$/.test(s)) throw new Error(`金额“${v}”不是最多两位小数的非负数`);
    const n = Math.round(Number(s) * 100); if (!Number.isSafeInteger(n)) throw new Error('金额超出安全范围'); return n;
  };
  let filePeriod = period;
  matrix.slice(headerIndex + 1).forEach((r, index) => {
    if (r.every(c => String(c).trim() === '')) return;
    try {
      const addr = String(r[address] ?? '').trim(); if (!addr) throw new Error('缺少地址');
      const orderCode = code >= 0 ? String(r[code] ?? '') : '';
      let value = date >= 0 ? r[date] : '';
      if (typeof value === 'number') { const d = XLSX.SSF.parse_date_code(value); value = d ? `${d.y}-${d.m}-${d.d}` : ''; }
      const billDate = normalizeBillDateInput(String(value), period) ?? (orderCode.match(/(\d{2})-(\d{2})-(\d{2})/) ? `20${orderCode.match(/(\d{2})-(\d{2})-(\d{2})/)!.slice(1).join('-')}` : '');
      if (!billDate) throw new Error('单子日期无法解析');
      const f = cents(r[freight]); const u = cents(r[upstairs]); const t = total < 0 ? f + u : cents(r[total]);
      if (t !== f + u) throw new Error('运费 + 上楼费与合计不一致');
      if (month >= 0 && /^\d{4}-\d{2}$/.test(String(r[month]))) filePeriod = String(r[month]);
      rows.push({ originalSequence: seq >= 0 ? String(r[seq]) : String(index + 1), orderCode, recipientName: name >= 0 ? String(r[name]) : '', billDate, address: addr, freightCents: f, upstairsCents: u, totalCents: t, confidence: 1 });
      sourceCounts.push(count >= 0 ? Number(r[count]) || 0 : 0);
      const dates = origins >= 0 ? String(r[origins]).split(/[、;；]/).filter(Boolean) : [];
      if (dates.some(d=>!normalizeBillDateInput(d,period))) throw new Error('来源日期无法解析');
      sourceDates.push(dates.length ? dates : [billDate]);
    } catch (e) { errors.push(`文件第 ${headerIndex + index + 2} 行：${e instanceof Error ? e.message : e}`); }
  });
  return { rows, errors, period: filePeriod, sourceCounts, sourceDates };
}
