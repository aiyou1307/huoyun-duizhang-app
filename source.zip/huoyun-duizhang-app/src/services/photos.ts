import * as FileSystem from 'expo-file-system/legacy';
import * as ImagePicker from 'expo-image-picker';

async function persistPickedImage(uri: string): Promise<string> {
  if (!FileSystem.documentDirectory) return uri;
  const dir = `${FileSystem.documentDirectory}receipt_photos/`;
  await FileSystem.makeDirectoryAsync(dir, { intermediates: true });
  const cleanUri = uri.split('?')[0] ?? uri;
  const extMatch = cleanUri.match(/\.([a-zA-Z0-9]+)$/);
  const ext = (extMatch?.[1] || 'jpg').toLowerCase();
  const target = `${dir}receipt_${Date.now()}_${Math.random().toString(36).slice(2, 7)}.${ext}`;
  await FileSystem.copyAsync({ from: uri, to: target });
  return target;
}

export async function takeReceiptPhoto(): Promise<string | null> {
  const permission = await ImagePicker.requestCameraPermissionsAsync();
  if (!permission.granted) return null;
  const result = await ImagePicker.launchCameraAsync({
    mediaTypes: ['images'],
    quality: 0.9,
    allowsEditing: false,
  });
  if (result.canceled) return null;
  return persistPickedImage(result.assets[0]?.uri ?? '');
}

export async function pickReceiptPhoto(): Promise<string | null> {
  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ['images'],
    quality: 0.9,
    allowsEditing: false,
  });
  if (result.canceled) return null;
  return persistPickedImage(result.assets[0]?.uri ?? '');
}
