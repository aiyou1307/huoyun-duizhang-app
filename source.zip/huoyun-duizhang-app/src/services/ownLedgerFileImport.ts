import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system/legacy';
import * as XLSX from 'xlsx';
import type { LedgerEntryDraft } from '../types';
import { normalizeBillDateInput } from '../utils/date';
import { yuanToCents } from '../utils/money';

export type OwnLedgerImport = { fileName: string; rows: LedgerEntryDraft[]; errors: string[]; dayCount: number; tripCount: number; totalCents: number };

const aliases: Record<string, string[]> = {
  recordDate: ['记账日期（不参与核算）', '记账日期', '实际日期', '工作日期'], billDate: ['单子日期', '账单日期'],
  tripNo: ['第几趟', '趟次'], address: ['地址', '地址/工地', '工地'], freight: ['运费'], upstairs: ['上楼费'],
  upstairsNote: ['上楼费备注'], note: ['整单备注', '备注'],
};
function headerIndex(headers: string[], key: string): number { return headers.findIndex((h) => aliases[key]?.some((a) => h.replace(/\s/g, '').includes(a.replace(/\s/g, '')))); }

export async function pickOwnLedgerFile(): Promise<OwnLedgerImport | null> {
  const picked = await DocumentPicker.getDocumentAsync({ type: ['text/csv', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'], copyToCacheDirectory: true });
  if (picked.canceled || !picked.assets[0]) return null;
  const asset = picked.assets[0];
  const name = asset.name.toLowerCase();
  if (!/\.(csv|xlsx|xls)$/.test(name)) throw new Error('请选择本 App 导出的 CSV，或字段一致的 Excel 文件。');
  const base64 = await FileSystem.readAsStringAsync(asset.uri, { encoding: FileSystem.EncodingType.Base64 });
  const book = XLSX.read(base64, { type: 'base64', raw: false });
  const first = book.SheetNames[0]; if (!first) throw new Error('文件里没有工作表。');
  const matrix = XLSX.utils.sheet_to_json<Array<string | number>>(book.Sheets[first]!, { header: 1, raw: false, defval: '' });
  const headers = (matrix[0] ?? []).map(String);
  const idx = {
    recordDate: headerIndex(headers, 'recordDate'), billDate: headerIndex(headers, 'billDate'), tripNo: headerIndex(headers, 'tripNo'),
    address: headerIndex(headers, 'address'), freight: headerIndex(headers, 'freight'), upstairs: headerIndex(headers, 'upstairs'),
    upstairsNote: headerIndex(headers, 'upstairsNote'), note: headerIndex(headers, 'note'),
  };
  if (idx.recordDate < 0 || idx.billDate < 0 || idx.tripNo < 0 || idx.address < 0 || idx.freight < 0 || idx.upstairs < 0) throw new Error('缺少必要列。请使用本 App 导出的“我的账 CSV”，或保留实际日期、单子日期、第几趟、地址、运费、上楼费列。');
  const rows: LedgerEntryDraft[] = [], errors: string[] = [];
  matrix.slice(1).forEach((cells, offset) => {
    if (!cells.some((v) => String(v).trim())) return;
    const recordDate = normalizeBillDateInput(String(cells[idx.recordDate] ?? ''), '') ?? '';
    const billDate = normalizeBillDateInput(String(cells[idx.billDate] ?? ''), '') ?? '';
    const tripNo = Number(String(cells[idx.tripNo] ?? '').replace(/[^0-9]/g, ''));
    const address = String(cells[idx.address] ?? '').trim();
    if (!recordDate || !billDate || !Number.isInteger(tripNo) || tripNo < 1 || !address) { errors.push(`第 ${offset + 2} 行日期、趟次或地址无效`); return; }
    rows.push({ recordDate, billDate, tripNo, address, freightCents: yuanToCents(String(cells[idx.freight] ?? '0')), upstairsCents: yuanToCents(String(cells[idx.upstairs] ?? '0')), upstairsNote: idx.upstairsNote >= 0 ? String(cells[idx.upstairsNote] ?? '').trim() || null : null, photoUri: null, note: idx.note >= 0 ? String(cells[idx.note] ?? '').trim() || null : null });
  });
  const days = new Set(rows.map((r) => r.recordDate));
  const trips = new Set(rows.map((r) => `${r.recordDate}|${r.tripNo}`));
  return { fileName: asset.name, rows, errors: errors.slice(0, 20), dayCount: days.size, tripCount: trips.size, totalCents: rows.reduce((s, r) => s + r.freightCents + r.upstairsCents, 0) };
}
