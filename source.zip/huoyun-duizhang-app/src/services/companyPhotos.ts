import * as FileSystem from 'expo-file-system/legacy';
import * as ImagePicker from 'expo-image-picker';

async function persistCompanyImage(uri: string): Promise<string> {
  if (!FileSystem.documentDirectory) return uri;
  const dir = `${FileSystem.documentDirectory}company_bills/`;
  await FileSystem.makeDirectoryAsync(dir, { intermediates: true });
  const cleanUri = uri.split('?')[0] ?? uri;
  const extMatch = cleanUri.match(/\.([a-zA-Z0-9]+)$/);
  const ext = (extMatch?.[1] || 'jpg').toLowerCase();
  const target = `${dir}company_${Date.now()}_${Math.random().toString(36).slice(2, 7)}.${ext}`;
  await FileSystem.copyAsync({ from: uri, to: target });
  return target;
}

export async function takeCompanyBillPhoto(): Promise<string | null> {
  const permission = await ImagePicker.requestCameraPermissionsAsync();
  if (!permission.granted) return null;
  const result = await ImagePicker.launchCameraAsync({ mediaTypes: ['images'], quality: 1, allowsEditing: false });
  if (result.canceled) return null;
  const uri = result.assets[0]?.uri;
  return uri ? persistCompanyImage(uri) : null;
}

export async function pickCompanyBillPhotos(): Promise<string[]> {
  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ['images'],
    quality: 1,
    allowsEditing: false,
    allowsMultipleSelection: true,
    selectionLimit: 20,
  });
  if (result.canceled) return [];
  const uris = await Promise.all(result.assets.map((asset) => persistCompanyImage(asset.uri)));
  return uris.filter(Boolean);
}
