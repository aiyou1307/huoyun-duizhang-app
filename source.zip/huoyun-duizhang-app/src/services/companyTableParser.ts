import { normalizeBillDateInput } from '../utils/date';

export type TableOcrElement = {
  text: string;
  frame: { x: number; y: number; width: number; height: number };
};

export type ParsedCompanyTableRow = {
  billDate: string;
  address: string;
  freightCents: number;
  upstairsCents: number;
  totalCents: number;
  confidence: number;
};

type RowToken = TableOcrElement & { centerX: number; centerY: number };

function median(values: number[]): number {
  if (!values.length) return 12;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid]! : (sorted[mid - 1]! + sorted[mid]!) / 2;
}

function parseMoney(text: string): number | null {
  const cleaned = text.trim().replace(/[￥¥,，\s]/g, '').replace(/[oO]/g, '0');
  if (!/^-?\d+(?:\.\d{1,2})?$/.test(cleaned)) return null;
  const value = Number(cleaned);
  if (!Number.isFinite(value) || value < 0 || value > 100000) return null;
  return Math.round(value * 100);
}

function extractDate(text: string, period: string): string {
  const chunks = text.match(/\d+/g) ?? [];
  for (let i = 0; i + 2 < chunks.length; i += 1) {
    const a = chunks[i]!;
    const b = chunks[i + 1]!;
    const c = chunks[i + 2]!;
    const first = Number(a);
    const month = Number(b);
    const day = Number(c);
    if (a.length === 4 && first >= 2000 && first <= 2099 && month >= 1 && month <= 12 && day >= 1 && day <= 31) {
      return normalizeBillDateInput(`${first}-${month}-${day}`, period) ?? '';
    }
    if (a.length === 2 && first >= 20 && first <= 99 && month >= 1 && month <= 12 && day >= 1 && day <= 31) {
      return normalizeBillDateInput(`${2000 + first}-${month}-${day}`, period) ?? '';
    }
  }

  // 少数账单可能只印“8/3”而没有年份。
  const short = text.match(/(?:^|\D)(\d{1,2})[\/.月-](\d{1,2})(?:日|\D|$)/);
  if (short) return normalizeBillDateInput(`${short[1]}/${short[2]}`, period) ?? '';
  return '';
}

function isLikelyDriverName(text: string): boolean {
  const value = text.replace(/\s/g, '');
  if (!/^[\u4e00-\u9fff]{2,4}$/.test(value)) return false;
  return !/[区县市镇村街路道巷园苑城府里庄楼栋室号店厂院湾墅家园公寓小区广场中心]/.test(value);
}

function groupIntoRows(elements: TableOcrElement[]): RowToken[][] {
  const tokens: RowToken[] = elements
    .filter((element) => element.text.trim() && element.frame.width > 0 && element.frame.height > 0)
    .map((element) => ({
      ...element,
      text: element.text.trim(),
      centerX: element.frame.x + element.frame.width / 2,
      centerY: element.frame.y + element.frame.height / 2,
    }))
    .sort((a, b) => a.centerY - b.centerY || a.centerX - b.centerX);

  const typicalHeight = median(tokens.map((token) => token.frame.height));
  const tolerance = Math.max(8, typicalHeight * 0.7);
  const rows: Array<{ centerY: number; tokens: RowToken[] }> = [];

  for (const token of tokens) {
    let best: { centerY: number; tokens: RowToken[] } | undefined;
    let bestDistance = Number.POSITIVE_INFINITY;
    for (const row of rows) {
      const distance = Math.abs(row.centerY - token.centerY);
      if (distance <= tolerance && distance < bestDistance) {
        best = row;
        bestDistance = distance;
      }
    }
    if (!best) {
      rows.push({ centerY: token.centerY, tokens: [token] });
    } else {
      best.tokens.push(token);
      best.centerY = best.tokens.reduce((sum, item) => sum + item.centerY, 0) / best.tokens.length;
    }
  }

  return rows
    .map((row) => row.tokens.sort((a, b) => a.centerX - b.centerX))
    .sort((a, b) => (a[0]?.centerY ?? 0) - (b[0]?.centerY ?? 0));
}

export function parseCompanyTableElements(elements: TableOcrElement[], period: string): ParsedCompanyTableRow[] {
  const grouped = groupIntoRows(elements);
  const output: ParsedCompanyTableRow[] = [];

  for (const tokens of grouped) {
    if (tokens.length < 4) continue;
    const moneyCandidates = tokens
      .map((token, index) => ({ index, cents: parseMoney(token.text) }))
      .filter((item): item is { index: number; cents: number } => item.cents !== null);
    if (moneyCandidates.length < 3) continue;

    // 公司表最右侧三列固定为：运费、上楼费、合计。
    const amounts = moneyCandidates.slice(-3);
    const firstAmountIndex = amounts[0]?.index;
    if (firstAmountIndex === undefined) continue;
    const freightCents = amounts[0]!.cents;
    const upstairsCents = amounts[1]!.cents;
    const totalCents = amounts[2]!.cents;

    const left = tokens.slice(0, firstAmountIndex);
    if (!left.length) continue;
    const fullLeftText = left.map((token) => token.text).join('-');
    const billDate = extractDate(fullLeftText, period);

    let orderIndex = left.findIndex((token) => /[A-Za-z]{1,4}[-_]?\d|XH|xh/.test(token.text));
    if (orderIndex < 0) {
      // 第一列通常是序号，第二列是销货单号；两者都不保存，只用于定位地址和提取日期。
      orderIndex = left.length >= 3 ? 1 : 0;
    }

    let addressTokens = left.slice(orderIndex + 1);
    if (addressTokens.length >= 2 && isLikelyDriverName(addressTokens[addressTokens.length - 1]!.text)) {
      addressTokens = addressTokens.slice(0, -1);
    }
    const address = addressTokens.map((token) => token.text.replace(/\s/g, '')).join('').trim();
    if (!address) continue;

    let confidence = 0.45;
    if (billDate) confidence += 0.2;
    if (address.length >= 3) confidence += 0.15;
    if (freightCents + upstairsCents === totalCents) confidence += 0.2;

    output.push({
      billDate,
      address,
      freightCents,
      upstairsCents,
      totalCents,
      confidence: Math.min(1, confidence),
    });
  }

  return output;
}
