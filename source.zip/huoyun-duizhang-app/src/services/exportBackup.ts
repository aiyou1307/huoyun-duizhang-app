import type { SQLiteDatabase } from 'expo-sqlite';
import * as FileSystem from 'expo-file-system/legacy';

type DbRow = Record<string, unknown>;

type BackupMedia = {
  sourceUri: string;
  backupFileName: string;
  kind: 'own' | 'company';
};

type FullBackup = {
  format: 'huoyun-ledger-backup';
  formatVersion: 1 | 2;
  createdAt: string;
  appVersion: '0.1.0';
  tables: {
    own_entries: DbRow[];
    company_batches: DbRow[];
    company_import_batches?: DbRow[];
    company_photos: DbRow[];
    company_raw_rows: DbRow[];
    company_merged_rows: DbRow[];
    reconciliation_matches: DbRow[];
    reconciliation_rejections: DbRow[];
  };
  media: BackupMedia[];
  warnings: string[];
};

function csvCell(value: unknown): string {
  const text = value === null || value === undefined ? '' : String(value);
  return `"${text.replace(/"/g, '""')}"`;
}

function ymdCompact(date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  const hh = String(date.getHours()).padStart(2, '0');
  const mm = String(date.getMinutes()).padStart(2, '0');
  return `${y}${m}${d}_${hh}${mm}`;
}

function yuan(cents: unknown): string {
  const n = typeof cents === 'number' ? cents : Number(cents ?? 0);
  return (n / 100).toFixed(2);
}

function sourceExt(uri: string): string {
  const clean = uri.split('?')[0] ?? uri;
  const match = clean.match(/\.([a-zA-Z0-9]{2,5})$/);
  const ext = (match?.[1] || 'jpg').toLowerCase();
  if (ext === 'jpeg') return 'jpg';
  return ext;
}

function mimeForExt(ext: string): string {
  if (ext === 'png') return 'image/png';
  if (ext === 'webp') return 'image/webp';
  if (ext === 'heic' || ext === 'heif') return 'image/heic';
  return 'image/jpeg';
}

function getDisplayName(uri: string): string {
  const decoded = decodeURIComponent(uri);
  const afterSlash = decoded.split('/').pop() ?? decoded;
  return afterSlash.split(':').pop() ?? afterSlash;
}

async function chooseFolder(): Promise<string> {
  const permission = await FileSystem.StorageAccessFramework.requestDirectoryPermissionsAsync();
  if (!permission.granted) throw new Error('没有选择保存文件夹。');
  return permission.directoryUri;
}

async function writeSafFile(folderUri: string, fileName: string, mimeType: string, content: string, encoding: 'utf8' | 'base64' = 'utf8'): Promise<string> {
  const uri = await FileSystem.StorageAccessFramework.createFileAsync(folderUri, fileName, mimeType);
  await FileSystem.writeAsStringAsync(uri, content, {
    encoding: encoding === 'base64' ? FileSystem.EncodingType.Base64 : FileSystem.EncodingType.UTF8,
  });
  return uri;
}

export async function exportOwnLedgerCsv(db: SQLiteDatabase): Promise<{ fileName: string; rowCount: number }> {
  const rows = await db.getAllAsync<DbRow>(
    `SELECT record_date, bill_date, trip_no, address, freight_cents, upstairs_cents,
      (freight_cents + upstairs_cents) AS total_cents, upstairs_note, note
     FROM own_entries ORDER BY record_date ASC, trip_no ASC, id ASC`,
  );
  const headers = ['记账日期（不参与核算）', '单子日期', '第几趟', '地址', '运费', '上楼费', '合计', '上楼费备注', '整单备注'];
  const lines = [headers.map(csvCell).join(',')];
  for (const row of rows) {
    lines.push([
      row.record_date,
      row.bill_date,
      row.trip_no,
      row.address,
      yuan(row.freight_cents),
      yuan(row.upstairs_cents),
      yuan(row.total_cents),
      row.upstairs_note,
      row.note,
    ].map(csvCell).join(','));
  }
  const folder = await chooseFolder();
  const fileName = `我的账_${ymdCompact()}.csv`;
  // BOM 让 Excel/WPS 默认按 UTF-8 打开中文。
  await writeSafFile(folder, fileName, 'text/csv', `\uFEFF${lines.join('\r\n')}`);
  return { fileName, rowCount: rows.length };
}

export async function exportCompanyMergedCsv(db: SQLiteDatabase): Promise<{ fileName: string; rowCount: number }> {
  const rows = await db.getAllAsync<DbRow>(
    `SELECT b.period, m.bill_date, m.address, m.freight_cents, m.upstairs_cents, m.total_cents, m.raw_row_count
     FROM company_merged_rows m
     JOIN company_batches b ON b.id = m.batch_id
     ORDER BY b.period ASC, m.bill_date ASC, m.id ASC`,
  );
  const headers = ['月份', '单子日期', '地址', '公司运费', '公司上楼费', '公司合计', '合并前原始行数'];
  const lines = [headers.map(csvCell).join(',')];
  for (const row of rows) {
    lines.push([
      row.period,
      row.bill_date,
      row.address,
      yuan(row.freight_cents),
      yuan(row.upstairs_cents),
      yuan(row.total_cents),
      row.raw_row_count,
    ].map(csvCell).join(','));
  }
  const folder = await chooseFolder();
  const fileName = `公司合并账_${ymdCompact()}.csv`;
  await writeSafFile(folder, fileName, 'text/csv', `\uFEFF${lines.join('\r\n')}`);
  return { fileName, rowCount: rows.length };
}

async function dumpTables(db: SQLiteDatabase): Promise<FullBackup['tables']> {
  return {
    own_entries: await db.getAllAsync<DbRow>('SELECT * FROM own_entries ORDER BY id ASC'),
    company_batches: await db.getAllAsync<DbRow>('SELECT * FROM company_batches ORDER BY id ASC'),
    company_import_batches: await db.getAllAsync<DbRow>('SELECT * FROM company_import_batches ORDER BY id ASC'),
    company_photos: await db.getAllAsync<DbRow>('SELECT * FROM company_photos ORDER BY id ASC'),
    company_raw_rows: await db.getAllAsync<DbRow>('SELECT * FROM company_raw_rows ORDER BY id ASC'),
    company_merged_rows: await db.getAllAsync<DbRow>('SELECT * FROM company_merged_rows ORDER BY id ASC'),
    reconciliation_matches: await db.getAllAsync<DbRow>('SELECT * FROM reconciliation_matches ORDER BY id ASC'),
    reconciliation_rejections: await db.getAllAsync<DbRow>('SELECT * FROM reconciliation_rejections ORDER BY id ASC'),
  };
}

export async function exportFullBackup(db: SQLiteDatabase): Promise<{ manifestName: string; mediaCount: number; warnings: string[] }> {
  const folder = await chooseFolder();
  const tables = await dumpTables(db);
  const mediaSources = new Map<string, 'own' | 'company'>();
  for (const row of tables.own_entries) {
    const uri = typeof row.photo_uri === 'string' ? row.photo_uri : '';
    if (uri) mediaSources.set(uri, 'own');
  }
  for (const row of tables.company_photos) {
    const uri = typeof row.uri === 'string' ? row.uri : '';
    if (uri) mediaSources.set(uri, 'company');
  }

  const media: BackupMedia[] = [];
  const warnings: string[] = [];
  let index = 0;
  for (const [sourceUri, kind] of mediaSources.entries()) {
    index += 1;
    try {
      const info = await FileSystem.getInfoAsync(sourceUri);
      if (!info.exists) {
        warnings.push(`有一张照片已不存在：${sourceUri}`);
        continue;
      }
      const ext = sourceExt(sourceUri);
      const backupFileName = `huoyun_media_${String(index).padStart(4, '0')}.${ext}`;
      const base64 = await FileSystem.readAsStringAsync(sourceUri, { encoding: FileSystem.EncodingType.Base64 });
      await writeSafFile(folder, backupFileName, mimeForExt(ext), base64, 'base64');
      media.push({ sourceUri, backupFileName, kind });
    } catch {
      warnings.push(`有一张照片备份失败：${sourceUri}`);
    }
  }

  const backup: FullBackup = {
    format: 'huoyun-ledger-backup',
    formatVersion: 2,
    createdAt: new Date().toISOString(),
    appVersion: '0.1.0',
    tables,
    media,
    warnings,
  };
  const manifestName = `huoyun_backup_${ymdCompact()}.json`;
  await writeSafFile(folder, manifestName, 'application/json', JSON.stringify(backup));
  return { manifestName, mediaCount: media.length, warnings };
}

async function findNewestManifest(folderUri: string): Promise<string> {
  const files = await FileSystem.StorageAccessFramework.readDirectoryAsync(folderUri);
  const candidates = files
    .map((uri) => ({ uri, name: getDisplayName(uri) }))
    .filter((item) => /^huoyun_backup_.*\.json$/i.test(item.name))
    .sort((a, b) => b.name.localeCompare(a.name));
  if (!candidates[0]) throw new Error('这个文件夹里没有找到“huoyun_backup_*.json”完整备份。');
  return candidates[0].uri;
}

function numberValue(value: unknown, fallback = 0): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function textValue(value: unknown): string {
  return value === null || value === undefined ? '' : String(value);
}

function nullableText(value: unknown): string | null {
  return value === null || value === undefined || value === '' ? null : String(value);
}

async function restoreMedia(folderUri: string, backup: FullBackup): Promise<Map<string, string>> {
  const allFiles = await FileSystem.StorageAccessFramework.readDirectoryAsync(folderUri);
  const byName = new Map(allFiles.map((uri) => [getDisplayName(uri), uri]));
  const restored = new Map<string, string>();
  if (!FileSystem.documentDirectory) return restored;

  const ownDir = `${FileSystem.documentDirectory}own_photos/`;
  const companyDir = `${FileSystem.documentDirectory}company_bills/`;
  await FileSystem.makeDirectoryAsync(ownDir, { intermediates: true });
  await FileSystem.makeDirectoryAsync(companyDir, { intermediates: true });

  for (const media of backup.media) {
    const source = byName.get(media.backupFileName);
    if (!source) continue;
    const ext = sourceExt(media.backupFileName);
    const destinationDir = media.kind === 'company' ? companyDir : ownDir;
    const destination = `${destinationDir}restored_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const base64 = await FileSystem.readAsStringAsync(source, { encoding: FileSystem.EncodingType.Base64 });
    await FileSystem.writeAsStringAsync(destination, base64, { encoding: FileSystem.EncodingType.Base64 });
    restored.set(media.sourceUri, destination);
  }
  return restored;
}

async function replaceAllData(db: SQLiteDatabase, backup: FullBackup, mediaMap: Map<string, string>): Promise<void> {
  await db.execAsync(`
    DELETE FROM reconciliation_rejections;
    DELETE FROM reconciliation_matches;
    DELETE FROM company_merged_rows;
    DELETE FROM company_raw_rows;
    DELETE FROM company_photos;
    DELETE FROM company_import_batches;
    DELETE FROM company_batches;
    DELETE FROM own_entries;
  `);

  for (const row of backup.tables.own_entries) {
    const oldPhoto = nullableText(row.photo_uri);
    const newPhoto = oldPhoto ? (mediaMap.get(oldPhoto) ?? oldPhoto) : null;
    await db.runAsync(
      `INSERT INTO own_entries(id, record_date, bill_date, trip_no, address, freight_cents, upstairs_cents,
        upstairs_note, photo_uri, note, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      numberValue(row.id), textValue(row.record_date), textValue(row.bill_date), numberValue(row.trip_no, 1), textValue(row.address),
      numberValue(row.freight_cents), numberValue(row.upstairs_cents), nullableText(row.upstairs_note), newPhoto, nullableText(row.note),
      textValue(row.created_at), textValue(row.updated_at),
    );
  }

  for (const row of backup.tables.company_batches) {
    await db.runAsync(
      `INSERT INTO company_batches(id, period, status, created_at, confirmed_at, merged_at) VALUES (?, ?, ?, ?, ?, ?)`,
      numberValue(row.id), textValue(row.period), textValue(row.status), textValue(row.created_at), nullableText(row.confirmed_at), nullableText(row.merged_at),
    );
  }

  for (const row of backup.tables.company_photos) {
    const oldUri = textValue(row.uri);
    await db.runAsync(
      `INSERT INTO company_photos(id, batch_id, uri, page_no, created_at) VALUES (?, ?, ?, ?, ?)`,
      numberValue(row.id), numberValue(row.batch_id), mediaMap.get(oldUri) ?? oldUri, numberValue(row.page_no, 1), textValue(row.created_at),
    );
  }

  for (const row of backup.tables.company_import_batches ?? []) {
    await db.runAsync(
      `INSERT INTO company_import_batches(id, company_batch_id, batch_no, status, source_type, source_text, created_at, confirmed_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      numberValue(row.id), numberValue(row.company_batch_id), numberValue(row.batch_no, 1), textValue(row.status) || 'reviewing',
      textValue(row.source_type) || 'legacy', nullableText(row.source_text), textValue(row.created_at), nullableText(row.confirmed_at),
    );
  }

  for (const row of backup.tables.company_raw_rows) {
    await db.runAsync(
      `INSERT INTO company_raw_rows(id, batch_id, import_batch_id, photo_id, source_row_no, original_sequence, order_code, recipient_name, bill_date, address, freight_cents, upstairs_cents,
        total_cents, confidence, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      numberValue(row.id), numberValue(row.batch_id), row.import_batch_id === null || row.import_batch_id === undefined ? null : numberValue(row.import_batch_id), row.photo_id === null ? null : numberValue(row.photo_id), numberValue(row.source_row_no),
      textValue(row.original_sequence), textValue(row.order_code), textValue(row.recipient_name), textValue(row.bill_date), textValue(row.address), numberValue(row.freight_cents), numberValue(row.upstairs_cents), numberValue(row.total_cents),
      row.confidence === null ? null : numberValue(row.confidence), textValue(row.created_at), textValue(row.updated_at),
    );
  }

  // 兼容旧版备份：每份旧公司账自动恢复为一个“第1批”。
  if (!(backup.tables.company_import_batches?.length)) {
    for (const account of backup.tables.company_batches) {
      const accountId = numberValue(account.id);
      const count = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) AS count FROM company_raw_rows WHERE batch_id = ?', accountId);
      if (!count?.count) continue;
      const result = await db.runAsync(
        `INSERT INTO company_import_batches(company_batch_id, batch_no, status, source_type, created_at, confirmed_at)
         VALUES (?, 1, ?, 'legacy', ?, ?)`,
        accountId, textValue(account.status) === 'reviewing' ? 'reviewing' : 'confirmed', textValue(account.created_at), nullableText(account.confirmed_at),
      );
      await db.runAsync('UPDATE company_raw_rows SET import_batch_id = ? WHERE batch_id = ?', result.lastInsertRowId, accountId);
    }
  }

  for (const row of backup.tables.company_merged_rows) {
    await db.runAsync(
      `INSERT INTO company_merged_rows(id, batch_id, bill_date, address, match_address, freight_cents, upstairs_cents, total_cents,
        raw_row_ids_json, raw_row_count, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      numberValue(row.id), numberValue(row.batch_id), textValue(row.bill_date), textValue(row.address), textValue(row.match_address),
      numberValue(row.freight_cents), numberValue(row.upstairs_cents), numberValue(row.total_cents), textValue(row.raw_row_ids_json),
      numberValue(row.raw_row_count), textValue(row.created_at),
    );
  }

  for (const row of backup.tables.reconciliation_matches) {
    await db.runAsync(
      `INSERT INTO reconciliation_matches(id, batch_id, own_entry_id, company_merged_id, created_at) VALUES (?, ?, ?, ?, ?)`,
      numberValue(row.id), numberValue(row.batch_id), numberValue(row.own_entry_id), numberValue(row.company_merged_id), textValue(row.created_at),
    );
  }

  for (const row of backup.tables.reconciliation_rejections) {
    await db.runAsync(
      `INSERT INTO reconciliation_rejections(id, batch_id, own_entry_id, company_merged_id, created_at) VALUES (?, ?, ?, ?, ?)`,
      numberValue(row.id), numberValue(row.batch_id), numberValue(row.own_entry_id), numberValue(row.company_merged_id), textValue(row.created_at),
    );
  }
}

export async function restoreFullBackup(db: SQLiteDatabase): Promise<{ manifestName: string; mediaRestored: number }> {
  const permission = await FileSystem.StorageAccessFramework.requestDirectoryPermissionsAsync();
  if (!permission.granted) throw new Error('没有选择备份文件夹。');
  const manifestUri = await findNewestManifest(permission.directoryUri);
  const raw = await FileSystem.readAsStringAsync(manifestUri, { encoding: FileSystem.EncodingType.UTF8 });
  const backup = JSON.parse(raw) as FullBackup;
  if (backup.format !== 'huoyun-ledger-backup' || ![1, 2].includes(backup.formatVersion) || !backup.tables) {
    throw new Error('这不是可识别的货运记账完整备份。');
  }
  const mediaMap = await restoreMedia(permission.directoryUri, backup);
  await replaceAllData(db, backup, mediaMap);
  return { manifestName: getDisplayName(manifestUri), mediaRestored: mediaMap.size };
}
