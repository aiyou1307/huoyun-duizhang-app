import { normalizeBillDateInput } from '../utils/date';
import { yuanToCents } from '../utils/money';
import { parseCompanyTableElements, type TableOcrElement } from './companyTableParser';

type OcrApiRow = {
  billDate?: string;
  address?: string;
  freight?: number | string;
  upstairs?: number | string;
  total?: number | string;
  confidence?: number;
};

type OcrApiResponse = { rows?: OcrApiRow[] };

export type CompanyOcrResult = {
  rows: Array<{ billDate: string; address: string; freightCents: number; upstairsCents: number; totalCents: number; confidence: number | null }>;
  configured: boolean;
  provider: 'on-device' | 'endpoint' | 'manual';
  message: string;
};

function moneyToCents(value: number | string | undefined): number {
  if (typeof value === 'number') return Math.round(value * 100);
  return yuanToCents(value ?? '');
}

async function recognizeOnDevice(photoUri: string, period: string): Promise<CompanyOcrResult | null> {
  try {
    const module = await import('rn-mlkit-ocr');
    const result = await module.default.recognizeText(photoUri, 'chinese');
    const elements: TableOcrElement[] = [];
    for (const block of result.blocks ?? []) {
      for (const line of block.lines ?? []) {
        if (line.elements?.length) {
          for (const element of line.elements) elements.push({ text: element.text, frame: element.frame });
        } else if (line.text && line.frame) {
          elements.push({ text: line.text, frame: line.frame });
        }
      }
    }
    const parsed = parseCompanyTableElements(elements, period);
    return {
      rows: parsed.map((row) => ({ ...row })),
      configured: true,
      provider: 'on-device',
      message: `本机 OCR 已识别 ${parsed.length} 行。请逐行与公司原账单核对，错误可直接修改。`,
    };
  } catch {
    // Expo Go 不包含这个原生模块；开发 APK/正式 APK 中会继续尝试。
    return null;
  }
}

async function recognizeByEndpoint(photoUri: string, period: string): Promise<CompanyOcrResult | null> {
  const endpoint = process.env.EXPO_PUBLIC_COMPANY_OCR_ENDPOINT;
  if (!endpoint) return null;
  const form = new FormData();
  form.append('image', { uri: photoUri, name: 'company-bill.jpg', type: 'image/jpeg' } as never);
  form.append('period', period);
  const response = await fetch(endpoint, { method: 'POST', body: form });
  if (!response.ok) throw new Error(`OCR请求失败：${response.status}`);
  const data = await response.json() as OcrApiResponse;
  const rows = (data.rows ?? []).map((row) => ({
    billDate: normalizeBillDateInput(row.billDate?.trim() ?? '', period) ?? row.billDate?.trim() ?? '',
    address: row.address?.trim() ?? '',
    freightCents: moneyToCents(row.freight),
    upstairsCents: moneyToCents(row.upstairs),
    totalCents: moneyToCents(row.total),
    confidence: typeof row.confidence === 'number' ? row.confidence : null,
  }));
  return { rows, configured: true, provider: 'endpoint', message: `联网 OCR 已识别 ${rows.length} 行，请逐行与原图核对。` };
}

export async function recognizeCompanyBill(photoUri: string, period: string): Promise<CompanyOcrResult> {
  const local = await recognizeOnDevice(photoUri, period);
  if (local) return local;
  const remote = await recognizeByEndpoint(photoUri, period);
  if (remote) return remote;
  return {
    rows: [],
    configured: false,
    provider: 'manual',
    message: '当前运行环境没有 OCR 原生模块。安装开发 APK/正式 APK 后可使用本机中文 OCR；现在仍可手动录入并测试后续核对、合并和对账流程。',
  };
}
