import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system/legacy';
import * as XLSX from 'xlsx';
import { parseCompanyWorkbook, type CompanyParsedFile } from './companyFileParser';

export type CompanyFileResult = CompanyParsedFile & { name: string } | null;

export async function pickAndParseCompanyFile(period: string): Promise<CompanyFileResult> {
  const picked = await DocumentPicker.getDocumentAsync({
    type: ['text/csv', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
    copyToCacheDirectory: true,
    multiple: false,
  });
  if (picked.canceled) return null;
  const asset = picked.assets[0];
  if (!asset) return null;
  const lower = asset.name.toLowerCase();
  if (!lower.endsWith('.csv') && !lower.endsWith('.xlsx') && !lower.endsWith('.xls')) throw new Error('请选择 .xlsx、.xls 或 .csv 文件。');
  const base64 = await FileSystem.readAsStringAsync(asset.uri, { encoding: FileSystem.EncodingType.Base64 });
  const workbook = XLSX.read(base64, { type: 'base64', cellDates: false });
  return { name: asset.name, ...parseCompanyWorkbook(workbook, period) };
}
