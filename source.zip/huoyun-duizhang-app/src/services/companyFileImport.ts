import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system/legacy';
import * as XLSX from 'xlsx';
import { parsePastedCompanyTable, type ParsedCompanyTableRow } from './companyTableParser';

export type CompanyFileResult = { name: string; rows: ParsedCompanyTableRow[]; errors: string[] } | null;

export async function pickAndParseCompanyFile(period: string): Promise<CompanyFileResult> {
  const picked = await DocumentPicker.getDocumentAsync({
    type: ['text/csv', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
    copyToCacheDirectory: true,
    multiple: false,
  });
  if (picked.canceled) return null;
  const asset = picked.assets[0];
  if (!asset) return null;
  const lower = asset.name.toLowerCase();
  if (!lower.endsWith('.csv') && !lower.endsWith('.xlsx') && !lower.endsWith('.xls')) throw new Error('请选择 .xlsx、.xls 或 .csv 文件。');
  const base64 = await FileSystem.readAsStringAsync(asset.uri, { encoding: FileSystem.EncodingType.Base64 });
  const workbook = XLSX.read(base64, { type: 'base64', cellDates: false });
  const firstSheet = workbook.SheetNames[0];
  if (!firstSheet) throw new Error('文件中没有可读取的工作表。');
  const sheet = workbook.Sheets[firstSheet];
  if (!sheet) throw new Error('文件中没有可读取的工作表。');
  const matrix = XLSX.utils.sheet_to_json<(string | number)[]>(sheet, { header: 1, raw: false, defval: '' });
  const text = matrix.map((row) => row.map((cell) => String(cell).trim()).join(' | ')).join('\n');
  const parsed = parsePastedCompanyTable(text, period);
  const errors: string[] = [];
  if (!parsed.rows.length) errors.push('没有匹配到数据列，请检查是否包含序号、地址、运费、上楼费、合计。');
  if (parsed.skippedLines) errors.push(`有 ${parsed.skippedLines} 行无法解析，请检查空日期、非数字金额或缺失字段。`);
  parsed.rows.forEach((row, index) => {
    if (!row.address.trim()) errors.push(`第 ${index + 1} 条缺少地址。`);
    if (![row.freightCents, row.upstairsCents, row.totalCents].every(Number.isFinite)) errors.push(`第 ${index + 1} 条金额不是有效数字。`);
  });
  return { name: asset.name, rows: parsed.rows, errors: errors.slice(0, 20) };
}
