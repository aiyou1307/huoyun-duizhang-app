declare module 'rn-mlkit-ocr' {
  export type OcrFrame = { x: number; y: number; width: number; height: number };
  export type OcrElement = { text: string; frame: OcrFrame };
  export type OcrLine = { text: string; frame: OcrFrame; elements: OcrElement[] };
  export type OcrBlock = { text: string; frame: OcrFrame; lines: OcrLine[] };
  export type OcrResult = { text: string; blocks: OcrBlock[] };
  const MlkitOcr: {
    recognizeText(imageUri: string, detectorType?: 'latin' | 'chinese' | 'devanagari' | 'japanese' | 'korean'): Promise<OcrResult>;
    getAvailableLanguages(): Promise<string[]>;
  };
  export default MlkitOcr;
}
