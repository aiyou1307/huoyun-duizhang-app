import { memo } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { CompanyRawRow } from '../types';
import { colors } from '../theme';
import { centsToYuan } from '../utils/money';

export const CompanyRawCompactRow = memo(function CompanyRawCompactRow({
  row, batchNo, onEdit,
}: { row: CompanyRawRow; batchNo?: number; onEdit?: (row: CompanyRawRow) => void }) {
  const total = row.freightCents + row.upstairsCents;
  return <Pressable style={styles.row} onPress={() => onEdit?.(row)} disabled={!onEdit}>
    <Text style={styles.no}>{row.originalSequence || row.sourceRowNo}</Text>
    <Text style={styles.date}>{row.billDate ? row.billDate.slice(5) : '—'}</Text>
    <View style={styles.addressWrap}>
      {batchNo ? <Text style={styles.batch}>第{batchNo}批</Text> : null}
      <Text style={styles.address} numberOfLines={2} ellipsizeMode="tail">{row.address || '点击填写地址'}</Text>
    </View>
    <Text style={styles.money}>{centsToYuan(row.freightCents)}</Text>
    <Text style={styles.money}>{centsToYuan(row.upstairsCents)}</Text>
    <Text style={styles.total}>{centsToYuan(total)}</Text>
  </Pressable>;
});

export function CompanyRawTableHeader() {
  return <View style={styles.header}><Text style={styles.no}>序号</Text><Text style={styles.date}>日期</Text><Text style={styles.addressWrap}>地址/工地</Text><Text style={styles.money}>运费</Text><Text style={styles.money}>上楼</Text><Text style={styles.total}>合计</Text></View>;
}

const styles = StyleSheet.create({
  row: { minHeight: 58, flexDirection: 'row', alignItems: 'center', paddingVertical: 6, paddingHorizontal: 5, backgroundColor: '#fff', borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  header: { minHeight: 38, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 5, backgroundColor: '#EAF5FF', borderBottomWidth: 1, borderBottomColor: '#B9D9F5' },
  no: { width: 38, textAlign: 'center', color: colors.text, fontSize: 12 },
  date: { width: 48, textAlign: 'center', color: colors.text, fontSize: 12 },
  addressWrap: { flex: 1, paddingHorizontal: 4, color: colors.text, fontWeight: '800', fontSize: 12 },
  address: { color: colors.text, fontSize: 13, lineHeight: 18 },
  batch: { color: colors.primaryDark, fontSize: 10, fontWeight: '800' },
  money: { width: 48, textAlign: 'right', color: colors.text, fontSize: 12 },
  total: { width: 53, textAlign: 'right', color: colors.primaryDark, fontSize: 12, fontWeight: '900' },
});
