import { useState } from 'react';
import { TextInput, type TextInputProps } from 'react-native';
import { centsToYuan, yuanToCents } from '../utils/money';
/** 文本与整数分分离，保留用户输入中的末尾小数点。 */
export function DecimalMoneyInput({ cents, onCentsChange, ...props }: Omit<TextInputProps,'value'|'onChangeText'> & { cents: number; onCentsChange: (value: number) => void }) {
  const [text,setText] = useState(centsToYuan(cents));
  return <TextInput {...props} value={text} keyboardType="decimal-pad" inputMode="decimal" onChangeText={raw => {
    const value = raw.replace(/，/g,'.').replace(/,/g,'.');
    if (!/^\d*(?:\.\d{0,2})?$/.test(value)) return;
    setText(value); onCentsChange(yuanToCents(value));
  }} />;
}
