import { Ionicons } from '@expo/vector-icons';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme';
import type { RootScreen } from '../types';

const items: Array<{ key: RootScreen; label: string; icon: keyof typeof Ionicons.glyphMap }> = [
  { key: 'home', label: '我的账', icon: 'home-outline' },
  { key: 'company', label: '公司账', icon: 'document-text-outline' },
  { key: 'reconcile', label: '工资对账', icon: 'calculator-outline' },
  { key: 'me', label: '我的', icon: 'person-outline' },
];

export function BottomNav({ current, onChange }: { current: RootScreen; onChange: (screen: RootScreen) => void }) {
  return (
    <View style={styles.bar}>
      {items.map((item) => {
        const active = current === item.key;
        return (
          <Pressable key={item.key} style={styles.item} onPress={() => onChange(item.key)}>
            <Ionicons name={item.icon} size={23} color={active ? colors.primary : '#8796A8'} />
            <Text style={[styles.label, active && styles.active]}>{item.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    height: 64,
    backgroundColor: '#fff',
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.border,
    flexDirection: 'row',
  },
  item: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 3 },
  label: { fontSize: 12, color: '#8796A8', fontWeight: '600' },
  active: { color: colors.primary, fontWeight: '800' },
});
