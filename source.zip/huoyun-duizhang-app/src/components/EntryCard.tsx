import { Ionicons } from '@expo/vector-icons';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme';
import type { LedgerEntry } from '../types';
import { formatChineseDate } from '../utils/date';
import { formatMoney } from '../utils/money';

export function EntryCard({ entry, onPress }: { entry: LedgerEntry; onPress: () => void }) {
  const total = entry.freightCents + entry.upstairsCents;
  return (
    <Pressable style={({ pressed }) => [styles.card, pressed && styles.pressed]} onPress={onPress}>
      <View style={styles.topLine}>
        <Text style={styles.billDate}>单子日期 {formatChineseDate(entry.billDate)}</Text>
        <Ionicons name="chevron-forward" size={22} color="#718096" />
      </View>
      <Text style={styles.address} numberOfLines={2}>{entry.address}</Text>
      <View style={styles.moneyRow}>
        <Text style={styles.muted}>运费 <Text style={styles.money}>{formatMoney(entry.freightCents)}</Text></Text>
        <Text style={styles.muted}>上楼费 <Text style={styles.money}>{formatMoney(entry.upstairsCents)}</Text></Text>
        <Text style={styles.muted}>合计 <Text style={styles.total}>{formatMoney(total)}</Text></Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { paddingVertical: 13, paddingHorizontal: 14, backgroundColor: '#fff', borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  pressed: { opacity: 0.72 },
  topLine: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  billDate: { fontSize: 14, color: colors.primaryDark, fontWeight: '800' },
  address: { marginTop: 6, fontSize: 17, lineHeight: 24, color: colors.text, fontWeight: '700' },
  moneyRow: { marginTop: 10, flexDirection: 'row', justifyContent: 'space-between', gap: 8 },
  muted: { color: colors.muted, fontSize: 14 },
  money: { color: colors.text, fontWeight: '800' },
  total: { color: colors.primaryDark, fontWeight: '900' },
});
