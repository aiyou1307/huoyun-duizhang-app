import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { colors } from '../theme';
import type { CompanyRawRow } from '../types';
import { centsToYuan, yuanToCents } from '../utils/money';

export function CompanyRawRowEditor({
  row,
  onChange,
  onDelete,
  onCommit,
}: {
  row: CompanyRawRow;
  onChange: (row: CompanyRawRow) => void;
  onDelete: () => void;
  onCommit: (row: CompanyRawRow) => void;
}) {
  const moneyOk = row.freightCents + row.upstairsCents === row.totalCents;
  return (
    <View style={styles.card}>
      <View style={styles.topLine}>
        <Text style={styles.rowTitle}>第 {row.sourceRowNo} 行</Text>
        <View style={[styles.badge, moneyOk ? styles.okBadge : styles.warnBadge]}>
          <Text style={[styles.badgeText, moneyOk ? styles.okText : styles.warnText]}>{moneyOk ? '金额校验正常' : '金额加不起来'}</Text>
        </View>
        <Pressable onPress={onDelete}><Text style={styles.delete}>删除</Text></Pressable>
      </View>

      <View style={styles.moneyRow}>
        <View style={styles.smallField}><Text style={styles.label}>序号</Text><TextInput style={styles.input} value={row.originalSequence} onChangeText={(value) => onChange({ ...row, originalSequence: value })} onEndEditing={() => onCommit(row)} /></View>
        <View style={styles.wideField}><Text style={styles.label}>编号</Text><TextInput style={styles.input} value={row.orderCode} onChangeText={(value) => onChange({ ...row, orderCode: value })} onEndEditing={() => onCommit(row)} /></View>
      </View>

      <Text style={styles.label}>姓名</Text>
      <TextInput style={styles.input} value={row.recipientName} onChangeText={(value) => onChange({ ...row, recipientName: value })} placeholder="公司表中的姓名" onEndEditing={() => onCommit(row)} />

      <Text style={styles.label}>单子日期</Text>
      <TextInput
        style={styles.input}
        value={row.billDate}
        onChangeText={(value) => onChange({ ...row, billDate: value })}
        placeholder="2026-09-16"
        autoCapitalize="none"
        onEndEditing={() => onCommit(row)}
      />

      <Text style={styles.label}>地址 / 工地</Text>
      <TextInput
        style={[styles.input, styles.addressInput]}
        value={row.address}
        onChangeText={(value) => onChange({ ...row, address: value })}
        placeholder="按公司原账单填写"
        multiline
        onEndEditing={() => onCommit(row)}
      />

      <View style={styles.moneyRow}>
        <MoneyField
          label="运费"
          value={row.freightCents}
          onChange={(value) => onChange({ ...row, freightCents: value })}
          onCommit={() => onCommit(row)}
        />
        <MoneyField
          label="上楼费"
          value={row.upstairsCents}
          onChange={(value) => onChange({ ...row, upstairsCents: value })}
          onCommit={() => onCommit(row)}
        />
        <MoneyField
          label="合计"
          value={row.totalCents}
          onChange={(value) => onChange({ ...row, totalCents: value })}
          onCommit={() => onCommit(row)}
        />
      </View>
    </View>
  );
}

function MoneyField({ label, value, onChange, onCommit }: { label: string; value: number; onChange: (value: number) => void; onCommit: () => void }) {
  return (
    <View style={styles.moneyField}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={styles.input}
        value={centsToYuan(value)}
        onChangeText={(text) => onChange(yuanToCents(text))}
        keyboardType="decimal-pad"
        placeholder="0"
        onEndEditing={onCommit}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: '#fff', borderRadius: 16, borderWidth: 1, borderColor: colors.border, padding: 14, marginBottom: 12 },
  topLine: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  rowTitle: { fontSize: 17, fontWeight: '900', color: colors.text },
  badge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 999 },
  okBadge: { backgroundColor: '#E9F8F0' },
  warnBadge: { backgroundColor: '#FFF4DA' },
  badgeText: { fontSize: 12, fontWeight: '800' },
  okText: { color: colors.success },
  warnText: { color: '#A96300' },
  delete: { marginLeft: 'auto', color: colors.danger, fontWeight: '800', fontSize: 14 },
  label: { marginTop: 9, marginBottom: 5, color: '#53657A', fontWeight: '800', fontSize: 13 },
  input: { minHeight: 44, borderWidth: 1, borderColor: colors.border, borderRadius: 10, backgroundColor: '#FAFCFE', paddingHorizontal: 10, fontSize: 16, color: colors.text },
  addressInput: { minHeight: 64, paddingTop: 10, textAlignVertical: 'top' },
  moneyRow: { flexDirection: 'row', gap: 8 },
  moneyField: { flex: 1 },
  smallField: { flex: 0.35 },
  wideField: { flex: 1 },
});
