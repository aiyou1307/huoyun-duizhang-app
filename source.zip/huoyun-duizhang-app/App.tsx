import { useState } from 'react';
import { SQLiteProvider } from 'expo-sqlite';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { StyleSheet, View } from 'react-native';
import { migrateDbIfNeeded } from './src/db/database';
import { BottomNav } from './src/components/BottomNav';
import { CompanyBatchFlowScreen } from './src/screens/CompanyBatchFlowScreen';
import { CompanyMergedDetailScreen } from './src/screens/CompanyMergedDetailScreen';
import { CompanyScreen } from './src/screens/CompanyScreen';
import { DateLookupScreen } from './src/screens/DateLookupScreen';
import { EntryFormScreen } from './src/screens/EntryFormScreen';
import { HomeScreen } from './src/screens/HomeScreen';
import { MeScreen } from './src/screens/MeScreen';
import { ReconcileDetailScreen } from './src/screens/ReconcileDetailScreen';
import { ReconcileScreen } from './src/screens/ReconcileScreen';
import type { RootScreen } from './src/types';
import { todayYmd } from './src/utils/date';

type Overlay =
  | { kind: 'dateLookup' }
  | { kind: 'entryForm'; entryId?: number }
  | { kind: 'companyBatch'; batchId: number }
  | { kind: 'reconcileBatch'; batchId: number }
  | { kind: 'mergedDetail'; batchId: number; mergedId: number; returnTo: 'companyBatch' | 'reconcileBatch' }
  | null;

function MainApp() {
  const [tab, setTab] = useState<RootScreen>('home');
  const [selectedDate, setSelectedDate] = useState(todayYmd());
  const [overlay, setOverlay] = useState<Overlay>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  if (overlay?.kind === 'dateLookup') {
    return <DateLookupScreen onBack={() => setOverlay(null)} onSelect={(date) => { setSelectedDate(date); setOverlay(null); }} />;
  }

  if (overlay?.kind === 'entryForm') {
    return (
      <EntryFormScreen
        entryId={overlay.entryId}
        onBack={() => setOverlay(null)}
        onSaved={(recordDate) => {
          setSelectedDate(recordDate);
          setRefreshKey((value) => value + 1);
          setOverlay(null);
          setTab('home');
        }}
      />
    );
  }

  if (overlay?.kind === 'companyBatch') {
    return (
      <CompanyBatchFlowScreen
        batchId={overlay.batchId}
        onBack={() => setOverlay(null)}
        onOpenMerged={(mergedId) => setOverlay({ kind: 'mergedDetail', batchId: overlay.batchId, mergedId, returnTo: 'companyBatch' })}
      />
    );
  }

  if (overlay?.kind === 'reconcileBatch') {
    return (
      <ReconcileDetailScreen
        batchId={overlay.batchId}
        onBack={() => setOverlay(null)}
        onOpenMerged={(mergedId) => setOverlay({ kind: 'mergedDetail', batchId: overlay.batchId, mergedId, returnTo: 'reconcileBatch' })}
      />
    );
  }

  if (overlay?.kind === 'mergedDetail') {
    const current = overlay;
    return (
      <CompanyMergedDetailScreen
        batchId={current.batchId}
        mergedId={current.mergedId}
        onBack={() => setOverlay(current.returnTo === 'companyBatch'
          ? { kind: 'companyBatch', batchId: current.batchId }
          : { kind: 'reconcileBatch', batchId: current.batchId })}
      />
    );
  }

  return (
    <View style={styles.app}>
      <View style={styles.content}>
        {tab === 'home' ? (
          <HomeScreen
            selectedDate={selectedDate}
            refreshKey={refreshKey}
            onOpenDateLookup={() => setOverlay({ kind: 'dateLookup' })}
            onAdd={() => setOverlay({ kind: 'entryForm' })}
            onEdit={(id) => setOverlay({ kind: 'entryForm', entryId: id })}
          />
        ) : tab === 'company' ? (
          <CompanyScreen onOpenBatch={(batchId) => setOverlay({ kind: 'companyBatch', batchId })} />
        ) : tab === 'reconcile' ? (
          <ReconcileScreen onOpenBatch={(batchId) => setOverlay({ kind: 'reconcileBatch', batchId })} />
        ) : (
          <MeScreen onDataRestored={() => { setRefreshKey((value) => value + 1); setSelectedDate(todayYmd()); setTab('home'); }} />
        )}
      </View>
      <BottomNav current={tab} onChange={setTab} />
    </View>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
        <StatusBar style="light" />
        <SQLiteProvider databaseName="huoyun_ledger.db" onInit={migrateDbIfNeeded}>
          <MainApp />
        </SQLiteProvider>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#1287F5' },
  app: { flex: 1, backgroundColor: '#F4F8FC' },
  content: { flex: 1 },
});
