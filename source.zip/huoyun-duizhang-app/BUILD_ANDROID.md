# Android APK 构建说明（开发/测试）

当前项目已经准备了 `eas.json`：

- `preview`：输出可直接安装的 APK，用于家里真机测试。
- `production`：输出 AAB，用于以后正式上架；现阶段不用。

## 目标命令

```bash
npm install
npx expo install --fix
npx eas-cli login
npx eas-cli build --platform android --profile preview
```

本项目 OCR 使用 `rn-mlkit-ocr` 原生模块，因此不能只用 Expo Go 测完整 OCR；需要开发 APK 或 preview APK。

## 当前环境限制

本次工作容器执行 `npm install` 仍然在 120 秒超时，且没有 Android SDK，所以这里无法直接产出 APK。项目本身已补齐 EAS APK profile，换到可联网的构建环境后可以直接继续。

## 真机第一轮必测

1. 我的账：新增、修改、删除、照片保存。
2. 日期查找：现实/记账日期只用于查找，金额汇总正确，不参与对账。
3. 公司账：多张纸质账单上传。
4. OCR：真实公司账单逐行识别，重点观察日期、长地址、小数金额。
5. OCR 错误手动修改。
6. 未勾选“与原账单一致”时不能合并。
7. 确认后按“单子日期 + 地址”合并。
8. 1805 vs 1806 不自动匹配；明显重复“北京市北京市”可安全处理。
9. ±10 元规则、疑似漏单、公司多出、金额异常。
10. 我的 → 导出 CSV、完整备份、恢复。

## GitHub 自动构建（已准备）

项目内已加入 `.github/workflows/android-apk.yml`。把项目放到 GitHub 后，GitHub Actions 会：

1. 安装 Node / Java / Android SDK。
2. 安装依赖。
3. `expo prebuild` 生成 Android 原生工程。
4. 构建 `app-debug.apk`。
5. 把 APK 作为 Actions Artifact 提供下载。

这条路径不需要本地电脑安装 Android Studio，适合先拿到第一版测试 APK。
