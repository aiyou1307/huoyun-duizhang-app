const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const { DatabaseSync } = require('node:sqlite');
const XLSX = require('xlsx');
require.extensions['.ts'] = (m,f) => m._compile(ts.transpileModule(fs.readFileSync(f,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,f);
const data = require('../src/db/database.ts');
const { parseCompanyWorkbook } = require('../src/services/companyFileParser.ts');
const { buildCompanyMerge, sumCompany } = require('../src/utils/companyMerge.ts');
const { yuanToCents } = require('../src/utils/money.ts');
const os = require('node:os'); const temp = fs.mkdtempSync(path.join(os.tmpdir(),'huoyun-test-')); const dbFile=path.join(temp,'ledger.sqlite'); let sqlite = new DatabaseSync(dbFile);
let injectFailure = false;
const db = {
 execAsync: async sql => sqlite.exec(sql),
 runAsync: async (sql,...params) => { if (injectFailure && sql.startsWith('UPDATE company_merged_rows')) throw Error('injected save failure'); const r=sqlite.prepare(sql).run(...params); return {changes:Number(r.changes),lastInsertRowId:Number(r.lastInsertRowid)}; },
 getAllAsync: async (sql,...params)=>sqlite.prepare(sql).all(...params),
 getFirstAsync: async (sql,...params)=>sqlite.prepare(sql).get(...params) ?? null,
 withTransactionAsync: async fn=>{sqlite.exec('BEGIN IMMEDIATE');try{await fn();sqlite.exec('COMMIT');}catch(e){sqlite.exec('ROLLBACK');throw e;}}
};
const blank = {originalSequence:'',orderCode:'',recipientName:'',confidence:1};
const row = (id,date,addr,f,u)=>({...blank,id,batchId:1,importBatchId:1,photoId:null,sourceRowNo:id,billDate:date,address:addr,freightCents:f,upstairsCents:u,totalCents:f+u,createdAt:'',updatedAt:''});
async function main(){
 await data.migrateDbIfNeeded(db); await data.migrateDbIfNeeded(db);
 const fixtures = process.argv.slice(2);
 let parsed;
 for(const f of fixtures){
  const book = XLSX.read(fs.readFileSync(f).toString('base64'),{type:'base64',cellDates:false}); const result = parseCompanyWorkbook(book,'2026-10');
  assert.equal(result.errors.length,0,result.errors.join('\n')); assert.equal(result.rows.length,114);
  assert.deepEqual(sumCompany(result.rows),{freightCents:1089500,upstairsCents:1061851,totalCents:2151351});
  parsed=result;
  console.log(path.basename(f)+': 114 rows, freight 10895.00, upstairs 10618.51, total 21513.51 PASS');
 }
 if(!parsed){parsed={period:'2026-08',errors:[],rows:[{...blank,billDate:'2026-08-01',address:'测试1栋1单元101',freightCents:10000,upstairsCents:25,totalCents:10025}]};}
 const imported = await data.importMergedCompanyFile(db,parsed,'fixture.xlsx');
 assert.equal((await data.getCompanyBatch(db,imported)).totalCents,sumCompany(parsed.rows).totalCents);
 assert.equal((await data.getCompanyRawRows(db,imported)).length,0);
 await assert.rejects(()=>data.importMergedCompanyFile(db,parsed,'copy.csv'),/已经导入/);
 assert.equal((await data.getCompanyBatches(db)).length,1);
 const originals = parsed.rows.map((r,i)=>row(i+1,r.billDate,r.address,r.freightCents,r.upstairsCents));
 const plan=buildCompanyMerge(originals,[]);
 assert.deepEqual(sumCompany(plan.groups.map(sumCompany)),sumCompany(originals));
 if(fixtures.length){const example=plan.groups.find(g=>g.some(r=>r.address.includes('恒大滨河左岸南区1号楼2单元503')));assert.equal(sumCompany(example).totalCents,21060);assert.deepEqual([...new Set(example.map(r=>r.billDate))].sort(),['2026-08-28','2026-08-31']);}
 assert.equal(yuanToCents('165.'),16500);assert.equal(yuanToCents('165.50')+yuanToCents('10.25'),17575);
 const a=row(1,'2026-08-28','房山区恒大滨河左岸南区1号楼2单元503',0,3760),b=row(2,'2026-08-31',a.address,17000,300);
 assert.equal(buildCompanyMerge([a,b],[]).groups.length,1);
 assert.equal(buildCompanyMerge([a,{...b,billDate:'2026-09-02'}],[]).groups.length,2);
 assert.equal(buildCompanyMerge([a,{...b,billDate:'2026-08-30',freightCents:0,upstairsCents:300,totalCents:300}, {...a,id:3,sourceRowNo:3,billDate:'2026-09-02'}],[]).groups.length,2,'chain cannot extend span beyond 4');
 assert.equal(buildCompanyMerge([a,{...b,address:a.address.replace('503','504')}],[]).groups.length,2);
 assert.equal(buildCompanyMerge([{...a,freightCents:5000,totalCents:8760},b],[]).candidates.length,1);
 const account=await data.createCompanyBatch(db,'2026-08');const batch=await data.createCompanyImportBatch(db,account,'file','test');
 await data.addParsedRowsToImportBatch(db,account,batch,[a,b]);await data.confirmCompanyImportBatch(db,batch);await data.mergeCompanyBatch(db,account);
 let raw=await data.getCompanyRawRows(db,account); let merged=await data.getCompanyMergedRows(db,account); assert.equal(merged.length,1);assert.equal(merged[0].totalCents,21060);assert.equal(merged[0].rawRowIds.length,2);
 const initialId=merged[0].id;
 await data.updateCompanyRawRow(db,{...raw[0],upstairsCents:4000,totalCents:4000});
 assert.equal((await data.getCompanyBatch(db,account)).needsRemerge,true);
 assert.equal((await data.getCompanyMergedRows(db,account))[0].totalCents,21060,'old correct result retained');
 await assert.rejects(()=>data.getReconciliationSnapshot(db,account),/重新合并/);
 injectFailure=true;await assert.rejects(()=>data.mergeCompanyBatch(db,account),/injected/);injectFailure=false;
 assert.equal((await data.getCompanyMergedRows(db,account))[0].totalCents,21060);
 await data.mergeCompanyBatch(db,account);merged=await data.getCompanyMergedRows(db,account);
 assert.equal(merged[0].totalCents,21300);assert.equal(merged[0].id,initialId,'same provenance keeps matching links');
 raw=await data.getCompanyRawRows(db,account);
 await data.saveCompanyMergeDecision(db,account,[raw[0]],[raw[1]],'separate');await data.mergeCompanyBatch(db,account);assert.equal((await data.getCompanyMergedRows(db,account)).length,2);
 sqlite.close(); sqlite=new DatabaseSync(dbFile); await data.migrateDbIfNeeded(db);await data.mergeCompanyBatch(db,account);assert.equal((await data.getCompanyMergedRows(db,account)).length,2);
 await data.saveCompanyMergeDecision(db,account,[raw[0]],[raw[1]],'merge');await data.mergeCompanyBatch(db,account);assert.equal((await data.getCompanyMergedRows(db,account)).length,1);
 const own = await data.addEntry(db,{recordDate:'2026-09-01',billDate:'2026-08-31',tripNo:1,address:a.address,freightCents:17000,upstairsCents:4300,upstairsNote:null,photoUri:null,note:null});
 let snapshot=await data.getReconciliationSnapshot(db,account,'2026-08-01','2026-09-30');assert.equal(snapshot.normalCount,1,'second source date auto matches');
 await data.updateEntry(db,own,{recordDate:'2026-09-01',billDate:'2026-08-18',tripNo:1,address:a.address,freightCents:17000,upstairsCents:4300,upstairsNote:null,photoUri:null,note:null});
 snapshot=await data.getReconciliationSnapshot(db,account,'2026-08-01','2026-09-30');assert.equal(snapshot.candidateCount,0);assert.equal(snapshot.normalCount,0);
 const empty=await data.createCompanyBatch(db,'2026-08');await data.deleteCompanyBatch(db,empty);assert.ok(await data.getCompanyBatch(db,account));
 const duplicate=await data.createCompanyImportBatch(db,account,'file','repeat');await assert.rejects(()=>data.addParsedRowsToImportBatch(db,account,duplicate,awaitableRows(raw)),/已经|已存在/);
 // Inclusive 10-yuan boundaries, normal fuzzy address and strict date gate.
 const checkAccount=await data.importMergedCompanyFile(db,{period:'2026-07',errors:[],rows:[{...blank,billDate:'2026-07-01',address:'北京市北京市朝阳区瞰都1栋0单元607室',freightCents:10000,upstairsCents:0,totalCents:10000}]},'boundary.csv');
 const checkOwn=await data.addEntry(db,{recordDate:'2026-07-01',billDate:'2026-07-01',tripNo:1,address:'朝阳区瞰都1号楼零单元607',freightCents:10000,upstairsCents:0,photoUri:null,note:null,upstairsNote:null});
 for(const [amount,expected] of [[10040,'normal'],[10999,'normal'],[11000,'normal'],[11001,'amount_anomaly']]){
  const entry=await data.getEntry(db,checkOwn);await data.updateEntry(db,checkOwn,{...entry,freightCents:amount});
  const snap=await data.getReconciliationSnapshot(db,checkAccount,'2026-07-01','2026-07-01');assert.equal(snap.items[0].kind,expected);
 }
 const tripAccount=await data.importMergedCompanyFile(db,{period:'2026-06',errors:[],rows:[{...blank,billDate:'2026-06-01',address:'测试A1栋101',freightCents:5000,upstairsCents:0,totalCents:5000},{...blank,billDate:'2026-06-03',address:'测试B2栋202',freightCents:21600,upstairsCents:0,totalCents:21600}]},'trip.csv');
 const ownA=await data.addEntry(db,{recordDate:'2026-06-03',billDate:'2026-06-01',tripNo:1,address:'测试A1栋101',freightCents:21600,upstairsCents:0,photoUri:null,note:null,upstairsNote:null});
 const ownB=await data.addEntry(db,{recordDate:'2026-06-03',billDate:'2026-06-03',tripNo:1,address:'测试B2栋202',freightCents:5000,upstairsCents:0,photoUri:null,note:null,upstairsNote:null});
 let tripSnap=await data.getReconciliationSnapshot(db,tripAccount,'2026-06-03','2026-06-03');assert.equal(tripSnap.normalCount,2);assert.equal(tripSnap.items.filter(i=>i.tripFreightBalanced).length,2);
 const tripEntry=await data.getEntry(db,ownB);await data.updateEntry(db,ownB,{...tripEntry,freightCents:12000});
 tripSnap=await data.getReconciliationSnapshot(db,tripAccount,'2026-06-03','2026-06-03');assert.ok(tripSnap.items.every(i=>!i.tripFreightBalanced));assert.equal(tripSnap.items[0].tripFreightDifferenceCents,-7000);
 await data.updateEntry(db,ownB,{...tripEntry,tripNo:2});tripSnap=await data.getReconciliationSnapshot(db,tripAccount,'2026-06-03','2026-06-03');assert.equal(tripSnap.anomalyCount,2,'different trips never offset');
 // Scale uses real amounts with independent row identifiers; all 300 rows must be retained.
 const many=Array.from({length:300},(_,i)=>row(i+1,'2026-05-01',`测试${i+1}栋101`,i*100,25));
 const started=performance.now();const large=buildCompanyMerge(many,[]);assert.equal(large.groups.flat().length,300);assert.deepEqual(sumCompany(large.groups.map(sumCompany)),sumCompany(many));
 console.log(`300-row merge correctness: ${(performance.now()-started).toFixed(0)} ms`);
 sqlite.close();fs.rmSync(temp,{recursive:true,force:true});
 console.log('SQLite migration, save/remerge, rollback, manual merge/split persistence, provenance dates, duplicates and decimals PASS');
}
function awaitableRows(raw){return raw.map(r=>({...r}));}
main().catch(e=>{console.error(e);process.exitCode=1;});
